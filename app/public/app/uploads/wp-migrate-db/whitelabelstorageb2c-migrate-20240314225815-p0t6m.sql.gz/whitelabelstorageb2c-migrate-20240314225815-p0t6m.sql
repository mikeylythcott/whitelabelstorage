# WordPress MySQL database migration
#
# Generated: Thursday 14. March 2024 22:58 UTC
# Hostname: localhost
# Database: `local`
# URL: //white-label-storage-b2c.local
# Path: /Users/mikey/Local Sites/white-label-storage-b2c/app/public
# Tables: wp_actionscheduler_actions, wp_actionscheduler_claims, wp_actionscheduler_groups, wp_actionscheduler_logs, wp_aioseo_cache, wp_aioseo_crawl_cleanup_blocked_args, wp_aioseo_crawl_cleanup_logs, wp_aioseo_notifications, wp_aioseo_posts, wp_blogmeta, wp_blogs, wp_commentmeta, wp_comments, wp_defender_audit_log, wp_defender_email_log, wp_defender_lockout, wp_defender_lockout_log, wp_defender_scan, wp_defender_scan_item, wp_links, wp_moos_oauth_access_tokens, wp_moos_oauth_authorization_codes, wp_moos_oauth_authorized_apps, wp_moos_oauth_clients, wp_moos_oauth_public_keys, wp_moos_oauth_refresh_tokens, wp_moos_oauth_scopes, wp_moos_oauth_users, wp_options, wp_postmeta, wp_posts, wp_registration_log, wp_signups, wp_site, wp_sitemeta, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, page, post, wp_navigation
# Protocol: https
# Multisite: true
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_actionscheduler_actions`
#

DROP TABLE IF EXISTS `wp_actionscheduler_actions`;


#
# Table structure of table `wp_actionscheduler_actions`
#

CREATE TABLE `wp_actionscheduler_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scheduled_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  `priority` tinyint(3) unsigned NOT NULL DEFAULT '10',
  `args` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schedule` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `attempts` int(11) NOT NULL DEFAULT '0',
  `last_attempt_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `extended_args` varchar(8000) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `hook` (`hook`),
  KEY `status` (`status`),
  KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  KEY `args` (`args`),
  KEY `group_id` (`group_id`),
  KEY `last_attempt_gmt` (`last_attempt_gmt`),
  KEY `claim_id_status_scheduled_date_gmt` (`claim_id`,`status`,`scheduled_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_actions`
#
INSERT INTO `wp_actionscheduler_actions` ( `action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `priority`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES
(12, 'action_scheduler/migration_hook', 'complete', '2024-03-10 04:07:05', '2024-03-10 04:07:05', 10, '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1710043625;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1710043625;s:19:"scheduled_timestamp";i:1710043625;s:9:"timestamp";i:1710043625;}', 2, 1, '2024-03-10 04:07:12', '2024-03-10 04:07:12', 0, NULL),
(13, 'aioseo_cache_prune', 'pending', '2024-03-11 04:06:05', '2024-03-11 04:06:05', 10, '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1710129965;s:18:"\0*\0first_timestamp";i:1710043565;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1710129965;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1710129965;s:15:"first_timestamp";i:1710043565;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1710129965;s:19:"interval_in_seconds";i:86400;}', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(18, 'defender/async_scan', 'complete', '2024-03-10 04:06:34', '2024-03-10 04:06:34', 10, '{"type":"install"}', 'O:28:"ActionScheduler_NullSchedule":0:{}', 3, 1, '2024-03-10 04:07:12', '2024-03-10 04:07:12', 0, NULL),
(28, 'aioseo_image_sitemap_scan', 'complete', '2024-03-10 11:23:02', '2024-03-10 07:23:02', 10, '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1710069782;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1710069782;s:19:"scheduled_timestamp";i:1710069782;s:9:"timestamp";i:1710069782;}', 1, 1, '2024-03-10 11:24:28', '2024-03-10 07:24:28', 0, NULL),
(29, 'aioseo_image_sitemap_scan', 'pending', '2024-03-10 11:39:28', '2024-03-10 07:39:28', 10, '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1710070768;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1710070768;s:19:"scheduled_timestamp";i:1710070768;s:9:"timestamp";i:1710070768;}', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(30, 'action_scheduler/migration_hook', 'pending', '2024-03-10 11:33:56', '2024-03-10 07:33:56', 10, '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1710070436;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1710070436;s:19:"scheduled_timestamp";i:1710070436;s:9:"timestamp";i:1710070436;}', 2, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL) ;

#
# End of data contents of table `wp_actionscheduler_actions`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_claims`
#

DROP TABLE IF EXISTS `wp_actionscheduler_claims`;


#
# Table structure of table `wp_actionscheduler_claims`
#

CREATE TABLE `wp_actionscheduler_claims` (
  `claim_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date_created_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`claim_id`),
  KEY `date_created_gmt` (`date_created_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_claims`
#

#
# End of data contents of table `wp_actionscheduler_claims`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_groups`
#

DROP TABLE IF EXISTS `wp_actionscheduler_groups`;


#
# Table structure of table `wp_actionscheduler_groups`
#

CREATE TABLE `wp_actionscheduler_groups` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_groups`
#
INSERT INTO `wp_actionscheduler_groups` ( `group_id`, `slug`) VALUES
(1, 'aioseo'),
(2, 'action-scheduler-migration'),
(3, 'defender') ;

#
# End of data contents of table `wp_actionscheduler_groups`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_logs`
#

DROP TABLE IF EXISTS `wp_actionscheduler_logs`;


#
# Table structure of table `wp_actionscheduler_logs`
#

CREATE TABLE `wp_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_logs`
#
INSERT INTO `wp_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(7, 12, 'action created', '2024-03-10 04:06:05', '2024-03-10 04:06:05'),
(10, 13, 'action created', '2024-03-10 04:06:05', '2024-03-10 04:06:05'),
(16, 18, 'action created', '2024-03-10 04:06:34', '2024-03-10 04:06:34'),
(28, 18, 'action started via WP Cron', '2024-03-10 04:07:04', '2024-03-10 04:07:04'),
(29, 18, 'action complete via WP Cron', '2024-03-10 04:07:12', '2024-03-10 04:07:12'),
(32, 12, 'action started via WP Cron', '2024-03-10 04:07:12', '2024-03-10 04:07:12'),
(33, 12, 'action complete via WP Cron', '2024-03-10 04:07:12', '2024-03-10 04:07:12'),
(59, 28, 'action created', '2024-03-10 11:22:32', '2024-03-10 07:22:32'),
(61, 28, 'action started via WP Cron', '2024-03-10 11:24:28', '2024-03-10 07:24:28'),
(62, 29, 'action created', '2024-03-10 11:24:28', '2024-03-10 07:24:28'),
(63, 28, 'action complete via WP Cron', '2024-03-10 11:24:28', '2024-03-10 07:24:28'),
(64, 30, 'action created', '2024-03-10 11:32:56', '2024-03-10 07:32:56') ;

#
# End of data contents of table `wp_actionscheduler_logs`
# --------------------------------------------------------



#
# Delete any existing table `wp_aioseo_cache`
#

DROP TABLE IF EXISTS `wp_aioseo_cache`;


#
# Table structure of table `wp_aioseo_cache`
#

CREATE TABLE `wp_aioseo_cache` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `expiration` datetime DEFAULT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ndx_aioseo_cache_key` (`key`),
  KEY `ndx_aioseo_cache_expiration` (`expiration`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_aioseo_cache`
#
INSERT INTO `wp_aioseo_cache` ( `id`, `key`, `value`, `expiration`, `created`, `updated`) VALUES
(1, 'admin_notifications_update', 'i:1710129984;', '2024-03-11 04:06:24', '2024-03-10 04:06:24', '2024-03-10 04:06:24'),
(2, 'attachment_url_to_post_id_d99ed2ddbeefba28910cca4100f73b401b38bc49', 's:4:"none";', '2024-03-11 04:13:03', '2024-03-10 04:13:03', '2024-03-10 04:13:03'),
(3, 'addons', 'a:9:{i:0;O:8:"stdClass":15:{s:3:"sku";s:16:"aioseo-redirects";s:4:"name";s:19:"Redirection Manager";s:7:"version";s:5:"1.3.7";s:5:"image";N;s:4:"icon";s:480:"PHN2ZyB2aWV3Qm94PSIwIDAgMjQgMjQiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgY2xhc3M9ImFpb3Nlby1yZWRpcmVjdCI+PHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0xMC41OSA5LjE3TDUuNDEgNEw0IDUuNDFMOS4xNyAxMC41OEwxMC41OSA5LjE3Wk0xNC41IDRMMTYuNTQgNi4wNEw0IDE4LjU5TDUuNDEgMjBMMTcuOTYgNy40NkwyMCA5LjVWNEgxNC41Wk0xMy40MiAxNC44MkwxNC44MyAxMy40MUwxNy45NiAxNi41NEwyMCAxNC41VjIwSDE0LjVMMTYuNTUgMTcuOTVMMTMuNDIgMTQuODJaIiBmaWxsPSJjdXJyZW50Q29sb3IiIC8+PC9zdmc+";s:6:"levels";a:4:{i:0;s:8:"business";i:1;s:6:"agency";i:2;s:3:"pro";i:3;s:5:"elite";}s:13:"currentLevels";a:2:{i:0;s:3:"pro";i:1;s:5:"elite";}s:15:"requiresUpgrade";b:1;s:11:"description";s:101:"<p>Our Redirection Manager allows you to create and manage redirects for 404s or modified posts.</p>\n";s:18:"descriptionVersion";i:0;s:11:"downloadUrl";s:0:"";s:10:"productUrl";s:48:"https://aioseo.com/features/redirection-manager/";s:12:"learnMoreUrl";s:48:"https://aioseo.com/features/redirection-manager/";s:9:"manageUrl";s:40:"https://route#aioseo-redirects:redirects";s:8:"features";a:1:{i:0;O:8:"stdClass":2:{s:13:"license_level";s:5:"elite";s:7:"feature";s:19:"404-parent-redirect";}}}i:1;O:8:"stdClass":15:{s:3:"sku";s:21:"aioseo-link-assistant";s:4:"name";s:14:"Link Assistant";s:7:"version";s:5:"1.1.3";s:5:"image";N;s:4:"icon";s:516:"PHN2ZyB2aWV3Qm94PSIwIDAgMjQgMjQiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0xMSAxNUg3QzUuMzUgMTUgNCAxMy42NSA0IDEyQzQgMTAuMzUgNS4zNSA5IDcgOUgxMVY3SDdDNC4yNCA3IDIgOS4yNCAyIDEyQzIgMTQuNzYgNC4yNCAxNyA3IDE3SDExVjE1Wk0xNyA3SDEzVjlIMTdDMTguNjUgOSAyMCAxMC4zNSAyMCAxMkMyMCAxMy42NSAxOC42NSAxNSAxNyAxNUgxM1YxN0gxN0MxOS43NiAxNyAyMiAxNC43NiAyMiAxMkMyMiA5LjI0IDE5Ljc2IDcgMTcgN1pNMTYgMTFIOFYxM0gxNlYxMVoiIGZpbGw9ImN1cnJlbnRDb2xvciIvPjwvc3ZnPgo=";s:6:"levels";a:3:{i:0;s:6:"agency";i:1;s:3:"pro";i:2;s:5:"elite";}s:13:"currentLevels";a:2:{i:0;s:3:"pro";i:1;s:5:"elite";}s:15:"requiresUpgrade";b:1;s:11:"description";s:283:"<p>Super-charge your SEO with Link Assistant! Get relevant suggestions for adding internal links to older content as well as finding any orphaned posts that have no internal links. Use our reporting feature to see all link suggestions or add them directly from any page or post.</p>\n";s:18:"descriptionVersion";i:0;s:11:"downloadUrl";s:0:"";s:10:"productUrl";s:39:"https://aioseo.com/docs/link-assistant/";s:12:"learnMoreUrl";s:39:"https://aioseo.com/docs/link-assistant/";s:9:"manageUrl";s:44:"https://route#aioseo-link-assistant:overview";s:8:"features";a:0:{}}i:2;O:8:"stdClass":15:{s:3:"sku";s:20:"aioseo-video-sitemap";s:4:"name";s:13:"Video Sitemap";s:7:"version";s:6:"1.1.13";s:5:"image";N;s:4:"icon";s:420:"PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMCAyMCI+PHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBkPSJNMy4zMzMgNWgxMGMuNDU5IDAgLjgzNC4zNzUuODM0LjgzM1Y4Ljc1TDE3LjUgNS40MTd2OS4xNjZsLTMuMzMzLTMuMzMzdjIuOTE3YS44MzYuODM2IDAgMCAxLS44MzQuODMzaC0xMGEuODM2LjgzNiAwIDAgMS0uODMzLS44MzNWNS44MzNjMC0uNDU4LjM3NS0uODMzLjgzMy0uODMzWm05LjE2NyA4LjMzM1Y2LjY2N0g0LjE2N3Y2LjY2NkgxMi41WiIgY2xpcC1ydWxlPSJldmVub2RkIi8+PC9zdmc+";s:6:"levels";a:5:{i:0;s:10:"individual";i:1;s:8:"business";i:2;s:6:"agency";i:3;s:3:"pro";i:4;s:5:"elite";}s:13:"currentLevels";a:2:{i:0;s:3:"pro";i:1;s:5:"elite";}s:15:"requiresUpgrade";b:1;s:11:"description";s:243:"<p>The Video Sitemap works in much the same way as the XML Sitemap module, it generates an XML Sitemap specifically for video content on your site. Search engines use this information to display rich snippet information in search results.</p>\n";s:18:"descriptionVersion";i:0;s:11:"downloadUrl";s:0:"";s:10:"productUrl";s:54:"https://aioseo.com/docs/how-to-create-a-video-sitemap/";s:12:"learnMoreUrl";s:54:"https://aioseo.com/docs/how-to-create-a-video-sitemap/";s:9:"manageUrl";s:43:"https://route#aioseo-sitemaps:video-sitemap";s:8:"features";a:0:{}}i:3;O:8:"stdClass":15:{s:3:"sku";s:21:"aioseo-local-business";s:4:"name";s:18:"Local Business SEO";s:7:"version";s:5:"1.3.0";s:5:"image";N;s:4:"icon";s:18:"svg-local-business";s:6:"levels";a:5:{i:0;s:8:"business";i:1;s:6:"agency";i:2;s:4:"plus";i:3;s:3:"pro";i:4;s:5:"elite";}s:13:"currentLevels";a:3:{i:0;s:4:"plus";i:1;s:3:"pro";i:2;s:5:"elite";}s:15:"requiresUpgrade";b:1;s:11:"description";s:253:"<p>Local Business schema markup enables you to tell Google about your business, including your business name, address and phone number, opening hours and price range. This information may be displayed as a Knowledge Graph card or business carousel.</p>\n";s:18:"descriptionVersion";i:0;s:11:"downloadUrl";s:0:"";s:10:"productUrl";s:43:"https://aioseo.com/docs/local-business-seo/";s:12:"learnMoreUrl";s:43:"https://aioseo.com/docs/local-business-seo/";s:9:"manageUrl";s:40:"https://route#aioseo-local-seo:locations";s:8:"features";a:0:{}}i:4;O:8:"stdClass":15:{s:3:"sku";s:19:"aioseo-news-sitemap";s:4:"name";s:12:"News Sitemap";s:7:"version";s:6:"1.0.15";s:5:"image";N;s:4:"icon";s:16:"svg-sitemaps-pro";s:6:"levels";a:4:{i:0;s:8:"business";i:1;s:6:"agency";i:2;s:3:"pro";i:3;s:5:"elite";}s:13:"currentLevels";a:2:{i:0;s:3:"pro";i:1;s:5:"elite";}s:15:"requiresUpgrade";b:1;s:11:"description";s:284:"<p>Our Google News Sitemap lets you control which content you submit to Google News and only contains articles that were published in the last 48 hours. In order to submit a News Sitemap to Google, you must have added your site to Google’s Publisher Center and had it approved.</p>\n";s:18:"descriptionVersion";i:0;s:11:"downloadUrl";s:0:"";s:10:"productUrl";s:60:"https://aioseo.com/docs/how-to-create-a-google-news-sitemap/";s:12:"learnMoreUrl";s:60:"https://aioseo.com/docs/how-to-create-a-google-news-sitemap/";s:9:"manageUrl";s:42:"https://route#aioseo-sitemaps:news-sitemap";s:8:"features";a:0:{}}i:5;O:8:"stdClass":15:{s:3:"sku";s:16:"aioseo-index-now";s:4:"name";s:8:"IndexNow";s:7:"version";s:6:"1.0.11";s:5:"image";N;s:4:"icon";s:1836:"PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMCAyMCI+PHBhdGggZD0iTTE3LjY0NCAxMS42NTVjLS4zMjEtLjIyOS0uNjU0LS40NDYtLjk2NC0uNjk3LS42NDMtLjUzNC0uNjMxLTEuMzcyLjAyMy0xLjg4NC4zMS0uMjQuNjQyLS40NTguOTY0LS42OTcuMTg0LS4xMy4zMjEtLjI5NC4zMzMtLjUzNCAwLS4wMzIgMC0uMDc2LS4wMTItLjEyYTcuNDQyIDcuNDQyIDAgMCAwLTEuODkzLTMuMTQ3Yy0uMjA3LS4yMDctLjQ2LS4yNC0uNzQ2LS4xMmEyMi4wNSAyMi4wNSAwIDAgMS0xLjA2OC40MzZjLS45MTguMzQ4LTEuNjg3LS4wODctMS44MTMtMS4wMjQtLjA0Ni0uMzM4LS4wOC0uNjc1LS4xMTUtMS4wMTMtLjAzNC0uMzctLjI0LS41OTktLjYzLS42NzVhOC40NDYgOC40NDYgMCAwIDAtMy40NjcgMGMtLjM2Ny4wNzYtLjU3NC4yNzItLjYwOC42MzJhMTMuNzggMTMuNzggMCAwIDEtLjE2IDEuMTc2Yy0uMTYxLjgyOC0uOTE5IDEuMjMtMS43NDUuOTE1LS4zNTYtLjEzLS43MTItLjI5NC0xLjA2Ny0uNDQ3LS4zMzMtLjE0MS0uNjA5LS4wODctLjg1LjE2NGE3Ljc3OSA3Ljc3OSAwIDAgMC0xLjc3OSAyLjkxOGMtLjExNC4zMzgtLjAyMy42MS4yODcuODI4LjI5OS4yMDcuNjA5LjQxNC44OTUuNjMyLjc3LjU4OC43NTggMS40NDgtLjAyMiAyLjAxNC0uMjg3LjIwNy0uNTc0LjQxNC0uODYxLjYxLS4zMjIuMjE4LS40MTMuNTEyLS4yOTkuODZhNy44NyA3Ljg3IDAgMCAwIDEuNzQ1IDIuODg3Yy4yNC4yNS41MTYuMzE2Ljg1LjE4NS4zOS0uMTUzLjc2OC0uMzI3IDEuMTU4LS40NjguNzU4LS4yNzMgMS41MTUuMTIgMS42NzYuODcuMDguNDA0LjEyNi44MTguMTYgMS4yMi4wMzUuMzcuMjQxLjU2Ny41OTcuNjQzIDEuMTYuMjQgMi4zMDcuMjQgMy40NjYuMDExLjQxMy0uMDg3LjYwOC0uMzE2LjY0My0uNzA4LjAyMy0uMzI3LjA2OS0uNjUzLjEwMy0uOTcuMTE1LS45MjUuODk1LTEuMzgyIDEuODE0LTEuMDQ1LjM0NC4xMzEuNjg4LjI3MyAxLjAzMi40MjUuMzY4LjE1My42NjYuMDc2LjkxOC0uMjA3YTguNDk0IDguNDk0IDAgMCAwIDEuNzEtMi44MmMuMTUtLjMzOC4wNTgtLjYyMS0uMjc1LS44NXptLTkuNDguNjk3Yy0uMTAzLjEzLS4zMS4xMi0uNDEzLS4wMUw2LjAzIDEwLjE3M2EuMjIuMjIgMCAwIDEgMC0uMjgzbDEuOTI4LTIuNDI5IDEuNDY5IDEuNzItLjYzMS44NS41MjcuNzA4YS4yMDUuMjA1IDAgMCAxLS4wMTEuMjYyem01LjgzLTIuMTc4LTIuNDc5IDMuMDE3YS4yNi4yNiAwIDAgMS0uMjA2LjEwOUg5LjEwNWEuMjUuMjUgMCAwIDEtLjIwNi0uNDAzbDIuMzUzLTIuODY1LTIuNjc0LTMuMjY3aDIuODY5bDIuNTU5IDMuMTI2YS4yMzYuMjM2IDAgMCAxLS4wMTEuMjgzeiIvPjwvc3ZnPg==";s:6:"levels";a:6:{i:0;s:8:"business";i:1;s:6:"agency";i:2;s:5:"basic";i:3;s:4:"plus";i:4;s:3:"pro";i:5;s:5:"elite";}s:13:"currentLevels";a:4:{i:0;s:5:"basic";i:1;s:4:"plus";i:2;s:3:"pro";i:3;s:5:"elite";}s:15:"requiresUpgrade";b:1;s:11:"description";s:193:"<p>Add IndexNow support to instantly notify search engines when your content has changed. This helps the search engines to prioritize the changes on your website and helps you rank faster.</p>\n";s:18:"descriptionVersion";i:0;s:11:"downloadUrl";s:0:"";s:10:"productUrl";s:28:"https://aioseo.com/index-now";s:12:"learnMoreUrl";s:28:"https://aioseo.com/index-now";s:9:"manageUrl";s:45:"https://route#aioseo-settings:webmaster-tools";s:8:"features";a:0:{}}i:6;O:8:"stdClass":15:{s:3:"sku";s:15:"aioseo-rest-api";s:4:"name";s:8:"REST API";s:7:"version";s:5:"1.0.6";s:5:"image";N;s:4:"icon";s:280:"PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgY2xhc3M9ImFpb3Nlby1jb2RlIj48cGF0aCBkPSJNOS40IDE2LjZMNC44IDEybDQuNi00LjZMOCA2bC02IDYgNiA2IDEuNC0xLjR6bTUuMiAwbDQuNi00LjYtNC42LTQuNkwxNiA2bDYgNi02IDYtMS40LTEuNHoiIGZpbGw9ImN1cnJlbnRDb2xvciIvPjwvc3ZnPg==";s:6:"levels";a:3:{i:0;s:4:"plus";i:1;s:3:"pro";i:2;s:5:"elite";}s:13:"currentLevels";a:3:{i:0;s:4:"plus";i:1;s:3:"pro";i:2;s:5:"elite";}s:15:"requiresUpgrade";b:1;s:11:"description";s:137:"<p>Manage your post and term SEO meta via the WordPress REST API. This addon also works seamlessly with headless WordPress installs.</p>\n";s:18:"descriptionVersion";i:0;s:11:"downloadUrl";s:0:"";s:10:"productUrl";s:36:"https://aioseo.com/feature/rest-api/";s:12:"learnMoreUrl";s:36:"https://aioseo.com/feature/rest-api/";s:9:"manageUrl";s:0:"";s:8:"features";a:0:{}}i:7;O:8:"stdClass":15:{s:3:"sku";s:16:"aioseo-image-seo";s:4:"name";s:9:"Image SEO";s:7:"version";s:6:"1.1.10";s:5:"image";N;s:4:"icon";s:436:"PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyMCAyMCI+PHBhdGggZD0iTTE1LjgzMyA0LjE2N3YxMS42NjZINC4xNjdWNC4xNjdoMTEuNjY2Wm0wLTEuNjY3SDQuMTY3QzMuMjUgMi41IDIuNSAzLjI1IDIuNSA0LjE2N3YxMS42NjZjMCAuOTE3Ljc1IDEuNjY3IDEuNjY3IDEuNjY3aDExLjY2NmMuOTE3IDAgMS42NjctLjc1IDEuNjY3LTEuNjY3VjQuMTY3YzAtLjkxNy0uNzUtMS42NjctMS42NjctMS42NjdabS00LjA1IDcuMzgzLTIuNSAzLjIyNUw3LjUgMTAuOTUgNSAxNC4xNjdoMTBsLTMuMjE3LTQuMjg0WiIvPjwvc3ZnPg==";s:6:"levels";a:5:{i:0;s:8:"business";i:1;s:6:"agency";i:2;s:4:"plus";i:3;s:3:"pro";i:4;s:5:"elite";}s:13:"currentLevels";a:3:{i:0;s:4:"plus";i:1;s:3:"pro";i:2;s:5:"elite";}s:15:"requiresUpgrade";b:1;s:11:"description";s:148:"<p>Globally control the Title attribute and Alt text for images in your content. These attributes are essential for both accessibility and SEO.</p>\n";s:18:"descriptionVersion";i:0;s:11:"downloadUrl";s:0:"";s:10:"productUrl";s:71:"https://aioseo.com/docs/using-the-image-seo-features-in-all-in-one-seo/";s:12:"learnMoreUrl";s:71:"https://aioseo.com/docs/using-the-image-seo-features-in-all-in-one-seo/";s:9:"manageUrl";s:44:"https://route#aioseo-search-appearance:media";s:8:"features";a:0:{}}i:8;O:8:"stdClass":15:{s:3:"sku";s:11:"aioseo-eeat";s:4:"name";s:20:"Author SEO (E-E-A-T)";s:7:"version";s:5:"1.1.0";s:5:"image";N;s:4:"icon";s:1380:"PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgLTk2MCA5NjAgOTYwIiB3aWR0aD0iMjQiPjxwYXRoIGQ9Ik00NDAuMTE4LTU2MHEzMy44MzkgMCA1Ny44MTctMjQuMDk3dDIzLjk3OC01Ny45MzVxMC0zMy44MzgtMjMuOTc4LTU3LjY5Ni0yMy45NzgtMjMuODU5LTU3LjgxNy0yMy44NTktMzMuODM4IDAtNTcuOTM0IDIzLjg1OS0yNC4wOTcgMjMuODU4LTI0LjA5NyA1Ny42OTYgMCAzMy44MzggMjQuMDk3IDU3LjkzNVE0MDYuMjgtNTYwIDQ0MC4xMTgtNTYwWk00NDAtMzk2LjQxM3E0NS43MTcgMCA4NS41NzYtMTkuNDc4IDM5Ljg1OS0xOS40NzkgNjkuNTc2LTU2LjE1Mi0zNS45NTYtMjMuNzE4LTc0LjkzNS0zNS44MzdRNDgxLjIzOS01MjAgNDQwLTUyMHQtODAuMjE3IDEyLjEycS0zOC45NzkgMTIuMTE5LTc0LjkzNSAzNS44MzcgMjkuNzE3IDM2LjY3MyA2OS41NzYgNTYuMTUyIDM5Ljg1OSAxOS40NzggODUuNTc2IDE5LjQ3OFptMzg2LjM5MSAyODYuOTM1TDYzNy45MTMtMjk3Ljk1NnEtNDEuNzE3IDMxLjc2MS05MS42OTYgNDkuNDAyUTQ5Ni4yMzktMjMwLjkxMyA0NDAtMjMwLjkxM3EtMTM3LjU4NyAwLTIzMy4zMzctOTUuNzVUMTEwLjkxMy01NjBxMC0xMzcuNTg3IDk1Ljc1LTIzMy4zMzdUNDQwLTg4OS4wODdxMTM3LjU4NyAwIDIzMy4zMzcgOTUuNzVUNzY5LjA4Ny01NjBxMCA1NS43NjEtMTcuNzYxIDEwNS45NzgtMTcuNzYxIDUwLjIxOC00OS41MjEgOTIuMTc0TDg5MC4yODMtMTczLjM3bC02My44OTIgNjMuODkyWk00NDAuMTEzLTMyMS45MTNxOTkuMTU2IDAgMTY4LjU2NS02OS41MjIgNjkuNDA5LTY5LjUyMiA2OS40MDktMTY4LjY3OCAwLTk5LjE1Ni02OS40MDktMTY4LjU2NS02OS40MDktNjkuNDA5LTE2OC41NjUtNjkuNDA5LTk5LjE1NiAwLTE2OC42NzggNjkuNDA5LTY5LjUyMiA2OS40MDktNjkuNTIyIDE2OC41NjUgMCA5OS4xNTYgNjkuNTIyIDE2OC42NzggNjkuNTIyIDY5LjUyMiAxNjguNjc4IDY5LjUyMlpNNDQwLTU2MFoiLz48L3N2Zz4=";s:6:"levels";a:3:{i:0;s:4:"plus";i:1;s:3:"pro";i:2;s:5:"elite";}s:13:"currentLevels";a:3:{i:0;s:4:"plus";i:1;s:3:"pro";i:2;s:5:"elite";}s:15:"requiresUpgrade";b:1;s:11:"description";s:147:"<p>Optimize your site for Google\'s E-E-A-T ranking factor by proving your writer\'s expertise through author schema markup and new UI elements.</p>\n";s:18:"descriptionVersion";i:0;s:11:"downloadUrl";s:0:"";s:10:"productUrl";s:33:"https://aioseo.com/features/eeat/";s:12:"learnMoreUrl";s:33:"https://aioseo.com/features/eeat/";s:9:"manageUrl";s:49:"https://route#aioseo-search-appearance:author-seo";s:8:"features";a:0:{}}}', '2024-03-11 04:13:04', '2024-03-10 04:13:04', '2024-03-10 04:13:04'),
(4, 'wp_notices', 'a:0:{}', '2024-03-11 11:32:41', '2024-03-10 04:20:14', '2024-03-10 11:32:41'),
(5, 'license_features', 'a:21:{i:0;O:8:"stdClass":3:{s:13:"license_level";s:3:"pro";s:7:"section";s:6:"schema";s:7:"feature";s:5:"event";}i:1;O:8:"stdClass":3:{s:13:"license_level";s:5:"elite";s:7:"section";s:6:"schema";s:7:"feature";s:5:"event";}i:2;O:8:"stdClass":3:{s:13:"license_level";s:5:"elite";s:7:"section";s:6:"schema";s:7:"feature";s:11:"job-posting";}i:3;O:8:"stdClass":3:{s:13:"license_level";s:5:"elite";s:7:"section";s:5:"tools";s:7:"feature";s:29:"network-tools-site-activation";}i:4;O:8:"stdClass":3:{s:13:"license_level";s:5:"elite";s:7:"section";s:5:"tools";s:7:"feature";s:22:"network-tools-database";}i:5;O:8:"stdClass":3:{s:13:"license_level";s:5:"elite";s:7:"section";s:5:"tools";s:7:"feature";s:27:"network-tools-import-export";}i:6;O:8:"stdClass":3:{s:13:"license_level";s:5:"elite";s:7:"section";s:5:"tools";s:7:"feature";s:20:"network-tools-robots";}i:7;O:8:"stdClass":3:{s:13:"license_level";s:5:"elite";s:7:"section";s:17:"search-statistics";s:7:"feature";s:14:"seo-statistics";}i:8;O:8:"stdClass":3:{s:13:"license_level";s:5:"elite";s:7:"section";s:17:"search-statistics";s:7:"feature";s:16:"keyword-rankings";}i:9;O:8:"stdClass":3:{s:13:"license_level";s:5:"elite";s:7:"section";s:17:"search-statistics";s:7:"feature";s:22:"keyword-rankings-pages";}i:10;O:8:"stdClass":3:{s:13:"license_level";s:5:"elite";s:7:"section";s:17:"search-statistics";s:7:"feature";s:11:"post-detail";}i:11;O:8:"stdClass":3:{s:13:"license_level";s:5:"elite";s:7:"section";s:17:"search-statistics";s:7:"feature";s:22:"post-detail-page-speed";}i:12;O:8:"stdClass":3:{s:13:"license_level";s:5:"elite";s:7:"section";s:17:"search-statistics";s:7:"feature";s:26:"post-detail-seo-statistics";}i:13;O:8:"stdClass":3:{s:13:"license_level";s:5:"elite";s:7:"section";s:17:"search-statistics";s:7:"feature";s:20:"post-detail-keywords";}i:14;O:8:"stdClass":3:{s:13:"license_level";s:5:"elite";s:7:"section";s:17:"search-statistics";s:7:"feature";s:31:"post-detail-focus-keyword-trend";}i:15;O:8:"stdClass":3:{s:13:"license_level";s:5:"elite";s:7:"section";s:17:"search-statistics";s:7:"feature";s:16:"keyword-tracking";}i:16;O:8:"stdClass":3:{s:13:"license_level";s:5:"elite";s:7:"section";s:17:"search-statistics";s:7:"feature";s:28:"post-detail-keyword-tracking";}i:17;O:8:"stdClass":3:{s:13:"license_level";s:5:"elite";s:7:"section";s:17:"search-statistics";s:7:"feature";s:16:"content-rankings";}i:18;O:8:"stdClass":3:{s:13:"license_level";s:5:"elite";s:7:"section";s:13:"seo-revisions";s:7:"feature";s:12:"revisions:-1";}i:19;O:8:"stdClass":3:{s:13:"license_level";s:3:"pro";s:7:"section";s:13:"seo-revisions";s:7:"feature";s:12:"revisions:30";}i:20;O:8:"stdClass":3:{s:13:"license_level";s:4:"plus";s:7:"section";s:13:"seo-revisions";s:7:"feature";s:12:"revisions:15";}}', '2024-03-11 04:20:14', '2024-03-10 04:20:14', '2024-03-10 04:20:14') ;
INSERT INTO `wp_aioseo_cache` ( `id`, `key`, `value`, `expiration`, `created`, `updated`) VALUES
(6, 'admin_help_docs', 's:74036:"{"categories":{"getting-started":"Getting Started","advanced-settings":"Advanced Settings","display-settings":"Display Settings","general-seo-topics":"General SEO Topics","feature-manager":"Feature Manager","installation":"Installation"},"docs":{"294047":{"title":"Using the Query Arg Monitoring in All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/using-the-query-arg-monitoring-in-all-in-one-seo\\/","categories":["advanced-settings"]},"279241":{"title":"How to Schedule a Redirect in All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-schedule-a-redirect-in-all-in-one-seo\\/","categories":["redirection-manager"]},"269732":{"title":"Displaying Detailed Author Information on Your Site","url":"https:\\/\\/aioseo.com\\/docs\\/displaying-detailed-author-information-on-your-site\\/","categories":["author-seo","content-blocks"]},"267254":{"title":"Adding Author SEO (E-E-A-T) to Your Site","url":"https:\\/\\/aioseo.com\\/docs\\/adding-author-seo-e-e-a-t-to-your-site\\/","categories":["author-seo"]},"262344":{"title":"How to Get Your Images to Appear in Search Results","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-get-your-images-to-appear-in-search-results\\/","categories":["frequently-asked-questions","general-seo-topics","image-seo"]},"261932":{"title":"Sharing Content on Slack","url":"https:\\/\\/aioseo.com\\/docs\\/sharing-content-on-slack\\/","categories":["social-networks"]},"261923":{"title":"Sharing Content on WhatsApp","url":"https:\\/\\/aioseo.com\\/docs\\/sharing-content-on-whatsapp\\/","categories":["social-networks"]},"261517":{"title":"Importing Locations From Other Plugins","url":"https:\\/\\/aioseo.com\\/docs\\/importing-locations-from-other-plugins\\/","categories":["importer-exporter","local-business-seo"]},"244975":{"title":"Checking the Index Status of Content","url":"https:\\/\\/aioseo.com\\/docs\\/checking-the-index-status-of-content\\/","categories":["post-page-settings","search-statistics"]},"242346":{"title":"Using AIOSEO Details on the Posts Screen","url":"https:\\/\\/aioseo.com\\/docs\\/using-aioseo-details-on-the-posts-screen\\/","categories":["category-tag-settings","post-page-settings"]},"240583":{"title":"Setting WP_HOME and WP_SITEURL in the wp-config.php File","url":"https:\\/\\/aioseo.com\\/docs\\/setting-wp_home-and-wp_siteurl-in-the-wp-config-php-file\\/","categories":["troubleshooting"]},"240452":{"title":"Should I Use Meta Keywords?","url":"https:\\/\\/aioseo.com\\/docs\\/should-i-use-meta-keywords\\/","categories":["frequently-asked-questions","general-seo-topics"]},"235044":{"title":"Setting Cornerstone Content in All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/cornerstone-content\\/","categories":["link-assistant","post-page-settings"]},"222363":{"title":"aioseo_get_post_id","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_get_post_id\\/","categories":["filter-hooks"]},"200603":{"title":"Viewing Detailed Search Statistics For Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/viewing-detailed-search-statistics-for-your-content\\/","categories":["search-statistics"]},"200304":{"title":"Tracking Changes to Your SEO Using SEO Revisions","url":"https:\\/\\/aioseo.com\\/docs\\/tracking-changes-to-your-seo-using-seo-revisions\\/","categories":["seo-revisions"]},"188167":{"title":"WPCode Snippet Library","url":"https:\\/\\/aioseo.com\\/docs\\/wpcode-snippet-library\\/","categories":["tools"]},"186946":{"title":"aioseo_hide_version_number","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_hide_version_number\\/","categories":["filter-hooks"]},"178887":{"title":"Setting the Primary Term for Breadcrumbs","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-primary-term-for-breadcrumbs\\/","categories":["breadcrumbs"]},"178727":{"title":"Using Broken Link Checker to Find and Fix Broken Links and Images","url":"https:\\/\\/aioseo.com\\/docs\\/using-broken-link-checker-to-find-and-fix-broken-links-and-images\\/","categories":["broken-link-checker"]},"163922":{"title":"aioseo_schema_json_flags","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_schema_json_flags\\/","categories":["filter-hooks"]},"163519":{"title":"Using OpenAI to Generate SEO Titles and Meta Descriptions","url":"https:\\/\\/aioseo.com\\/docs\\/using-openai-to-generate-seo-titles-and-meta-descriptions\\/","categories":[]},"145363":{"title":"Using the Search Statistics in All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/using-the-search-statistics-in-all-in-one-seo\\/","categories":["google-search-console","search-statistics"]},"145281":{"title":"Connecting Search Statistics to Google Search Console","url":"https:\\/\\/aioseo.com\\/docs\\/connecting-search-statistics-to-google-search-console\\/","categories":["google-search-console","search-statistics"]},"139798":{"title":"Checking Your SEO Using the SEO Preview","url":"https:\\/\\/aioseo.com\\/docs\\/checking-your-seo-using-the-seo-preview\\/","categories":["facebook-settings","post-page-settings","seo-preview","truseo","twitter-settings"]},"136509":{"title":"aioseo_sitemap_lastmod_disable","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_sitemap_lastmod_disable\\/","categories":["filter-hooks"]},"135249":{"title":"aioseo_sitemap_rss","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_sitemap_rss\\/","categories":["filter-hooks"]},"133251":{"title":"aioseo_user_profile_tab_disable","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_user_profile_tab_disable\\/","categories":["filter-hooks"]},"131885":{"title":"Setting Web Page Schema Markup in Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-web-page-schema-markup-in-your-content\\/","categories":["schema-settings"]},"129515":{"title":"Editing the .htaccess file Using All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/editing-the-htaccess-file-using-all-in-one-seo\\/","categories":["file-editor","tools"]},"124292":{"title":"Using the Emojis in Titles and Descriptions","url":"https:\\/\\/aioseo.com\\/docs\\/using-the-emojis-in-titles-and-descriptions\\/","categories":["facebook-settings","post-page-settings","search-appearance","social-networks","twitter-settings"]},"123164":{"title":"Google Permissions for the AIOSEO Google Search Console Integration","url":"https:\\/\\/aioseo.com\\/docs\\/google-permissions-for-oauth\\/","categories":["google-search-console","search-statistics"]},"112137":{"title":"Setting the Schema Type for Individual Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-schema-type-for-individual-content\\/","categories":["schema-settings"]},"112145":{"title":"Configuring the Schema Settings in All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/configuring-the-schema-settings-in-all-in-one-seo\\/","categories":["schema-settings"]},"112153":{"title":"A Guide to Schema.org Markup for Rich Snippets","url":"https:\\/\\/aioseo.com\\/docs\\/a-guide-to-schema-org-markup-for-rich-snippets\\/","categories":["schema-settings"]},"112438":{"title":"Creating Reusable Schema Templates in All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/creating-reusable-schema-templates-in-all-in-one-seo\\/","categories":["schema-settings"]},"112428":{"title":"Creating Custom Schema Markup with All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/creating-custom-schema-markup-with-all-in-one-seo\\/","categories":["schema-settings"]},"112889":{"title":"Setting Event Schema Markup in Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-event-schema-markup-in-your-content\\/","categories":["schema-settings"]},"112735":{"title":"Setting Dataset Schema Markup in Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-dataset-schema-markup-in-your-content\\/","categories":["schema-settings"]},"112711":{"title":"Setting Article Schema Markup in Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-article-schema-markup-in-your-content\\/","categories":["schema-settings"]},"112164":{"title":"Setting Course Schema Markup in Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-course-schema-markup-in-your-content\\/","categories":["schema-settings"]},"112933":{"title":"Setting Job Posting Schema Markup in Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-job-posting-schema-markup-in-your-content\\/","categories":["schema-settings"]},"112926":{"title":"Setting How-To Schema Markup in Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-how-to-schema-markup-in-your-content\\/","categories":["schema-settings"]},"112916":{"title":"Setting Fact Check Schema Markup in Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-fact-check-schema-markup-in-your-content\\/","categories":["schema-settings"]},"112727":{"title":"Setting Book Schema Markup in Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-book-schema-markup-in-your-content\\/","categories":["schema-settings"]},"112243":{"title":"Setting FAQ Schema Markup in Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-faq-page-schema-markup-in-your-content\\/","categories":["schema-settings"]},"112958":{"title":"Setting Service Schema Markup in Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-service-schema-markup-in-your-content\\/","categories":["schema-settings"]},"112949":{"title":"Setting Person Schema Markup in Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-person-schema-markup-in-your-content\\/","categories":["schema-settings"]},"112944":{"title":"Setting Music Schema Markup in Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-music-schema-markup-in-your-content\\/","categories":["schema-settings"]},"112941":{"title":"Setting Movie Schema Markup in Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-movie-schema-markup-in-your-content\\/","categories":["schema-settings"]},"112212":{"title":"Setting Recipe Schema Markup in Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-recipe-schema-markup-in-your-content\\/","categories":["schema-settings"]},"112962":{"title":"Setting Video Schema Markup in Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-video-schema-markup-in-your-content\\/","categories":["schema-settings"]},"112403":{"title":"Testing Your Schema in All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/testing-your-schema-in-all-in-one-seo\\/","categories":["schema-settings"]},"112226":{"title":"Setting Software Application Schema Markup in Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-software-application-schema-markup-in-your-content\\/","categories":["schema-settings"]},"112197":{"title":"Setting Product Schema Markup in Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-product-schema-markup-in-your-content\\/","categories":["schema-settings"]},"119555":{"title":"How to Use the AIOSEO Feature Manager on a Multisite Network","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-use-the-aioseo-feature-manager-on-a-multisite-network\\/","categories":["feature-manager","multisite-networks"]},"119550":{"title":"How to Reset the AIOSEO Site Settings on a Multisite Network","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-reset-the-aioseo-site-settings-on-a-multisite-network\\/","categories":["multisite-networks","network-tools"]},"119543":{"title":"How to Backup and Restore AIOSEO Site Settings on a Multisite Network","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-backup-and-restore-aioseo-site-settings-on-a-multisite-network\\/","categories":["multisite-networks","network-tools"]},"119531":{"title":"How to Import Settings from Other Plugins on a Multisite Network","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-import-settings-from-other-plugins-on-a-multisite-network\\/","categories":["multisite-networks","network-tools"]},"119519":{"title":"How to Import and Export AIOSEO Settings and Meta Data on a Multisite Network","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-import-and-export-aioseo-settings-and-meta-data-on-a-multisite-network\\/","categories":["multisite-networks","network-tools"]},"119497":{"title":"How to Add Your AIOSEO License Key on a WordPress Multisite Network","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-add-your-aioseo-license-key-on-a-wordpress-multisite-network\\/","categories":["multisite-networks","network-settings"]},"111476":{"title":"Displaying a List of Locations on Your Site","url":"https:\\/\\/aioseo.com\\/docs\\/displaying-a-list-of-locations-on-your-site\\/","categories":["content-blocks","local-business-seo"]},"111473":{"title":"Displaying Your Business Location Information on Your Site","url":"https:\\/\\/aioseo.com\\/docs\\/displaying-your-business-location-information-on-your-site\\/","categories":["content-blocks","local-business-seo"]},"111459":{"title":"Displaying Opening Hours on Your Site","url":"https:\\/\\/aioseo.com\\/docs\\/displaying-opening-hours-on-your-site\\/","categories":["content-blocks","local-business-seo"]},"111455":{"title":"Adding a Map of Your Location to Your Site","url":"https:\\/\\/aioseo.com\\/docs\\/adding-a-map-of-your-location-to-your-site\\/","categories":["content-blocks","local-business-seo"]},"111450":{"title":"Adding Breadcrumbs to Your Site Using the AIOSEO Breadcrumbs Block","url":"https:\\/\\/aioseo.com\\/docs\\/adding-breadcrumbs-to-your-site-using-the-aioseo-breadcrumbs-block\\/","categories":["breadcrumbs","content-blocks"]},"109878":{"title":"Adding a Redirect When You Delete Content","url":"https:\\/\\/aioseo.com\\/docs\\/adding-a-redirect-when-you-delete-content\\/","categories":["redirection-manager"]},"109829":{"title":"Redirecting 404 Content Not Found Using All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/redirecting-404-content-not-found-using-all-in-one-seo\\/","categories":["redirection-manager"]},"109916":{"title":"Using the Image SEO Features in All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/using-the-image-seo-features-in-all-in-one-seo\\/","categories":["image-seo"]},"104857":{"title":"Adding a Table of Contents to Your Site Using All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/adding-a-table-of-contents-to-your-site-using-all-in-one-seo\\/","categories":["content-blocks"]},"104616":{"title":"Adding FAQs to Your Site Using All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/adding-faqs-to-your-site-using-all-in-one-seo\\/","categories":["content-blocks"]},"104595":{"title":"Automatic Redirects When Changing the Post Slug","url":"https:\\/\\/aioseo.com\\/docs\\/automatic-redirects-when-changing-the-post-slug\\/","categories":["redirection-manager"]},"103415":{"title":"Removing Published Date from Article Schema","url":"https:\\/\\/aioseo.com\\/docs\\/removing-published-date-from-article-schema\\/","categories":["developer-documentation"]},"101250":{"title":"Outputting AIOSEO\'s data in the HEAD without using wp_head()","url":"https:\\/\\/aioseo.com\\/docs\\/outputting-aioseos-data-in-the-head-without-using-wp_head\\/","categories":["developer-documentation"]},"100154":{"title":"Automatic Redirects When You Delete Content","url":"https:\\/\\/aioseo.com\\/docs\\/automatic-redirects-when-you-delete-content\\/","categories":["redirection-manager"]},"98532":{"title":"Localizing AIOSEO Data via the Translations API","url":"https:\\/\\/aioseo.com\\/docs\\/localizing-aioseo-data-via-the-translations-api\\/","categories":["developer-documentation"]},"98576":{"title":"aioseo_sitemap_term","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_sitemap_term\\/","categories":["filter-hooks"]},"98575":{"title":"aioseo_sitemap_post","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_sitemap_post\\/","categories":["filter-hooks"]},"98566":{"title":"aioseo_save_term","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_save_term\\/","categories":["filter-hooks"]},"98565":{"title":"aioseo_save_post","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_save_post\\/","categories":["filter-hooks"]},"98557":{"title":"aioseo_get_term","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_get_term\\/","categories":["filter-hooks"]},"98554":{"title":"aioseo_get_post","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_get_post\\/","categories":["filter-hooks"]},"93967":{"title":"Importing URLs into the XML Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/importing-urls-into-the-xml-sitemap\\/","categories":["xml-sitemap"]},"93822":{"title":"How to Use Crawl Cleanup to Increase Search Engine Crawl Quota","url":"https:\\/\\/aioseo.com\\/docs\\/crawl-cleanup-best-practices\\/","categories":["advanced-settings"]},"90584":{"title":"How to Add a Temporary Administrator Login to Your Site","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-add-a-temporary-administrator-login-to-your-site\\/","categories":["frequently-asked-questions","troubleshooting"]},"88927":{"title":"Dashboard Widgets in All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/dashboard-widgets-in-all-in-one-seo\\/","categories":["dashboard"]},"86198":{"title":"How to Strip the Category Base in WordPress","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-strip-the-category-base-in-wordpress\\/","categories":["category-tag-settings"]},"84322":{"title":"Running shortcodes in All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/running-shortcodes\\/","categories":["advanced-settings"]},"84156":{"title":"Translating Your SEO with WPML","url":"https:\\/\\/aioseo.com\\/docs\\/translating-your-seo-with-wpml\\/","categories":["post-page-settings"]},"80219":{"title":"How to Verify Your Site with Microsoft Clarity","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-verify-your-site-with-microsoft-clarity\\/","categories":["webmaster-tools"]},"79928":{"title":"How to Handle Issues With Installing All in One SEO Pro","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-handle-issues-with-installing-all-in-one-seo-pro\\/","categories":["installation"]},"79149":{"title":"Fetching &amp; Updating AIOSEO Data via the WordPress REST API","url":"https:\\/\\/aioseo.com\\/docs\\/fetching-updating-aioseo-data-via-the-wordpress-rest-api\\/","categories":["developer-documentation","rest-api"]},"77593":{"title":"How To Fix JavaScript Errors","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-fix-javascript-errors\\/","categories":["troubleshooting"]},"77589":{"title":"Browser Support Policy","url":"https:\\/\\/aioseo.com\\/docs\\/browser-support-policy\\/","categories":["frequently-asked-questions"]},"75143":{"title":"How to Redirect a Post from the Edit Post Screen","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-redirect-a-post-from-the-edit-post-screen\\/","categories":["post-page-settings","redirection-manager"]},"75686":{"title":"Preventing the Modified Date for Content from Changing","url":"https:\\/\\/aioseo.com\\/docs\\/preventing-the-modified-date-for-content-from-changing\\/","categories":["post-page-settings"]},"73002":{"title":"Page Builder Integrations","url":"https:\\/\\/aioseo.com\\/docs\\/page-builder-integrations\\/","categories":["home-page-settings","post-page-settings","third-party-integrations","truseo"]},"73003":{"title":"Integrating with IndexNow to Instantly Re-index Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/integrating-with-indexnow-to-instantly-re-index-your-content\\/","categories":["indexnow","webmaster-tools"]},"72711":{"title":"aioseo_page_builder_integration_disable","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_page_builder_integration_disable\\/","categories":["filter-hooks"]},"68444":{"title":"An Introduction to Link Assistant \\u2014 The Easy Way to Manage Onsite Links","url":"https:\\/\\/aioseo.com\\/docs\\/introduction-to-link-assistant\\/","categories":["link-assistant"]},"69559":{"title":"Using the Link Assistant in All in One SEO Pro","url":"https:\\/\\/aioseo.com\\/docs\\/link-assistant\\/","categories":["link-assistant"]},"69594":{"title":"Internal Links in the Links Report in Link Assistant","url":"https:\\/\\/aioseo.com\\/docs\\/internal-links-in-the-links-report-in-link-assistant\\/","categories":["link-assistant"]},"69596":{"title":"External Links in the Links Report in Link Assistant","url":"https:\\/\\/aioseo.com\\/docs\\/external-links-in-the-links-report-in-link-assistant\\/","categories":["link-assistant"]},"69921":{"title":"Link Suggestions in the Links Report in Link Assistant","url":"https:\\/\\/aioseo.com\\/docs\\/link-suggestions-in-the-links-report-in-link-assistant\\/","categories":["link-assistant"]},"69602":{"title":"Affiliate Links in the Links Report in Link Assistant","url":"https:\\/\\/aioseo.com\\/docs\\/affiliate-links-in-the-links-report-in-link-assistant\\/","categories":["link-assistant"]},"69761":{"title":"Using the Domains Report in Link Assistant","url":"https:\\/\\/aioseo.com\\/docs\\/using-the-domains-report-in-link-assistant\\/","categories":["link-assistant"]},"69770":{"title":"Link Assistant Settings","url":"https:\\/\\/aioseo.com\\/docs\\/link-assistant-settings\\/","categories":["link-assistant"]},"68431":{"title":"aioseo_sitemap_images","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_sitemap_images\\/","categories":["filter-hooks"]},"66833":{"title":"Why Is N\\/A Displayed Instead of a Score For My Content?","url":"https:\\/\\/aioseo.com\\/docs\\/why-is-na-displayed-instead-of-a-score-for-my-content\\/","categories":["frequently-asked-questions","truseo"]},"18824":{"title":"Local Business SEO for a Single Location","url":"https:\\/\\/aioseo.com\\/docs\\/local-business-seo-for-a-single-location\\/","categories":["local-business-seo","schema-settings"]},"35828":{"title":"Local Business SEO for Multiple Locations","url":"https:\\/\\/aioseo.com\\/docs\\/local-business-seo-for-multiple-locations\\/","categories":["local-business-seo"]},"58476":{"title":"aioseo_public_taxonomies","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_public_taxonomies\\/","categories":["filter-hooks"]},"58475":{"title":"aioseo_public_post_types","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_public_post_types\\/","categories":["filter-hooks"]},"64776":{"title":"How Long Does it Take For My Content to Appear on Google?","url":"https:\\/\\/aioseo.com\\/docs\\/how-long-does-it-take-for-my-content-to-appear-on-google\\/","categories":["frequently-asked-questions"]},"35926":{"title":"Adding a Location in Local SEO Addon","url":"https:\\/\\/aioseo.com\\/docs\\/adding-a-location-in-local-seo-addon\\/","categories":["local-business-seo"]},"61020":{"title":"How to Display a Favicon in Search Results","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-display-a-favicon-in-search-results\\/","categories":["frequently-asked-questions","general-seo-topics"]},"35956":{"title":"Displaying Locations on Your Site","url":"https:\\/\\/aioseo.com\\/docs\\/displaying-locations-on-your-site\\/","categories":["local-business-seo"]},"56330":{"title":"aioseo_sitemap_indexes","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_sitemap_indexes\\/","categories":["filter-hooks"]},"56011":{"title":"Redirect Manager - Configuration Reload","url":"https:\\/\\/aioseo.com\\/docs\\/redirect-manager-configuration-reload\\/","categories":["redirection-manager"]},"52689":{"title":"aioseo_flyout_menu_enable","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_flyout_menu_disable\\/","categories":["filter-hooks"]},"45698":{"title":"Displaying your Business Information and Star Ratings on a Map","url":"https:\\/\\/aioseo.com\\/docs\\/using-places-on-your-maps\\/","categories":["local-business-seo"]},"49268":{"title":"aioseo_access_control_excluded_roles","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_access_control_excluded_roles\\/","categories":["filter-hooks"]},"44555":{"title":"Setting up Google Maps for Local SEO","url":"https:\\/\\/aioseo.com\\/docs\\/setting-up-google-maps\\/","categories":["local-business-seo"]},"48189":{"title":"How to Create an HTML Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/html-sitemap\\/","categories":["html-sitemap"]},"48365":{"title":"Using a Widget to Display Your HTML Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/using-a-widget-to-display-your-html-sitemap\\/","categories":["html-sitemap"]},"48361":{"title":"Using PHP Code to Display Your HTML Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/function-html-sitemap\\/","categories":["html-sitemap"]},"48260":{"title":"Using a Block to Display Your HTML Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/using-a-block-to-display-your-html-sitemap\\/","categories":["content-blocks","html-sitemap"]},"48222":{"title":"aioseo_breadcrumbs_separator_symbol","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_breadcrumbs_separator_symbol\\/","categories":["filter-hooks"]},"48227":{"title":"aioseo_breadcrumbs_template","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_breadcrumbs_template\\/","categories":["filter-hooks"]},"48231":{"title":"aioseo_breadcrumbs_trail","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_breadcrumbs_trail\\/","categories":["filter-hooks"]},"48232":{"title":"aioseo_breadcrumbs_link_current_item","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_breadcrumbs_link_current_item\\/","categories":["filter-hooks"]},"48233":{"title":"aioseo_breadcrumbs_show_current_item","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_breadcrumbs_show_current_item\\/","categories":["filter-hooks"]},"48219":{"title":"aioseo_breadcrumbs_output","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_breadcrumbs_output\\/","categories":["filter-hooks"]},"48223":{"title":"aioseo_breadcrumbs_separator","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_breadcrumbs_separator\\/","categories":["filter-hooks"]},"48238":{"title":"Using a Shortcode to Display Your HTML Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/shortcode-html-sitemap\\/","categories":["html-sitemap"]},"45805":{"title":"aioseo_sitemap_exclude_terms","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_sitemap_exclude_terms\\/","categories":["filter-hooks"]},"45804":{"title":"aioseo_sitemap_exclude_posts","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_sitemap_exclude_posts\\/","categories":["filter-hooks"]},"61002":{"title":"How to Create a Google Maps API Key","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-create-a-google-maps-api-key\\/","categories":["local-business-seo"]},"45528":{"title":"aioseo_schema_output","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_schema_output\\/","categories":["filter-hooks"]},"42995":{"title":"Using the Headline Analyzer in All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/using-the-headline-analyzer-in-all-in-one-seo\\/","categories":["headline-analyzer"]},"42683":{"title":"How to Perform a Full Site Redirect","url":"https:\\/\\/aioseo.com\\/docs\\/full-site-redirects\\/","categories":["redirection-manager"]},"50988":{"title":"Displaying Maps on Your Site","url":"https:\\/\\/aioseo.com\\/docs\\/displaying-maps-on-your-site\\/","categories":["local-business-seo"]},"42999":{"title":"How to Disable the Headline Analyzer","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-disable-the-headline-analyzer\\/","categories":["advanced-settings","headline-analyzer"]},"42975":{"title":"Installing Addons for All in One SEO Pro","url":"https:\\/\\/aioseo.com\\/docs\\/installing-addons-for-all-in-one-seo-pro\\/","categories":["installation"]},"42854":{"title":"Creating a Pass Through Redirect","url":"https:\\/\\/aioseo.com\\/docs\\/creating-a-pass-through-redirect\\/","categories":["redirection-manager"]},"41800":{"title":"Using Custom Rules in the Redirection Manager","url":"https:\\/\\/aioseo.com\\/docs\\/redirection-manager-custom-rules\\/","categories":["redirection-manager"]},"42224":{"title":"Resetting the Settings in All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/resetting-the-settings-in-all-in-one-seo\\/","categories":["database-tools","tools"]},"41884":{"title":"Setting the Site Name for Facebook","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-site-name-for-facebook\\/","categories":["facebook-settings","social-networks"]},"41862":{"title":"How to Get Google to Display the Sitelinks Search Box","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-get-google-to-display-the-sitelinks-search-box\\/","categories":["schema-settings"]},"41851":{"title":"Setting the SEO Title and Description Format for the Search Results Page","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-title-and-description-format-for-the-search-results-page\\/","categories":["content-type-settings","search-appearance"]},"41811":{"title":"SEO Analysis Unable to Connect to Your Site","url":"https:\\/\\/aioseo.com\\/docs\\/seo-analysis-unable-to-connect-to-your-site\\/","categories":["seo-analysis","troubleshooting"]},"41280":{"title":"How to Renew Your AIOSEO License","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-renew-your-aioseo-license\\/","categories":["frequently-asked-questions","getting-started"]},"41077":{"title":"Update WordPress: WordPress Versions Supported by AIOSEO","url":"https:\\/\\/aioseo.com\\/docs\\/update-wordpress\\/","categories":["troubleshooting"]},"40587":{"title":"How to Open the Browser Error Console","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-open-the-browser-error-console\\/","categories":["troubleshooting"]},"40582":{"title":"How to Enable Debugging in WordPress","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-enable-debugging-in-wordpress\\/","categories":["troubleshooting"]},"40148":{"title":"What is TruSEO?","url":"https:\\/\\/aioseo.com\\/docs\\/what-is-truseo\\/","categories":["frequently-asked-questions","truseo"]},"39494":{"title":"Redirecting Attachment Pages","url":"https:\\/\\/aioseo.com\\/docs\\/redirecting-attachment-pages\\/","categories":["media-settings","search-appearance"]},"66310":{"title":"Selecting the Google Maps APIs to use with All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/selecting-the-google-maps-apis-to-use-with-all-in-one-seo\\/","categories":["local-business-seo"]},"38915":{"title":"Setting Up and Using Breadcrumbs Templates","url":"https:\\/\\/aioseo.com\\/docs\\/setting-up-and-using-breadcrumbs-templates\\/","categories":["breadcrumbs"]},"38610":{"title":"Displaying Breadcrumbs On Your Site","url":"https:\\/\\/aioseo.com\\/docs\\/displaying-breadcrumbs-on-your-site\\/","categories":["breadcrumbs"]},"36048":{"title":"Function: aioseo_breadcrumbs()","url":"https:\\/\\/aioseo.com\\/docs\\/function-aioseo_breadcrumbs\\/","categories":["breadcrumbs"]},"36047":{"title":"Shortcode: [aioseo_breadcrumbs]","url":"https:\\/\\/aioseo.com\\/docs\\/shortcode-aioseo_breadcrumbs\\/","categories":["breadcrumbs"]},"38240":{"title":"aioseo_social_image_ignore_cover_block","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_social_image_ignore_cover_block\\/","categories":["filter-hooks"]},"37961":{"title":"aioseo_classic_editor_disable_emoji_script","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_classic_editor_disable_emoji_script\\/","categories":["filter-hooks"]},"34923":{"title":"How to Redirect a Post or Page in All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-redirect-a-post-or-page-in-all-in-one-seo\\/","categories":["redirection-manager"]},"34977":{"title":"How to Redirect Multiple URLs to the Same Destination","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-redirect-multiple-urls-to-the-same-destination\\/","categories":["redirection-manager"]},"35604":{"title":"Automatic Redirects When URLs Change in Content","url":"https:\\/\\/aioseo.com\\/docs\\/automatic-redirects-when-urls-change-in-content\\/","categories":["redirection-manager"]},"31460":{"title":"Enhanced Search Query Conflict","url":"https:\\/\\/aioseo.com\\/docs\\/enhanced-search-query-conflict\\/","categories":["local-business-seo"]},"30850":{"title":"aioseo_local_business_info_email_icon","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_info_email_icon\\/","categories":["filter-hooks"]},"30839":{"title":"aioseo_local_business_info_location_icon","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_info_location_icon\\/","categories":["filter-hooks"]},"30756":{"title":"aioseo_local_business_get_locations_by_category_posts","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_get_locations_by_category_posts\\/","categories":["filter-hooks"]},"30755":{"title":"aioseo_local_business_get_locations_by_category_args","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_get_locations_by_category_args\\/","categories":["filter-hooks"]},"30754":{"title":"aioseo_local_business_get_location_categories","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_get_location_categories\\/","categories":["filter-hooks"]},"30751":{"title":"aioseo_local_business_get_locations_posts","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_get_locations_posts\\/","categories":["filter-hooks"]},"30753":{"title":"aioseo_local_business_get_location_category_args","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_get_location_category_args\\/","categories":["filter-hooks"]},"30759":{"title":"aioseo_local_business_output_business_info_instance","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_output_business_info_instance\\/","categories":["filter-hooks"]},"30760":{"title":"aioseo_local_business_output_business_info_location_data","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_output_business_info_location_data\\/","categories":["filter-hooks"]},"30761":{"title":"aioseo_local_business_output_location_category_instance","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_output_location_category_instance\\/","categories":["filter-hooks"]},"30764":{"title":"aioseo_local_business_output_location_category_location_data","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_output_location_category_location_data\\/","categories":["filter-hooks"]},"30765":{"title":"aioseo_local_business_output_opening_hours_instance","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_output_opening_hours_instance\\/","categories":["filter-hooks"]},"30766":{"title":"aioseo_local_business_output_opening_hours_data","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_output_opening_hours_data\\/","categories":["filter-hooks"]},"30849":{"title":"aioseo_local_business_info_phone_icon","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_info_phone_icon\\/","categories":["filter-hooks"]},"30851":{"title":"aioseo_local_business_opening_hours_icon","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_opening_hours_icon\\/","categories":["filter-hooks"]},"30398":{"title":"aioseo_local_business_post_type_name","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_post_type_name\\/","categories":["filter-hooks"]},"30551":{"title":"aioseo_local_business_post_type_slug","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_post_type_slug\\/","categories":["filter-hooks"]},"30556":{"title":"aioseo_local_business_post_type_single_label","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_post_type_single_label\\/","categories":["filter-hooks"]},"30559":{"title":"aioseo_local_business_post_type_plural_label","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_post_type_plural_label\\/","categories":["filter-hooks"]},"30560":{"title":"aioseo_local_business_post_type","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_post_type\\/","categories":["filter-hooks"]},"30563":{"title":"aioseo_local_business_taxonomy_name","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_taxonomy_name\\/","categories":["filter-hooks"]},"30564":{"title":"aioseo_local_business_taxonomy_slug","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_taxonomy_slug\\/","categories":["filter-hooks"]},"35609":{"title":"Choosing Which Redirect Type to Use","url":"https:\\/\\/aioseo.com\\/docs\\/choosing-which-redirect-type-to-use\\/","categories":["redirection-manager"]},"35599":{"title":"Importing Redirects From Other Plugins","url":"https:\\/\\/aioseo.com\\/docs\\/importing-redirects-from-other-plugins\\/","categories":["redirection-manager"]},"35588":{"title":"Exporting and Importing Redirects","url":"https:\\/\\/aioseo.com\\/docs\\/exporting-and-importing-redirects\\/","categories":["redirection-manager"]},"35579":{"title":"Logging 404 Errors in All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/logging-404-errors-in-all-in-one-seo\\/","categories":["redirection-manager"]},"35552":{"title":"Logging Redirects in All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/logging-redirects-in-all-in-one-seo\\/","categories":["redirection-manager"]},"35570":{"title":"Redirect GDPR Privacy Information","url":"https:\\/\\/aioseo.com\\/docs\\/redirect-gdpr-privacy-information\\/","categories":["redirection-manager"]},"30863":{"title":"Local Business SEO - Template overrides","url":"https:\\/\\/aioseo.com\\/docs\\/local-business-seo-template-overrides\\/","categories":["local-business-seo"]},"35133":{"title":"aioseo_twitter_tags","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_twitter_tags\\/","categories":["filter-hooks"]},"35132":{"title":"aioseo_facebook_tags","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_facebook_tags\\/","categories":["filter-hooks"]},"34993":{"title":"Ignoring Case Sensitivity in Redirects","url":"https:\\/\\/aioseo.com\\/docs\\/ignoring-case-sensitivity-in-redirects\\/","categories":["redirection-manager"]},"34983":{"title":"Ignoring the Trailing Slash in Redirects","url":"https:\\/\\/aioseo.com\\/docs\\/ignoring-the-trailing-slash-in-redirects\\/","categories":["redirection-manager"]},"36104":{"title":"Using Query Parameters With Redirects","url":"https:\\/\\/aioseo.com\\/docs\\/using-query-parameters-with-redirects\\/","categories":["redirection-manager"]},"30565":{"title":"aioseo_local_business_taxonomy","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_taxonomy\\/","categories":["filter-hooks"]},"36115":{"title":"Caching of Redirects in the Browser","url":"https:\\/\\/aioseo.com\\/docs\\/caching-of-redirects-in-the-browser\\/","categories":["redirection-manager"]},"34701":{"title":"Adding WooCommerce Product Attributes to SEO Title or Description","url":"https:\\/\\/aioseo.com\\/docs\\/adding-woocommerce-product-attributes-to-seo-title-or-description\\/","categories":["post-page-settings","search-appearance","woocommerce"]},"36111":{"title":"Selecting the Redirect Method in Redirects","url":"https:\\/\\/aioseo.com\\/docs\\/selecting-the-redirect-method-in-redirects\\/","categories":["redirection-manager"]},"40115":{"title":"Redirect Manager Cannot Detect Your Server","url":"https:\\/\\/aioseo.com\\/docs\\/redirect-manager-unknown-web-server\\/","categories":["redirection-manager"]},"36369":{"title":"Using Regex in the Redirection Manager","url":"https:\\/\\/aioseo.com\\/docs\\/redirect-manager-regex\\/","categories":["redirection-manager"]},"31442":{"title":"Shortcode: [aioseo_local_opening_hours]","url":"https:\\/\\/aioseo.com\\/docs\\/shortcode-aioseo_local_opening_hours\\/","categories":["local-business-seo"]},"31443":{"title":"Shortcode: [aioseo_local_locations]","url":"https:\\/\\/aioseo.com\\/docs\\/shortcode-aioseo_local_locations\\/","categories":["local-business-seo"]},"34179":{"title":"Using the Smart Tags in Titles and Descriptions","url":"https:\\/\\/aioseo.com\\/docs\\/using-the-smart-tags-in-titles-and-descriptions\\/","categories":["post-page-settings","search-appearance"]},"31441":{"title":"Shortcode: [aioseo_local_business_info]","url":"https:\\/\\/aioseo.com\\/docs\\/shortcode-aioseo_local_business_info\\/","categories":["local-business-seo"]},"46122":{"title":"Shortcode: [aioseo_local_map]","url":"https:\\/\\/aioseo.com\\/docs\\/shortcode-aioseo_local_map\\/","categories":["local-business-seo"]},"33507":{"title":"What\'s The Difference Between TruSEO and Page Analysis?","url":"https:\\/\\/aioseo.com\\/docs\\/whats-the-difference-between-truseo-and-page-analysis\\/","categories":["frequently-asked-questions","post-page-settings","truseo"]},"33310":{"title":"Setting Noindex for RSS Feeds","url":"https:\\/\\/aioseo.com\\/docs\\/setting-noindex-for-rss-feeds\\/","categories":["advanced-settings","search-appearance"]},"33130":{"title":"aioseo_disable_shortcode_parsing","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_disable_shortcode_parsing\\/","categories":["filter-hooks"]},"32085":{"title":"aioseo_conflicting_shortcodes","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_conflicting_shortcodes\\/","categories":["filter-hooks"]},"31992":{"title":"aioseo_schema_graphs","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_schema_graphs\\/","categories":["filter-hooks"]},"31589":{"title":"Understanding the TruSEO Page Analysis Recommendations","url":"https:\\/\\/aioseo.com\\/docs\\/understanding-the-truseo-page-analysis-recommendations\\/","categories":["post-page-settings","truseo"]},"31456":{"title":"Function: aioseo_local_locations()","url":"https:\\/\\/aioseo.com\\/docs\\/function-aioseo_local_locations\\/","categories":["local-business-seo"]},"31455":{"title":"Function: aioseo_local_opening_hours()","url":"https:\\/\\/aioseo.com\\/docs\\/function-aioseo_local_opening_hours\\/","categories":["local-business-seo"]},"31451":{"title":"Function: aioseo_local_business_info()","url":"https:\\/\\/aioseo.com\\/docs\\/function-aioseo_local_business_info\\/","categories":["local-business-seo"]},"46123":{"title":"Function: aioseo_local_map()","url":"https:\\/\\/aioseo.com\\/docs\\/function-aioseo_local_map\\/","categories":["local-business-seo"]},"31042":{"title":"Getting Keyphrase Suggestions From Semrush","url":"https:\\/\\/aioseo.com\\/docs\\/getting-keyphrase-suggestions-from-semrush\\/","categories":["post-page-settings","truseo"]},"30773":{"title":"aioseo_local_business_address_tag_value","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_address_tag_value\\/","categories":["filter-hooks"]},"30770":{"title":"aioseo_local_business_address_tags","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_address_tags\\/","categories":["filter-hooks"]},"30567":{"title":"aioseo_local_business_get_locations_args","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_get_locations_args\\/","categories":["filter-hooks"]},"30752":{"title":"aioseo_local_business_get_location","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_local_business_get_location\\/","categories":["filter-hooks"]},"30728":{"title":"Unable to Save Settings Due to Cloudflare Firewall Rules","url":"https:\\/\\/aioseo.com\\/docs\\/unable-to-save-settings-due-to-cloudflare-firewall-rules\\/","categories":["troubleshooting"]},"30318":{"title":"aioseo_flush_output_buffer","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_flush_output_buffer\\/","categories":["filter-hooks"]},"18813":{"title":"Installing All in One SEO Pro","url":"https:\\/\\/aioseo.com\\/docs\\/installing-all-in-one-seo-pro\\/","categories":["getting-started","installation"]},"18973":{"title":"Beginners Guide for All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/quick-start-guide\\/","categories":["getting-started"]},"18820":{"title":"Setting the SEO Title and Description for Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-title-and-description-for-your-content\\/","categories":["getting-started","post-page-settings"]},"18902":{"title":"How to Create an XML Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-create-an-xml-sitemap\\/","categories":["getting-started","xml-sitemap"]},"18859":{"title":"Beginners Guide to Social Networks Settings for Facebook","url":"https:\\/\\/aioseo.com\\/docs\\/beginners-guide-to-social-networks-settings-for-facebook\\/","categories":["facebook-settings","getting-started","social-networks"]},"18857":{"title":"Beginners Guide to Social Networks Settings for Twitter","url":"https:\\/\\/aioseo.com\\/docs\\/beginners-guide-to-social-networks-settings-for-twitter\\/","categories":["getting-started","social-networks","twitter-settings"]},"29991":{"title":"aioseo_disable_link_format","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_disable_link_format\\/","categories":["filter-hooks"]},"27841":{"title":"aioseo_thumbnail_size","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_thumbnail_size\\/","categories":["filter-hooks"]},"27844":{"title":"Displaying Additional Data for Written By and Reading Time","url":"https:\\/\\/aioseo.com\\/docs\\/displaying-additional-data-for-written-by-and-reading-time\\/","categories":["social-networks"]},"27494":{"title":"aioseo_meta_views","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_meta_views\\/","categories":["filter-hooks"]},"27363":{"title":"Using the SEO Analysis Tool","url":"https:\\/\\/aioseo.com\\/docs\\/using-the-seo-analysis-tool\\/","categories":["seo-analysis"]},"27272":{"title":"Importing Settings From Other Plugins","url":"https:\\/\\/aioseo.com\\/docs\\/importing-settings-from-other-plugins\\/","categories":["importer-exporter","seo-data-importer","tools"]},"27268":{"title":"Backing Up and Restoring AIOSEO Settings","url":"https:\\/\\/aioseo.com\\/docs\\/backing-up-and-restoring-aioseo-settings\\/","categories":["importer-exporter","tools"]},"27259":{"title":"Importing and Exporting AIOSEO Settings and Meta Data","url":"https:\\/\\/aioseo.com\\/docs\\/importing-and-exporting-aioseo-settings-and-meta-data\\/","categories":["importer-exporter","tools"]},"26450":{"title":"Blank Title Formats Have Been Detected","url":"https:\\/\\/aioseo.com\\/docs\\/blank-title-formats-detected\\/","categories":["troubleshooting"]},"25802":{"title":"aioseo_sitemap_additional_pages","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_sitemap_additional_pages\\/","categories":["filter-hooks"]},"24928":{"title":"Including Custom Fields in the TruSEO Page Analysis","url":"https:\\/\\/aioseo.com\\/docs\\/including-custom-fields-in-the-seo-page-analysis\\/","categories":["content-type-settings","search-appearance","truseo"]},"24285":{"title":"aioseo_prev_link","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_prev_link\\/","categories":["filter-hooks"]},"24284":{"title":"aioseo_next_link","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_next_link\\/","categories":["filter-hooks"]},"23717":{"title":"aioseo_canonical_url","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_canonical_url\\/","categories":["filter-hooks"]},"23604":{"title":"aioseo_schema_breadcrumbs_home","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_schema_breadcrumbs_home\\/","categories":["filter-hooks"]},"23448":{"title":"aioseo_schema_disable","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_schema_disable\\/","categories":["filter-hooks"]},"23447":{"title":"aioseo_robots_meta","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_robots_meta\\/","categories":["filter-hooks"]},"23446":{"title":"aioseo_disable","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_disable\\/","categories":["filter-hooks"]},"23441":{"title":"aioseo_generate_descriptions_from_content","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_generate_descriptions_from_content\\/","categories":["filter-hooks"]},"23438":{"title":"aioseo_disable_title_rewrites","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_disable_title_rewrites\\/","categories":["filter-hooks"]},"23437":{"title":"aioseo_post_metabox_priority","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_post_metabox_priority\\/","categories":["filter-hooks"]},"23436":{"title":"aioseo_show_seo_news","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_show_seo_news\\/","categories":["filter-hooks"]},"23433":{"title":"aioseo_show_in_admin_bar","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_show_in_admin_bar\\/","categories":["filter-hooks"]},"23423":{"title":"aioseo_keywords","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_keywords\\/","categories":["filter-hooks"]},"23350":{"title":"aioseo_title","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_title\\/","categories":["filter-hooks"]},"23351":{"title":"aioseo_description","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo_description\\/","categories":["filter-hooks"]},"23415":{"title":"Troubleshooting Action Scheduler issues with AIOSEO","url":"https:\\/\\/aioseo.com\\/docs\\/troubleshooting-action-scheduler-issues\\/","categories":["troubleshooting"]},"20504":{"title":"Where Did my SEO Keywords go in All in One SEO v4.0?","url":"https:\\/\\/aioseo.com\\/docs\\/where-did-my-seo-keywords-go-in-all-in-one-seo-v4-0\\/","categories":["advanced-settings","frequently-asked-questions","post-page-settings","search-appearance"]},"18792":{"title":"Sitemap rewrite rules for NGINX","url":"https:\\/\\/aioseo.com\\/docs\\/xml-sitemap-rewrite-rules-for-nginx\\/","categories":["rss-sitemap","video-sitemap","xml-sitemap"]},"18793":{"title":"Unfiltered HTML Capability is Required","url":"https:\\/\\/aioseo.com\\/docs\\/unfiltered-html-capability\\/","categories":["troubleshooting"]},"18794":{"title":"Deprecated Open Graph Settings in All in One SEO version 4.0","url":"https:\\/\\/aioseo.com\\/docs\\/deprecated-opengraph-settings\\/","categories":["social-networks"]},"18795":{"title":"Why does the character counter for SEO titles show a different count?","url":"https:\\/\\/aioseo.com\\/docs\\/why-does-the-character-counter-for-seo-titles-show-a-different-count\\/","categories":["frequently-asked-questions","post-page-settings"]},"18796":{"title":"Adding nofollow, sponsored, UGC and title attributes to links","url":"https:\\/\\/aioseo.com\\/docs\\/adding-nofollow-sponsored-and-title-attributes-to-links\\/","categories":["post-page-settings"]},"18797":{"title":"Setting the SEO for WooCommerce Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-for-woocommerce-content\\/","categories":["search-appearance","woocommerce"]},"18798":{"title":"All in One SEO uses the WordPress REST API","url":"https:\\/\\/aioseo.com\\/docs\\/aioseo-uses-rest-api\\/","categories":["frequently-asked-questions"]},"18799":{"title":"How to Remove All Settings and Data When you Uninstall All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-remove-all-settings-and-data-when-you-uninstall-all-in-one-seo\\/","categories":["advanced-settings","general-settings"]},"18800":{"title":"How to Disable TruSEO Content Analysis","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-disable-truseo-content-analysis\\/","categories":["advanced-settings","general-settings","truseo"]},"18801":{"title":"Enabling Automatic Updates for All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/enabling-automatic-updates-for-all-in-one-seo\\/","categories":["advanced-settings","general-settings"]},"18802":{"title":"Hiding Plugin Notifications in the Notifications Center","url":"https:\\/\\/aioseo.com\\/docs\\/hiding-plugin-notifications-in-the-notifications-center\\/","categories":["advanced-settings","general-settings"]},"18803":{"title":"How to Hide the AIOSEO Settings on the Edit Content Screens in WordPress","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-hide-the-aioseo-settings-on-the-edit-content-screens-in-wordpress\\/","categories":["advanced-settings","content-type-settings","post-page-settings","search-appearance"]},"18804":{"title":"Setting Noindex and Nofollow on Paginated Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-noindex-and-nofollow-on-paginated-content\\/","categories":["advanced-settings","search-appearance"]},"18805":{"title":"Setting Unique SEO Titles and Descriptions for Paginated Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-unique-seo-titles-and-descriptions-for-paginated-content\\/","categories":["advanced-settings","search-appearance"]},"18806":{"title":"Setting the SEO Title and Description Format for Custom Post Type Archives","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-title-and-description-format-for-custom-post-type-archives\\/","categories":["archive-settings","search-appearance"]},"18807":{"title":"Meta Keyword Settings in All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/keyword-settings\\/","categories":["advanced-settings","search-appearance"]},"18808":{"title":"Using the Quick Edit Feature in All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/using-the-quick-edit-feature-in-all-in-one-seo\\/","categories":["post-page-settings"]},"18809":{"title":"How to FTP to your web server","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-ftp-to-your-web-server\\/","categories":["frequently-asked-questions"]},"18810":{"title":"How to manually install All in One SEO Pro when the file is too big","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-manually-install-all-in-one-seo-pro-when-the-file-is-too-big\\/","categories":["frequently-asked-questions","installation"]},"18811":{"title":"How to Upgrade From All in One SEO Lite to Pro","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-upgrade-from-all-in-one-seo-lite-to-pro\\/","categories":["getting-started","installation"]},"18812":{"title":"Installation instructions for WordPress.com Users","url":"https:\\/\\/aioseo.com\\/docs\\/installation-instructions-for-wordpress-com-users\\/","categories":["installation"]},"18814":{"title":"Configuring the Twitter Settings for Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/configuring-the-twitter-settings-for-your-content\\/","categories":["post-page-settings","social-networks","twitter-settings"]},"18815":{"title":"Configuring the Facebook Settings for Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/configuring-the-facebook-settings-for-your-content\\/","categories":["facebook-settings","post-page-settings","social-networks"]},"18816":{"title":"Hiding the AIOSEO Column on Taxonomy Screens","url":"https:\\/\\/aioseo.com\\/docs\\/hiding-the-aioseo-column-on-taxonomy-screens\\/","categories":["advanced-settings","category-tag-settings","general-settings"]},"18818":{"title":"Setting the Sitemap Priority and Frequency for Individual Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-sitemap-priority-and-frequency-for-individual-content\\/","categories":["post-page-settings","xml-sitemap"]},"18819":{"title":"Setting the Robots Meta for Individual Content","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-robots-meta-for-individual-content\\/","categories":["post-page-settings"]},"18821":{"title":"Individual Post\\/Page Settings","url":"https:\\/\\/aioseo.com\\/docs\\/post-settings\\/","categories":["post-page-settings"]},"18822":{"title":"Bad Bot Blocker","url":"https:\\/\\/aioseo.com\\/docs\\/bad-bot-blocker\\/","categories":["bad-bot-blocker"]},"18823":{"title":"How to Fix a 404 Error When Viewing Your Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-fix-a-404-error-when-viewing-your-sitemap\\/","categories":["frequently-asked-questions","google-news-sitemap","rss-sitemap","troubleshooting","video-sitemap","xml-sitemap"]},"18825":{"title":"When to use NOINDEX or the robots.txt?","url":"https:\\/\\/aioseo.com\\/docs\\/when-to-use-noindex-or-the-robots-txt\\/","categories":["frequently-asked-questions","robots-txt","search-appearance","tools"]},"18826":{"title":"Support for Videos Embedded Using the Media Library","url":"https:\\/\\/aioseo.com\\/docs\\/support-for-videos-embedded-using-the-media-library\\/","categories":["video-sitemap"]},"18827":{"title":"Supported Videos","url":"https:\\/\\/aioseo.com\\/docs\\/supported-videos\\/","categories":["video-sitemap"]},"18828":{"title":"Performance Settings","url":"https:\\/\\/aioseo.com\\/docs\\/performance-settings\\/","categories":["performance"]},"18830":{"title":"Setting the SEO Title and Description Format for Author and Date Archives","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-title-and-description-format-for-author-and-date-archives\\/","categories":["archive-settings","search-appearance"]},"18831":{"title":"Using Custom Fields in Titles and Descriptions","url":"https:\\/\\/aioseo.com\\/docs\\/custom-fields-in-titles-and-descriptions\\/","categories":["content-type-settings","post-page-settings","search-appearance"]},"18832":{"title":"Using the Focus Keyphrase to Analyze Your Content","url":"https:\\/\\/aioseo.com\\/docs\\/using-the-focus-keyphrase-to-analyze-your-content\\/","categories":["frequently-asked-questions","post-page-settings","truseo"]},"18833":{"title":"Using the Robots.txt Tool in All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/using-the-robots-txt-tool-in-all-in-one-seo\\/","categories":["robots-txt","tools"]},"18834":{"title":"Using the Robots Meta Settings in All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/using-the-robots-meta-settings-in-all-in-one-seo\\/","categories":["advanced-settings","archive-settings","category-tag-settings","content-type-settings","media-settings","post-page-settings","search-appearance","taxonomy-settings"]},"18835":{"title":"Noindex Settings","url":"https:\\/\\/aioseo.com\\/docs\\/noindex-settings\\/","categories":["search-appearance"]},"18838":{"title":"Hiding the AIOSEO Admin Bar Menu","url":"https:\\/\\/aioseo.com\\/docs\\/hiding-the-aioseo-admin-bar-menu\\/","categories":["advanced-settings","general-settings"]},"18839":{"title":"Hiding the AIOSEO Dashboard Widgets","url":"https:\\/\\/aioseo.com\\/docs\\/hiding-the-aioseo-dashboard-widget\\/","categories":["advanced-settings","general-settings"]},"18840":{"title":"Hiding the AIOSEO Column on All Posts Screens","url":"https:\\/\\/aioseo.com\\/docs\\/hiding-the-aioseo-column-on-all-posts-screens\\/","categories":["advanced-settings","general-settings"]},"18841":{"title":"Display Settings","url":"https:\\/\\/aioseo.com\\/docs\\/display-settings\\/","categories":["display-settings"]},"18842":{"title":"Setting the SEO Title and Description Format for Media Attachments","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-title-and-description-format-for-media-attachments\\/","categories":["media-settings","search-appearance"]},"18843":{"title":"Showing or Hiding Your Content in Search Results","url":"https:\\/\\/aioseo.com\\/docs\\/showing-or-hiding-your-content-in-search-results\\/","categories":["archive-settings","category-tag-settings","content-type-settings","media-settings","post-page-settings","search-appearance","taxonomy-settings"]},"18844":{"title":"Content Type Settings","url":"https:\\/\\/aioseo.com\\/docs\\/custom-post-type-settings\\/","categories":["content-type-settings","search-appearance"]},"18845":{"title":"What Are Media Attachments and Should I Submit Them to Search Engines?","url":"https:\\/\\/aioseo.com\\/docs\\/what-are-media-attachments-and-should-i-submit-them-to-search-engines\\/","categories":["frequently-asked-questions","media-settings"]},"18846":{"title":"Setting the SEO Title and Description Format for Custom Taxonomies","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-title-and-description-format-for-custom-taxonomies\\/","categories":["category-tag-settings","search-appearance","taxonomy-settings"]},"18847":{"title":"Setting the SEO Title and Description Format for Custom Post Types","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-title-and-description-format-for-custom-post-types\\/","categories":["content-type-settings","search-appearance"]},"18848":{"title":"Setting the SEO Title and Description Format for Tags","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-title-and-description-format-for-tags\\/","categories":["category-tag-settings","search-appearance","taxonomy-settings"]},"18849":{"title":"Setting the SEO Title and Description Format for Categories","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-title-and-description-format-for-categories\\/","categories":["category-tag-settings","search-appearance","taxonomy-settings"]},"18850":{"title":"Setting the SEO Title and Description Format for Pages","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-title-and-description-format-for-pages\\/","categories":["content-type-settings","post-page-settings","search-appearance"]},"18851":{"title":"Setting the SEO Title and Description Format for Posts","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-title-and-description-format-for-posts\\/","categories":["content-type-settings","post-page-settings","search-appearance"]},"18852":{"title":"Title Settings","url":"https:\\/\\/aioseo.com\\/docs\\/title-settings\\/","categories":["search-appearance"]},"18853":{"title":"Setting the SEO for Your Home Page","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-seo-for-your-home-page\\/","categories":["home-page-settings","search-appearance"]},"18854":{"title":"General Settings","url":"https:\\/\\/aioseo.com\\/docs\\/general-settings\\/","categories":["general-settings"]},"18855":{"title":"How to Add Your License Key for All in One SEO Pro","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-add-your-license-key-in-all-in-one-seo-pro\\/","categories":["general-settings","getting-started"]},"18856":{"title":"Canonical URLs in All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/canonical-urls-in-all-in-one-seo\\/","categories":["advanced-settings","search-appearance"]},"18858":{"title":"Adding non-WordPress Content to the Video Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/adding-non-wordpress-content-to-the-video-sitemap\\/","categories":["video-sitemap"]},"18860":{"title":"Troubleshooting Problems With Sharing Content on Twitter","url":"https:\\/\\/aioseo.com\\/docs\\/troubleshooting-problems-with-sharing-content-on-twitter\\/","categories":["social-networks","troubleshooting","twitter-settings"]},"18861":{"title":"Troubleshooting Problems With Sharing Content on Facebook","url":"https:\\/\\/aioseo.com\\/docs\\/troubleshooting-problems-with-sharing-content-on-facebook\\/","categories":["facebook-settings","social-networks","troubleshooting"]},"18862":{"title":"Getting Started With Pinterest Rich Pins","url":"https:\\/\\/aioseo.com\\/docs\\/using-social-meta-for-pinterest-rich-pins\\/","categories":["pinterest-settings","social-networks"]},"18863":{"title":"Setting the Content Publisher for Twitter","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-content-publisher-for-twitter\\/","categories":["social-networks","twitter-settings"]},"18865":{"title":"Submitting a Sitemap to Yandex","url":"https:\\/\\/aioseo.com\\/docs\\/submitting-a-sitemap-to-yandex\\/","categories":["rss-sitemap","video-sitemap","xml-sitemap"]},"18866":{"title":"Submitting a Sitemap to Bing","url":"https:\\/\\/aioseo.com\\/docs\\/submitting-a-sitemap-to-bing\\/","categories":["bing-webmaster-tools","rss-sitemap","video-sitemap","xml-sitemap"]},"18867":{"title":"Submitting a Sitemap to Google","url":"https:\\/\\/aioseo.com\\/docs\\/submitting-a-sitemap-to-google\\/","categories":["google-news-sitemap","google-search-console","rss-sitemap","video-sitemap","xml-sitemap"]},"18868":{"title":"Including Date and Author Archives in Your XML Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/including-date-and-author-archives-in-your-xml-sitemap\\/","categories":["xml-sitemap"]},"18869":{"title":"Choosing Which Content to Include in Your Video Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/choosing-which-content-to-include-in-your-video-sitemap\\/","categories":["video-sitemap"]},"18870":{"title":"Choosing Which Content to Include in Your XML Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/choosing-which-content-to-include-in-your-xml-sitemap\\/","categories":["xml-sitemap"]},"18871":{"title":"Using Sitemap Indexes and Pagination","url":"https:\\/\\/aioseo.com\\/docs\\/using-sitemap-indexes-and-pagination\\/","categories":["video-sitemap","xml-sitemap"]},"18872":{"title":"How to Disable Sitemaps in All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-disable-sitemaps-in-all-in-one-seo\\/","categories":["google-news-sitemap","rss-sitemap","video-sitemap","xml-sitemap"]},"18873":{"title":"Baidu Webmaster Tools Verification","url":"https:\\/\\/aioseo.com\\/docs\\/baidu-webmaster-tools-verification\\/","categories":["webmaster-tools","webmaster-verification"]},"18874":{"title":"Setting Twitter Social Meta for Your Homepage","url":"https:\\/\\/aioseo.com\\/docs\\/setting-twitter-social-meta-for-your-homepage\\/","categories":["home-page-settings","social-networks","twitter-settings"]},"18875":{"title":"Setting Facebook Social Meta for Your Homepage","url":"https:\\/\\/aioseo.com\\/docs\\/setting-facebook-social-meta-for-your-homepage\\/","categories":["facebook-settings","home-page-settings","social-networks"]},"18876":{"title":"Setting the Card Type for Twitter","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-card-type-for-twitter\\/","categories":["social-networks","twitter-settings"]},"18877":{"title":"Setting the Object Types for Facebook","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-object-types-for-facebook\\/","categories":["facebook-settings","social-networks"]},"18879":{"title":"Setting the Priority and Frequency for Content in the Video Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-priority-and-frequency-for-content-in-the-video-sitemap\\/","categories":["video-sitemap"]},"18880":{"title":"Setting the Priority and Frequency for Content in the XML Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-priority-and-frequency-for-content-in-the-xml-sitemap\\/","categories":["xml-sitemap"]},"18881":{"title":"How to Exclude Content from Your RSS Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-exclude-content-from-your-rss-sitemap\\/","categories":["rss-sitemap"]},"18882":{"title":"How to Exclude Content from Your Google News Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-exclude-content-from-your-google-news-sitemap\\/","categories":["google-news-sitemap"]},"18883":{"title":"How to Exclude Content from Your Video Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-exclude-content-from-your-video-sitemap\\/","categories":["video-sitemap"]},"18884":{"title":"How to Exclude Content from Your XML Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-exclude-content-from-your-xml-sitemap\\/","categories":["xml-sitemap"]},"18885":{"title":"Setting Article Tags for Facebook","url":"https:\\/\\/aioseo.com\\/docs\\/setting-article-tags-for-facebook\\/","categories":["facebook-settings","social-networks"]},"18886":{"title":"Setting the Content Author for Twitter","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-content-author-for-twitter\\/","categories":["social-networks","twitter-settings"]},"18887":{"title":"Setting the Content Author for Facebook","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-content-author-for-facebook\\/","categories":["facebook-settings","social-networks"]},"18888":{"title":"Setting the Content Publisher for Facebook","url":"https:\\/\\/aioseo.com\\/docs\\/setting-the-content-publisher-for-facebook\\/","categories":["facebook-settings","social-networks"]},"18889":{"title":"How to Create a Google News Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-create-a-google-news-sitemap\\/","categories":["google-news-sitemap"]},"18890":{"title":"Including Videos in Custom Fields in Your Video Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/including-videos-in-custom-fields-in-your-video-sitemap\\/","categories":["video-sitemap"]},"18891":{"title":"What is a Dynamically Generated Sitemap and Why is it Better to Use?","url":"https:\\/\\/aioseo.com\\/docs\\/what-is-a-dynamically-generated-sitemap-and-why-is-it-better-to-use\\/","categories":["frequently-asked-questions","video-sitemap","xml-sitemap"]},"18892":{"title":"How to Create a Video Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-create-a-video-sitemap\\/","categories":["video-sitemap"]},"18893":{"title":"Adding Your Facebook Admin ID","url":"https:\\/\\/aioseo.com\\/docs\\/adding-your-facebook-admin-id\\/","categories":["facebook-settings","social-networks"]},"18894":{"title":"Adding Your Facebook App ID","url":"https:\\/\\/aioseo.com\\/docs\\/adding-your-facebook-app-id\\/","categories":["facebook-settings","social-networks"]},"18895":{"title":"Access Control Settings","url":"https:\\/\\/aioseo.com\\/docs\\/access-control-settings\\/","categories":["access-control-settings"]},"18896":{"title":"Advanced Settings for Google Analytics","url":"https:\\/\\/aioseo.com\\/docs\\/advanced-settings-for-google-analytics\\/","categories":["google-analytics"]},"18897":{"title":"Miscellaneous Site Verification","url":"https:\\/\\/aioseo.com\\/docs\\/miscellaneous-site-verification\\/","categories":["webmaster-tools","webmaster-verification"]},"18898":{"title":"Displaying Your Social Media Profiles in Knowledge Panel","url":"https:\\/\\/aioseo.com\\/docs\\/displaying-your-social-media-profiles-in-knowledge-panel\\/","categories":["schema-settings","social-networks"]},"18899":{"title":"How to Create an RSS Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-create-an-rss-sitemap\\/","categories":["rss-sitemap"]},"18900":{"title":"Excluding Images from the XML Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/excluding-images-from-the-xml-sitemap\\/","categories":["xml-sitemap"]},"18901":{"title":"Adding non-WordPress Content to the XML Sitemap","url":"https:\\/\\/aioseo.com\\/docs\\/adding-non-wordpress-content-to-the-xml-sitemap\\/","categories":["xml-sitemap"]},"18903":{"title":"Setting a Default Image for Twitter","url":"https:\\/\\/aioseo.com\\/docs\\/setting-a-default-image-for-twitter\\/","categories":["social-networks","twitter-settings"]},"18904":{"title":"Setting a Default Image for Facebook","url":"https:\\/\\/aioseo.com\\/docs\\/setting-a-default-image-for-facebook\\/","categories":["facebook-settings","social-networks"]},"18905":{"title":"Setting a Title Separator","url":"https:\\/\\/aioseo.com\\/docs\\/setting-a-title-separator\\/","categories":["search-appearance"]},"18906":{"title":"How to Protect Your Content With RSS Content Settings","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-protect-your-content-with-rss-content-settings\\/","categories":["rss-content-settings"]},"18907":{"title":"How to Connect Your Site with Google Tag Manager","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-connect-your-site-with-google-tag-manager\\/","categories":["google-analytics"]},"18908":{"title":"How to Connect Your Site with Google Analytics","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-connect-your-site-with-google-analytics\\/","categories":["google-analytics"]},"18909":{"title":"How to Verify Your Site with Pinterest","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-verify-your-site-with-pinterest\\/","categories":["pinterest-settings","social-networks","webmaster-tools","webmaster-verification"]},"18910":{"title":"How to Verify Your Site with Yandex Webmaster Tools","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-verify-your-site-with-yandex-webmaster-tools\\/","categories":["webmaster-tools","webmaster-verification"]},"18911":{"title":"How to Verify Your Site with Bing Webmaster Tools","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-verify-your-site-with-bing-webmaster-tools\\/","categories":["bing-webmaster-tools","webmaster-tools","webmaster-verification"]},"18912":{"title":"How to Verify Your Site with Google Search Console","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-verify-your-site-with-google-search-console\\/","categories":["google-search-console","webmaster-tools","webmaster-verification"]},"18913":{"title":"Usage Tracking","url":"https:\\/\\/aioseo.com\\/docs\\/usage-tracking\\/","categories":["frequently-asked-questions"]},"18915":{"title":"How do I use All in One SEO in my language?","url":"https:\\/\\/aioseo.com\\/docs\\/how-do-i-use-all-in-one-seo-in-my-language\\/","categories":["frequently-asked-questions"]},"18920":{"title":"NGINX rewrite rules for Robots.txt","url":"https:\\/\\/aioseo.com\\/docs\\/nginx-rewrite-rules-for-robots-txt\\/","categories":["robots-txt","tools"]},"18927":{"title":"Supported PHP Versions for All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/supported-php-version\\/","categories":["troubleshooting"]},"18929":{"title":"Using a different CDN for script enqueuing","url":"https:\\/\\/aioseo.com\\/docs\\/using-a-different-cdn-for-script-enqueuing\\/","categories":["troubleshooting"]},"18930":{"title":"How do I get Google to show sitelinks for my site?","url":"https:\\/\\/aioseo.com\\/docs\\/how-do-i-get-google-to-show-sitelinks-for-my-site\\/","categories":["frequently-asked-questions"]},"18954":{"title":"How does the import process for SEO data work?","url":"https:\\/\\/aioseo.com\\/docs\\/how-does-the-import-process-for-seo-data-work\\/","categories":["frequently-asked-questions","importer-exporter","tools"]},"18960":{"title":"Robots.txt Editor for Multisite Networks","url":"https:\\/\\/aioseo.com\\/docs\\/robots-txt-editor-for-multisite-networks\\/","categories":["multisite-networks","robots-txt"]},"18961":{"title":"What are the minimum requirements for All in One SEO?","url":"https:\\/\\/aioseo.com\\/docs\\/what-are-the-minimum-requirements-for-all-in-one-seo-pack\\/","categories":["frequently-asked-questions"]},"18964":{"title":"How do I use your API code examples?","url":"https:\\/\\/aioseo.com\\/docs\\/how-do-i-use-your-api-code-examples\\/","categories":["frequently-asked-questions"]},"18969":{"title":"XML Parsing Error - This page contains the following errors","url":"https:\\/\\/aioseo.com\\/docs\\/this-page-contains-the-following-errors\\/","categories":["google-news-sitemap","troubleshooting","video-sitemap","xml-sitemap"]},"18972":{"title":"The File Editor or Robots.txt modules are missing","url":"https:\\/\\/aioseo.com\\/docs\\/the-file-editor-or-robots-txt-modules-are-missing\\/","categories":["frequently-asked-questions"]},"18977":{"title":"Excluding the XML Sitemap from caching","url":"https:\\/\\/aioseo.com\\/docs\\/excluding-the-xml-sitemap-from-caching\\/","categories":["xml-sitemap"]},"18982":{"title":"Why doesn\'t the title and description I set appear in search results?","url":"https:\\/\\/aioseo.com\\/docs\\/why-doesnt-the-title-and-description-i-set-appear-in-search-results\\/","categories":["frequently-asked-questions","post-page-settings"]},"18983":{"title":"Can I remove the date from Google search results?","url":"https:\\/\\/aioseo.com\\/docs\\/can-i-remove-the-date-from-google-search-results\\/","categories":["frequently-asked-questions"]},"18985":{"title":"Setting up HTTPS SSL","url":"https:\\/\\/aioseo.com\\/docs\\/setting-up-https-ssl\\/","categories":["general-seo-topics"]},"18995":{"title":"How to Increase the WordPress PHP Memory Limit","url":"https:\\/\\/aioseo.com\\/docs\\/increase-wordpress-php-memory-limit\\/","categories":["troubleshooting"]},"19002":{"title":"Checking Index Status in Google Search Results","url":"https:\\/\\/aioseo.com\\/docs\\/checking-index-status-in-google-search-results\\/","categories":["general-seo-topics"]},"19006":{"title":"SEO Data Importer","url":"https:\\/\\/aioseo.com\\/docs\\/seo-data-importer\\/","categories":["seo-data-importer"]},"19008":{"title":"How to troubleshoot issues with All in One SEO","url":"https:\\/\\/aioseo.com\\/docs\\/how-to-troubleshoot-issues-with-all-in-one-seo-pack\\/","categories":["troubleshooting"]},"19010":{"title":"Quality Guidelines for SEO Titles and Descriptions","url":"https:\\/\\/aioseo.com\\/docs\\/quality-guidelines-for-seo-titles-and-descriptions\\/","categories":["general-seo-topics"]},"19016":{"title":"Top Tips for Good On-Page SEO","url":"https:\\/\\/aioseo.com\\/docs\\/top-tips-for-good-on-page-seo\\/","categories":["general-seo-topics"]},"19017":{"title":"Meta Descriptions","url":"https:\\/\\/aioseo.com\\/docs\\/meta-descriptions\\/","categories":["general-seo-topics"]},"19028":{"title":"What is SEO meta?","url":"https:\\/\\/aioseo.com\\/docs\\/what-is-seo-meta\\/","categories":["getting-started"]},"19029":{"title":"Social Meta Settings - Individual Page\\/Post Settings","url":"https:\\/\\/aioseo.com\\/docs\\/social-meta-settings-individual-pagepost-settings\\/","categories":["post-page-settings","social-networks"]},"19030":{"title":"File Editor Module","url":"https:\\/\\/aioseo.com\\/docs\\/file-editor-module\\/","categories":["file-editor"]},"19031":{"title":"Social Meta Settings","url":"https:\\/\\/aioseo.com\\/docs\\/social-meta-module\\/","categories":["social-networks"]},"19032":{"title":"Importer &amp; Exporter Module","url":"https:\\/\\/aioseo.com\\/docs\\/importer-exporter-module\\/","categories":["importer-exporter","tools"]},"19034":{"title":"Feature Manager","url":"https:\\/\\/aioseo.com\\/docs\\/feature-manager\\/","categories":["feature-manager"]},"19035":{"title":"Advanced Settings for All in One SEO Pack","url":"https:\\/\\/aioseo.com\\/docs\\/all-in-one-seo-pack-advanced-settings\\/","categories":["advanced-settings"]}}}";', '2024-03-17 04:20:14', '2024-03-10 04:20:14', '2024-03-10 04:20:14') ;
INSERT INTO `wp_aioseo_cache` ( `id`, `key`, `value`, `expiration`, `created`, `updated`) VALUES
(9, 'rss_feed', 'a:4:{i:0;a:4:{s:3:"url";s:100:"https://aioseo.com/redirect-types/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=redirect-types";s:5:"title";s:41:"19 Redirect Types You Should Know in 2024";s:4:"date";s:13:"March 7, 2024";s:7:"content";s:131:"Curious about the different redirect types you should know as you manage your site?\n\n\n\nRedirects are an essential aspect of site...";}i:1;a:4:{s:3:"url";s:204:"https://aioseo.com/how-to-write-an-author-bio-that-boosts-your-google-e-e-a-t-signals/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=how-to-write-an-author-bio-that-boosts-your-google-e-e-a-t-signals";s:5:"title";s:66:"How to Write an Author Bio that Boosts Your Google E-E-A-T Signals";s:4:"date";s:13:"March 6, 2024";s:7:"content";s:131:"Would you like to know how to write an author bio that boosts your Google E-E-A-T signals?\n\n\n\nYour author bio is a critical yet ...";}i:2;a:4:{s:3:"url";s:128:"https://aioseo.com/how-to-rank-higher-on-google/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=how-to-rank-higher-on-google";s:5:"title";s:47:"How to Rank Higher on Google in 2024 (14 Steps)";s:4:"date";s:13:"March 5, 2024";s:7:"content";s:131:"Learning how to rank higher on Google can transform your online efforts.\n\n\n\nWith billions of Google searches every day, being on...";}i:3;a:4:{s:3:"url";s:104:"https://aioseo.com/content-strategy/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=content-strategy";s:5:"title";s:50:"What is Content Strategy? An Ultimate Guide (2024)";s:4:"date";s:13:"March 4, 2024";s:7:"content";s:131:"Good content strategy drives business growth by aligning content with business objectives.\n\n\n\nEven a simple strategy can spark l...";}}', '2024-03-10 16:20:15', '2024-03-10 04:20:15', '2024-03-10 04:20:15') ;

#
# End of data contents of table `wp_aioseo_cache`
# --------------------------------------------------------



#
# Delete any existing table `wp_aioseo_crawl_cleanup_blocked_args`
#

DROP TABLE IF EXISTS `wp_aioseo_crawl_cleanup_blocked_args`;


#
# Table structure of table `wp_aioseo_crawl_cleanup_blocked_args`
#

CREATE TABLE `wp_aioseo_crawl_cleanup_blocked_args` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `key` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `key_value_hash` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `regex` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `hits` int(20) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ndx_aioseo_crawl_cleanup_blocked_args_key_value_hash` (`key_value_hash`),
  UNIQUE KEY `ndx_aioseo_crawl_cleanup_blocked_args_regex` (`regex`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_aioseo_crawl_cleanup_blocked_args`
#

#
# End of data contents of table `wp_aioseo_crawl_cleanup_blocked_args`
# --------------------------------------------------------



#
# Delete any existing table `wp_aioseo_crawl_cleanup_logs`
#

DROP TABLE IF EXISTS `wp_aioseo_crawl_cleanup_logs`;


#
# Table structure of table `wp_aioseo_crawl_cleanup_logs`
#

CREATE TABLE `wp_aioseo_crawl_cleanup_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `key` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `hash` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `hits` int(20) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ndx_aioseo_crawl_cleanup_logs_hash` (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_aioseo_crawl_cleanup_logs`
#

#
# End of data contents of table `wp_aioseo_crawl_cleanup_logs`
# --------------------------------------------------------



#
# Delete any existing table `wp_aioseo_notifications`
#

DROP TABLE IF EXISTS `wp_aioseo_notifications`;


#
# Table structure of table `wp_aioseo_notifications`
#

CREATE TABLE `wp_aioseo_notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(13) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `addon` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `level` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `notification_id` bigint(20) unsigned DEFAULT NULL,
  `notification_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `start` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `button1_label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `button1_action` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `button2_label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `button2_action` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `dismissed` tinyint(1) NOT NULL DEFAULT '0',
  `new` tinyint(1) NOT NULL DEFAULT '1',
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ndx_aioseo_notifications_slug` (`slug`),
  KEY `ndx_aioseo_notifications_dates` (`start`,`end`),
  KEY `ndx_aioseo_notifications_type` (`type`),
  KEY `ndx_aioseo_notifications_dismissed` (`dismissed`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_aioseo_notifications`
#

#
# End of data contents of table `wp_aioseo_notifications`
# --------------------------------------------------------



#
# Delete any existing table `wp_aioseo_posts`
#

DROP TABLE IF EXISTS `wp_aioseo_posts`;


#
# Table structure of table `wp_aioseo_posts`
#

CREATE TABLE `wp_aioseo_posts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `keywords` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `keyphrases` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `page_analysis` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `primary_term` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `canonical_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `og_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `og_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `og_object_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT 'default',
  `og_image_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT 'default',
  `og_image_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `og_image_width` int(11) DEFAULT NULL,
  `og_image_height` int(11) DEFAULT NULL,
  `og_image_custom_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `og_image_custom_fields` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `og_video` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `og_custom_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `og_article_section` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `og_article_tags` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `twitter_use_og` tinyint(1) DEFAULT '0',
  `twitter_card` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT 'default',
  `twitter_image_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT 'default',
  `twitter_image_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `twitter_image_custom_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `twitter_image_custom_fields` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `twitter_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `twitter_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `seo_score` int(11) NOT NULL DEFAULT '0',
  `schema` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `schema_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT 'default',
  `schema_type_options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `pillar_content` tinyint(1) DEFAULT NULL,
  `robots_default` tinyint(1) NOT NULL DEFAULT '1',
  `robots_noindex` tinyint(1) NOT NULL DEFAULT '0',
  `robots_noarchive` tinyint(1) NOT NULL DEFAULT '0',
  `robots_nosnippet` tinyint(1) NOT NULL DEFAULT '0',
  `robots_nofollow` tinyint(1) NOT NULL DEFAULT '0',
  `robots_noimageindex` tinyint(1) NOT NULL DEFAULT '0',
  `robots_noodp` tinyint(1) NOT NULL DEFAULT '0',
  `robots_notranslate` tinyint(1) NOT NULL DEFAULT '0',
  `robots_max_snippet` int(11) DEFAULT NULL,
  `robots_max_videopreview` int(11) DEFAULT NULL,
  `robots_max_imagepreview` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT 'large',
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `image_scan_date` datetime DEFAULT NULL,
  `priority` float DEFAULT NULL,
  `frequency` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `videos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `video_thumbnail` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `video_scan_date` datetime DEFAULT NULL,
  `local_seo` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `limit_modified_date` tinyint(1) NOT NULL DEFAULT '0',
  `options` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ndx_aioseo_posts_post_id` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_aioseo_posts`
#
INSERT INTO `wp_aioseo_posts` ( `id`, `post_id`, `title`, `description`, `keywords`, `keyphrases`, `page_analysis`, `primary_term`, `canonical_url`, `og_title`, `og_description`, `og_object_type`, `og_image_type`, `og_image_url`, `og_image_width`, `og_image_height`, `og_image_custom_url`, `og_image_custom_fields`, `og_video`, `og_custom_url`, `og_article_section`, `og_article_tags`, `twitter_use_og`, `twitter_card`, `twitter_image_type`, `twitter_image_url`, `twitter_image_custom_url`, `twitter_image_custom_fields`, `twitter_title`, `twitter_description`, `seo_score`, `schema`, `schema_type`, `schema_type_options`, `pillar_content`, `robots_default`, `robots_noindex`, `robots_noarchive`, `robots_nosnippet`, `robots_nofollow`, `robots_noimageindex`, `robots_noodp`, `robots_notranslate`, `robots_max_snippet`, `robots_max_videopreview`, `robots_max_imagepreview`, `images`, `image_scan_date`, `priority`, `frequency`, `videos`, `video_thumbnail`, `video_scan_date`, `local_seo`, `limit_modified_date`, `options`, `created`, `updated`) VALUES
(1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'default', 'default', NULL, NULL, NULL, NULL, NULL, 0, '{"blockGraphs":[],"customGraphs":[],"default":{"data":{"Article":[],"Course":[],"Dataset":[],"FAQPage":[],"Movie":[],"Person":[],"Product":[],"Recipe":[],"Service":[],"SoftwareApplication":[],"WebPage":[]},"graphName":"","isEnabled":true},"graphs":[]}', 'default', NULL, 0, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'large', NULL, '2024-03-10 04:07:04', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"linkFormat":{"internalLinkCount":0,"linkAssistantDismissed":false},"primaryTerm":{"productEducationDismissed":false}}', '2024-03-10 04:07:04', '2024-03-10 04:07:04'),
(2, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 'default', 'default', NULL, NULL, NULL, NULL, NULL, 0, '{"blockGraphs":[],"customGraphs":[],"default":{"data":{"Article":[],"Course":[],"Dataset":[],"FAQPage":[],"Movie":[],"Person":[],"Product":[],"Recipe":[],"Service":[],"SoftwareApplication":[],"WebPage":[]},"graphName":"","isEnabled":true},"graphs":[]}', 'default', NULL, 0, 1, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, 'large', NULL, '2024-03-10 04:07:04', NULL, NULL, NULL, NULL, NULL, NULL, 0, '{"linkFormat":{"internalLinkCount":0,"linkAssistantDismissed":false},"primaryTerm":{"productEducationDismissed":false}}', '2024-03-10 04:07:04', '2024-03-10 04:07:04'),
(3, 8, NULL, NULL, '[]', '{"focus":{"keyphrase":"","score":0,"analysis":{"keyphraseInTitle":{"score":0,"maxScore":9,"error":1}}},"additional":[]}', '{"analysis":{"basic":{"lengthContent":{"error":1,"score":1,"maxScore":5}},"title":{"titleLength":{"score":9,"maxScore":9,"error":0},"errors":0},"readability":{"contentHasAssets":{"error":1,"score":1,"maxScore":5}}}}', NULL, NULL, NULL, NULL, 'default', 'default', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, '[]', 0, 'default', 'default', NULL, NULL, NULL, NULL, NULL, 100, '{"blockGraphs":[],"customGraphs":[],"default":{"data":{"Article":[],"Course":[],"Dataset":[],"FAQPage":[],"Movie":[],"Person":[],"Product":[],"Recipe":[],"Service":[],"SoftwareApplication":[],"WebPage":[]},"graphName":"WebPage","isEnabled":true},"graphs":[]}', 'default', NULL, 0, 1, 0, 0, 0, 0, 0, 0, 0, -1, -1, 'large', NULL, '2024-03-10 11:22:32', NULL, 'default', NULL, NULL, NULL, NULL, 0, '{"linkFormat":{"internalLinkCount":0,"linkAssistantDismissed":false},"primaryTerm":{"productEducationDismissed":false}}', '2024-03-10 11:19:40', '2024-03-10 11:22:32') ;

#
# End of data contents of table `wp_aioseo_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_blogmeta`
#

DROP TABLE IF EXISTS `wp_blogmeta`;


#
# Table structure of table `wp_blogmeta`
#

CREATE TABLE `wp_blogmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `blog_id` (`blog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_blogmeta`
#

#
# End of data contents of table `wp_blogmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_blogs`
#

DROP TABLE IF EXISTS `wp_blogs`;


#
# Table structure of table `wp_blogs`
#

CREATE TABLE `wp_blogs` (
  `blog_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) NOT NULL DEFAULT '0',
  `domain` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `path` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `public` tinyint(2) NOT NULL DEFAULT '1',
  `archived` tinyint(2) NOT NULL DEFAULT '0',
  `mature` tinyint(2) NOT NULL DEFAULT '0',
  `spam` tinyint(2) NOT NULL DEFAULT '0',
  `deleted` tinyint(2) NOT NULL DEFAULT '0',
  `lang_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`blog_id`),
  KEY `domain` (`domain`(50),`path`(5)),
  KEY `lang_id` (`lang_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_blogs`
#
INSERT INTO `wp_blogs` ( `blog_id`, `site_id`, `domain`, `path`, `registered`, `last_updated`, `public`, `archived`, `mature`, `spam`, `deleted`, `lang_id`) VALUES
(1, 1, 'white-label-storage-b2c.local', '/', '2024-03-09 21:20:42', '2024-03-14 08:54:15', 1, 0, 0, 0, 0, 0) ;

#
# End of data contents of table `wp_blogs`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2024-03-09 21:20:42', '2024-03-09 21:20:42', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href="https://en.gravatar.com/">Gravatar</a>.', 0, 'post-trashed', '', 'comment', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_defender_audit_log`
#

DROP TABLE IF EXISTS `wp_defender_audit_log`;


#
# Table structure of table `wp_defender_audit_log`
#

CREATE TABLE `wp_defender_audit_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` int(11) NOT NULL,
  `event_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `action_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `site_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `context` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `ip` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `msg` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `blog_id` int(11) NOT NULL,
  `synced` int(11) NOT NULL,
  `ttl` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `event_type` (`event_type`),
  KEY `action_type` (`action_type`),
  KEY `user_id` (`user_id`),
  KEY `context` (`context`),
  KEY `ip` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_defender_audit_log`
#

#
# End of data contents of table `wp_defender_audit_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_defender_email_log`
#

DROP TABLE IF EXISTS `wp_defender_email_log`;


#
# Table structure of table `wp_defender_email_log`
#

CREATE TABLE `wp_defender_email_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` int(11) NOT NULL,
  `source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `to` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `source` (`source`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_defender_email_log`
#

#
# End of data contents of table `wp_defender_email_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_defender_lockout`
#

DROP TABLE IF EXISTS `wp_defender_lockout`;


#
# Table structure of table `wp_defender_lockout`
#

CREATE TABLE `wp_defender_lockout` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `lockout_message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `release_time` int(11) DEFAULT NULL,
  `lock_time` int(11) DEFAULT NULL,
  `lock_time_404` int(11) DEFAULT NULL,
  `attempt` int(11) DEFAULT NULL,
  `attempt_404` int(11) DEFAULT NULL,
  `meta` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`id`),
  KEY `ip` (`ip`),
  KEY `status` (`status`),
  KEY `attempt` (`attempt`),
  KEY `attempt_404` (`attempt_404`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_defender_lockout`
#
INSERT INTO `wp_defender_lockout` ( `id`, `ip`, `status`, `lockout_message`, `release_time`, `lock_time`, `lock_time_404`, `attempt`, `attempt_404`, `meta`) VALUES
(3, '::1', 'normal', '', 0, 1710043585, 0, 0, 0, '[]'),
(4, '127.0.0.1', 'normal', '', 0, 1710043585, 0, 0, 0, '[]') ;

#
# End of data contents of table `wp_defender_lockout`
# --------------------------------------------------------



#
# Delete any existing table `wp_defender_lockout_log`
#

DROP TABLE IF EXISTS `wp_defender_lockout_log`;


#
# Table structure of table `wp_defender_lockout_log`
#

CREATE TABLE `wp_defender_lockout_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `log` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  `ip` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `date` int(11) DEFAULT NULL,
  `type` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `user_agent` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `blog_id` int(11) DEFAULT NULL,
  `tried` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `country_iso_code` char(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ip` (`ip`),
  KEY `type` (`type`),
  KEY `tried` (`tried`),
  KEY `country_iso_code` (`country_iso_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_defender_lockout_log`
#

#
# End of data contents of table `wp_defender_lockout_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_defender_scan`
#

DROP TABLE IF EXISTS `wp_defender_scan`;


#
# Table structure of table `wp_defender_scan`
#

CREATE TABLE `wp_defender_scan` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `percent` float NOT NULL,
  `total_tasks` tinyint(4) NOT NULL,
  `task_checkpoint` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_start` datetime NOT NULL,
  `date_end` datetime NOT NULL,
  `is_automation` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_defender_scan`
#
INSERT INTO `wp_defender_scan` ( `id`, `percent`, `total_tasks`, `task_checkpoint`, `status`, `date_start`, `date_end`, `is_automation`) VALUES
(1, '99.98', 2, '', 'finish', '2024-03-10 04:06:34', '2024-03-10 04:07:05', 0) ;

#
# End of data contents of table `wp_defender_scan`
# --------------------------------------------------------



#
# Delete any existing table `wp_defender_scan_item`
#

DROP TABLE IF EXISTS `wp_defender_scan_item`;


#
# Table structure of table `wp_defender_scan_item`
#

CREATE TABLE `wp_defender_scan_item` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `raw_data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_defender_scan_item`
#
INSERT INTO `wp_defender_scan_item` ( `id`, `parent_id`, `type`, `status`, `raw_data`) VALUES
(1, 1, 'core_integrity', 'active', '{"file":"\\/Users\\/mikey\\/Local Sites\\/white-label-storage-b2c\\/app\\/public\\/local-xdebuginfo.php","type":"unversion"}') ;

#
# End of data contents of table `wp_defender_scan_item`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_moos_oauth_access_tokens`
#

DROP TABLE IF EXISTS `wp_moos_oauth_access_tokens`;


#
# Table structure of table `wp_moos_oauth_access_tokens`
#

CREATE TABLE `wp_moos_oauth_access_tokens` (
  `access_token` varchar(255) DEFAULT NULL,
  `client_id` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `expires` timestamp NULL DEFAULT NULL,
  `scope` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_moos_oauth_access_tokens`
#

#
# End of data contents of table `wp_moos_oauth_access_tokens`
# --------------------------------------------------------



#
# Delete any existing table `wp_moos_oauth_authorization_codes`
#

DROP TABLE IF EXISTS `wp_moos_oauth_authorization_codes`;


#
# Table structure of table `wp_moos_oauth_authorization_codes`
#

CREATE TABLE `wp_moos_oauth_authorization_codes` (
  `authorization_code` varchar(255) DEFAULT NULL,
  `client_id` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `redirect_uri` varchar(255) DEFAULT NULL,
  `expires` timestamp NULL DEFAULT NULL,
  `scope` varchar(255) DEFAULT NULL,
  `id_token` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_moos_oauth_authorization_codes`
#

#
# End of data contents of table `wp_moos_oauth_authorization_codes`
# --------------------------------------------------------



#
# Delete any existing table `wp_moos_oauth_authorized_apps`
#

DROP TABLE IF EXISTS `wp_moos_oauth_authorized_apps`;


#
# Table structure of table `wp_moos_oauth_authorized_apps`
#

CREATE TABLE `wp_moos_oauth_authorized_apps` (
  `client_id` text,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_moos_oauth_authorized_apps`
#

#
# End of data contents of table `wp_moos_oauth_authorized_apps`
# --------------------------------------------------------



#
# Delete any existing table `wp_moos_oauth_clients`
#

DROP TABLE IF EXISTS `wp_moos_oauth_clients`;


#
# Table structure of table `wp_moos_oauth_clients`
#

CREATE TABLE `wp_moos_oauth_clients` (
  `client_name` varchar(255) DEFAULT NULL,
  `client_id` varchar(255) DEFAULT NULL,
  `client_secret` varchar(255) DEFAULT NULL,
  `redirect_uri` varchar(255) DEFAULT NULL,
  `active_oauth_server_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_moos_oauth_clients`
#

#
# End of data contents of table `wp_moos_oauth_clients`
# --------------------------------------------------------



#
# Delete any existing table `wp_moos_oauth_public_keys`
#

DROP TABLE IF EXISTS `wp_moos_oauth_public_keys`;


#
# Table structure of table `wp_moos_oauth_public_keys`
#

CREATE TABLE `wp_moos_oauth_public_keys` (
  `client_id` varchar(80) DEFAULT NULL,
  `public_key` varchar(8000) DEFAULT NULL,
  `private_key` varchar(8000) DEFAULT NULL,
  `encryption_algorithm` varchar(80) DEFAULT 'RS256'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_moos_oauth_public_keys`
#

#
# End of data contents of table `wp_moos_oauth_public_keys`
# --------------------------------------------------------



#
# Delete any existing table `wp_moos_oauth_refresh_tokens`
#

DROP TABLE IF EXISTS `wp_moos_oauth_refresh_tokens`;


#
# Table structure of table `wp_moos_oauth_refresh_tokens`
#

CREATE TABLE `wp_moos_oauth_refresh_tokens` (
  `refresh_token` varchar(255) DEFAULT NULL,
  `client_id` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `expires` timestamp NULL DEFAULT NULL,
  `scope` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_moos_oauth_refresh_tokens`
#

#
# End of data contents of table `wp_moos_oauth_refresh_tokens`
# --------------------------------------------------------



#
# Delete any existing table `wp_moos_oauth_scopes`
#

DROP TABLE IF EXISTS `wp_moos_oauth_scopes`;


#
# Table structure of table `wp_moos_oauth_scopes`
#

CREATE TABLE `wp_moos_oauth_scopes` (
  `scope` varchar(100) DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT NULL,
  UNIQUE KEY `scope` (`scope`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_moos_oauth_scopes`
#
INSERT INTO `wp_moos_oauth_scopes` ( `scope`, `is_default`) VALUES
('email', 1),
('profile', 0) ;

#
# End of data contents of table `wp_moos_oauth_scopes`
# --------------------------------------------------------



#
# Delete any existing table `wp_moos_oauth_users`
#

DROP TABLE IF EXISTS `wp_moos_oauth_users`;


#
# Table structure of table `wp_moos_oauth_users`
#

CREATE TABLE `wp_moos_oauth_users` (
  `username` varchar(100) NOT NULL,
  `password` varchar(2000) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_moos_oauth_users`
#

#
# End of data contents of table `wp_moos_oauth_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=505 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://white-label-storage-b2c.local', 'yes'),
(2, 'home', 'http://white-label-storage-b2c.local', 'yes'),
(3, 'blogname', 'White Label Storage B2c', 'yes'),
(4, 'blogdescription', 'Your trusted partner', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'mike@reccenter.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '50', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', '', 'yes'),
(20, 'default_ping_status', '', 'yes'),
(21, 'default_pingback_flag', '', 'yes'),
(22, 'posts_per_page', '50', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/blog/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:107:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:52:"blog/category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:47:"blog/category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:28:"blog/category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:40:"blog/category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:22:"blog/category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:49:"blog/tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:44:"blog/tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:25:"blog/tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:37:"blog/tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:19:"blog/tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:50:"blog/type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:45:"blog/type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:26:"blog/type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:38:"blog/type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:20:"blog/type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:36:"blog/units/.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:46:"blog/units/.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:66:"blog/units/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"blog/units/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"blog/units/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:42:"blog/units/.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:25:"blog/units/(.+?)/embed/?$";s:38:"index.php?units=$matches[1]&embed=true";s:29:"blog/units/(.+?)/trackback/?$";s:32:"index.php?units=$matches[1]&tb=1";s:37:"blog/units/(.+?)/page/?([0-9]{1,})/?$";s:45:"index.php?units=$matches[1]&paged=$matches[2]";s:44:"blog/units/(.+?)/comment-page-([0-9]{1,})/?$";s:45:"index.php?units=$matches[1]&cpage=$matches[2]";s:33:"blog/units/(.+?)(?:/([0-9]+))?/?$";s:44:"index.php?units=$matches[1]&page=$matches[2]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:13:"favicon\\.ico$";s:19:"index.php?favicon=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:16:".*wp-signup.php$";s:21:"index.php?signup=true";s:18:".*wp-activate.php$";s:23:"index.php?activate=true";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=8&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:52:"blog/author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:47:"blog/author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:28:"blog/author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:40:"blog/author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:22:"blog/author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:74:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:69:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:50:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:62:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:44:"blog/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:61:"blog/([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:56:"blog/([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:37:"blog/([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:49:"blog/([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:31:"blog/([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:48:"blog/([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:43:"blog/([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:24:"blog/([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:36:"blog/([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:18:"blog/([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:32:"blog/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:"blog/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:"blog/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"blog/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"blog/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"blog/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:21:"blog/([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:25:"blog/([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:45:"blog/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:40:"blog/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:33:"blog/([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:40:"blog/([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:29:"blog/([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:21:"blog/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:31:"blog/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:51:"blog/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"blog/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"blog/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:27:"blog/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:0:{}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:2:{i:0;s:104:"/Users/mikey/Local Sites/white-label-storage-b2c/app/public/wp-content/themes/twentytwentyfour/style.css";i:1;s:0:"";}', 'no'),
(40, 'template', 'sage-10', 'yes'),
(41, 'stylesheet', 'sage-10', 'yes'),
(42, 'comment_registration', '1', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '56657', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '500', 'yes'),
(57, 'thumbnail_size_h', '500', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '800', 'yes'),
(60, 'medium_size_h', '9999', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1500', 'yes'),
(63, 'large_size_h', '9999', 'yes'),
(64, 'image_default_link_type', '', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '1', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:0:{}', 'yes'),
(77, 'widget_text', 'a:0:{}', 'yes'),
(78, 'widget_rss', 'a:0:{}', 'yes'),
(79, 'uninstall_plugins', 'a:1:{s:43:"dreamhost-automated-migration/dreamhost.php";a:2:{i:0;s:10:"DHWPAction";i:1;s:9:"uninstall";}}', 'no'),
(80, 'timezone_string', 'America/New_York', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '8', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '', 'yes'),
(91, 'admin_email_lifespan', '1725571242', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'wp_attachment_pages_enabled', '0', 'yes'),
(100, 'initial_db_version', '56657', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:67:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:17:"aioseo_manage_seo";b:1;s:20:"aioseo_page_analysis";b:1;s:28:"aioseo_page_general_settings";b:1;s:29:"aioseo_page_advanced_settings";b:1;s:27:"aioseo_page_schema_settings";b:1;s:27:"aioseo_page_social_settings";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:39:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:20:"aioseo_page_analysis";b:1;s:28:"aioseo_page_general_settings";b:1;s:29:"aioseo_page_advanced_settings";b:1;s:27:"aioseo_page_schema_settings";b:1;s:27:"aioseo_page_social_settings";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:15:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"aioseo_page_analysis";b:1;s:28:"aioseo_page_general_settings";b:1;s:29:"aioseo_page_advanced_settings";b:1;s:27:"aioseo_page_schema_settings";b:1;s:27:"aioseo_page_social_settings";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:10:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:20:"aioseo_page_analysis";b:1;s:28:"aioseo_page_general_settings";b:1;s:29:"aioseo_page_advanced_settings";b:1;s:27:"aioseo_page_schema_settings";b:1;s:27:"aioseo_page_social_settings";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(102, 'fresh_site', '0', 'yes'),
(103, 'user_count', '1', 'no'),
(104, 'widget_block', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:0:{}s:15:"sidebar-primary";a:0:{}s:14:"sidebar-footer";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(106, 'upload_space_check_disabled', '1', 'no'),
(107, 'cron', 'a:8:{i:1710458034;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1710458053;a:3:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:21:"update_network_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1710458054;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1710494442;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1710643505;a:1:{s:30:"wp_delete_temp_updater_backups";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1710689311;a:1:{s:37:"mo_oauth_server_debug_delete_cron_job";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1710710442;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes'),
(108, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(118, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(120, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(121, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(128, 'theme_mods_twentytwentyfour', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1710044442;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(143, 'finished_updating_comment_type', '1', 'yes'),
(147, 'acf_first_activated_version', '6.2.7', 'yes'),
(148, 'action_scheduler_hybrid_store_demarkation', '6', 'yes'),
(149, 'schema-ActionScheduler_StoreSchema', '7.0.1710043564', 'yes'),
(150, 'schema-ActionScheduler_LoggerSchema', '3.0.1710043564', 'yes'),
(151, 'action_scheduler_lock_async-request-runner', '1710070421', 'yes'),
(152, 'aioseo_options_internal', '{"internal":{"validLicenseKey":null,"lastActiveVersion":"4.5.8","migratedVersion":"0.0","siteAnalysis":{"connectToken":null,"score":0,"results":null,"competitors":[]},"headlineAnalysis":{"headlines":[]},"wizard":null,"category":null,"categoryOther":null,"deprecatedOptions":[],"searchStatistics":{"profile":[],"trustToken":null,"rolling":"last28Days"}},"integrations":{"semrush":{"accessToken":null,"tokenType":null,"expires":null,"refreshToken":null}},"database":{"installedTables":"{\\"wp_aioseo_posts\\":[\\"id\\",\\"post_id\\",\\"title\\",\\"description\\",\\"keywords\\",\\"keyphrases\\",\\"page_analysis\\",\\"primary_term\\",\\"canonical_url\\",\\"og_title\\",\\"og_description\\",\\"og_object_type\\",\\"og_image_type\\",\\"og_image_url\\",\\"og_image_width\\",\\"og_image_height\\",\\"og_image_custom_url\\",\\"og_image_custom_fields\\",\\"og_video\\",\\"og_custom_url\\",\\"og_article_section\\",\\"og_article_tags\\",\\"twitter_use_og\\",\\"twitter_card\\",\\"twitter_image_type\\",\\"twitter_image_url\\",\\"twitter_image_custom_url\\",\\"twitter_image_custom_fields\\",\\"twitter_title\\",\\"twitter_description\\",\\"seo_score\\",\\"schema\\",\\"schema_type\\",\\"schema_type_options\\",\\"pillar_content\\",\\"robots_default\\",\\"robots_noindex\\",\\"robots_noarchive\\",\\"robots_nosnippet\\",\\"robots_nofollow\\",\\"robots_noimageindex\\",\\"robots_noodp\\",\\"robots_notranslate\\",\\"robots_max_snippet\\",\\"robots_max_videopreview\\",\\"robots_max_imagepreview\\",\\"images\\",\\"image_scan_date\\",\\"priority\\",\\"frequency\\",\\"videos\\",\\"video_thumbnail\\",\\"video_scan_date\\",\\"local_seo\\",\\"limit_modified_date\\",\\"options\\",\\"created\\",\\"updated\\"],\\"wp_actionscheduler_actions\\":[],\\"wp_actionscheduler_logs\\":[],\\"wp_actionscheduler_groups\\":[],\\"wp_actionscheduler_claims\\":[],\\"wp_aioseo_notifications\\":[]}"}}', 'yes'),
(153, 'aioseo_options_internal_lite', '{"internal":{"activated":1710043564,"firstActivated":1710043564,"installed":0,"connect":{"key":null,"time":0,"network":false,"token":null}}}', 'yes'),
(154, 'gutenberg_font_family_format_converted', '1', 'yes'),
(157, 'gutenberg_version_migration', '9.8.0', 'yes'),
(158, 'aioseo_options_dynamic_localized', 'a:4:{s:42:"searchAppearance_taxonomies_category_title";s:41:"#taxonomy_title #separator_sa #site_title";s:52:"searchAppearance_taxonomies_category_metaDescription";s:21:"#taxonomy_description";s:42:"searchAppearance_taxonomies_post_tag_title";s:41:"#taxonomy_title #separator_sa #site_title";s:52:"searchAppearance_taxonomies_post_tag_metaDescription";s:21:"#taxonomy_description";}', 'yes'),
(161, 'aioseo_dynamic_settings_backup', '[]', 'yes'),
(162, 'acf_version', '6.2.7', 'yes'),
(163, 'aioseo_options', '{"internal":[],"webmasterTools":{"google":null,"bing":null,"yandex":null,"baidu":null,"pinterest":null,"microsoftClarityProjectId":null,"norton":null,"miscellaneousVerification":null},"breadcrumbs":{"enable":true,"separator":"&raquo;","homepageLink":true,"homepageLabel":"Home","breadcrumbPrefix":"","archiveFormat":"Archives for #breadcrumb_archive_post_type_name","searchResultFormat":"Search Results for \'#breadcrumb_search_string\'","errorFormat404":"404 - Page Not Found","showCurrentItem":true,"linkCurrentItem":false,"categoryFullHierarchy":false,"showBlogHome":false},"rssContent":{"before":null,"after":"&lt;p&gt;The post #post_link first appeared on #site_link.&lt;\\/p&gt;"},"advanced":{"truSeo":true,"headlineAnalyzer":true,"seoAnalysis":true,"dashboardWidgets":["seoSetup","seoOverview","seoNews"],"announcements":true,"postTypes":{"all":true,"included":["post","page","product"]},"taxonomies":{"all":true,"included":["category","post_tag","product_cat","product_tag"]},"uninstall":false},"sitemap":{"general":{"enable":true,"filename":"sitemap","indexes":true,"linksPerIndex":1000,"postTypes":{"all":true,"included":["post","page","attachment","product"]},"taxonomies":{"all":true,"included":["category","post_tag","product_cat","product_tag"]},"author":false,"date":false,"additionalPages":{"enable":false,"pages":[]},"advancedSettings":{"enable":false,"excludeImages":false,"excludePosts":[],"excludeTerms":[],"priority":{"homePage":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"},"postTypes":{"grouped":true,"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"},"taxonomies":{"grouped":true,"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"},"archive":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"},"author":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"}}}},"rss":{"enable":true,"linksPerIndex":50,"postTypes":{"all":true,"included":["post","page","product"]}},"html":{"enable":true,"pageUrl":"","postTypes":{"all":true,"included":["post","page","product"]},"taxonomies":{"all":true,"included":["category","post_tag","product_cat","product_tag"]},"sortOrder":"publish_date","sortDirection":"asc","publicationDate":true,"compactArchives":false,"advancedSettings":{"enable":false,"nofollowLinks":false,"excludePosts":[],"excludeTerms":[]}}},"social":{"profiles":{"sameUsername":{"enable":false,"username":null,"included":["facebookPageUrl","twitterUrl","tiktokUrl","pinterestUrl","instagramUrl","youtubeUrl","linkedinUrl"]},"urls":{"facebookPageUrl":null,"twitterUrl":null,"instagramUrl":null,"tiktokUrl":null,"pinterestUrl":null,"youtubeUrl":null,"linkedinUrl":null,"tumblrUrl":null,"yelpPageUrl":null,"soundCloudUrl":null,"wikipediaUrl":null,"myspaceUrl":null,"googlePlacesUrl":null},"additionalUrls":null},"facebook":{"general":{"enable":true,"defaultImageSourcePosts":"default","customFieldImagePosts":null,"defaultImagePosts":"","defaultImagePostsWidth":"","defaultImagePostsHeight":"","showAuthor":true,"siteName":"#site_title #separator_sa #tagline"},"homePage":{"image":"","title":"","description":"","imageWidth":"","imageHeight":"","objectType":"website"},"advanced":{"enable":false,"adminId":"","appId":"","authorUrl":"","generateArticleTags":false,"useKeywordsInTags":true,"useCategoriesInTags":true,"usePostTagsInTags":true}},"twitter":{"general":{"enable":true,"useOgData":false,"defaultCardType":"summary_large_image","defaultImageSourcePosts":"default","customFieldImagePosts":null,"defaultImagePosts":"","showAuthor":true,"additionalData":false},"homePage":{"image":"","title":"","description":"","cardType":"summary"}}},"searchAppearance":{"global":{"separator":"&#45;","siteTitle":"#site_title #separator_sa #tagline","metaDescription":"#tagline","keywords":null,"schema":{"websiteName":"White Label Storage B2c","websiteAlternateName":null,"siteRepresents":"organization","person":null,"organizationName":"White Label Storage B2c","organizationLogo":"","personName":null,"personLogo":null,"phone":null,"contactType":null,"contactTypeManual":null}},"advanced":{"globalRobotsMeta":{"default":true,"noindex":false,"nofollow":false,"noindexPaginated":true,"nofollowPaginated":true,"noindexFeed":true,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"sitelinks":true,"noIndexEmptyCat":true,"removeStopWords":false,"noPaginationForCanonical":true,"useKeywords":false,"keywordsLooking":true,"useCategoriesForMetaKeywords":false,"useTagsForMetaKeywords":false,"dynamicallyGenerateKeywords":false,"pagedFormat":"#separator_sa Page #page_number","runShortcodes":false,"crawlCleanup":{"enable":false,"feeds":{"global":true,"globalComments":false,"staticBlogPage":true,"authors":true,"postComments":false,"search":false,"attachments":false,"archives":{"all":false,"included":[]},"taxonomies":{"all":false,"included":["category"]},"atom":false,"rdf":false,"paginated":false}},"blockArgs":{"enable":false,"logsRetention":"{\\"label\\":\\"1 week\\",\\"value\\":\\"week\\"}"}},"archives":{"author":{"show":true,"title":"#author_name #separator_sa #site_title","metaDescription":"#author_bio","advanced":{"robotsMeta":{"default":true,"noindex":false,"nofollow":false,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"showDateInGooglePreview":true,"showPostThumbnailInSearch":true,"showMetaBox":true,"keywords":null}},"date":{"show":true,"title":"#archive_date #separator_sa #site_title","metaDescription":"","advanced":{"robotsMeta":{"default":true,"noindex":false,"nofollow":false,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"showDateInGooglePreview":true,"showPostThumbnailInSearch":true,"showMetaBox":true,"keywords":null}},"search":{"show":false,"title":"#search_term #separator_sa #site_title","metaDescription":"","advanced":{"robotsMeta":{"default":false,"noindex":true,"nofollow":false,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"showDateInGooglePreview":true,"showPostThumbnailInSearch":true,"showMetaBox":true,"keywords":null}}}},"searchStatistics":{"postTypes":{"all":true,"included":["post","page"]}},"tools":{"robots":{"enable":false,"rules":[],"robotsDetected":true},"importExport":{"backup":{"lastTime":null,"data":null}}},"deprecated":{"searchAppearance":{"global":{"descriptionFormat":null,"schema":{"enableSchemaMarkup":true}},"advanced":{"autogenerateDescriptions":true,"runShortcodesInDescription":true,"useContentForAutogeneratedDescriptions":false,"excludePosts":[],"excludeTerms":[]}},"sitemap":{"general":{"advancedSettings":{"dynamic":true}}},"tools":{"blocker":{"blockBots":null,"blockReferer":null,"track":null,"custom":{"enable":null,"bots":"Abonti\\naggregator\\nAhrefsBot\\nasterias\\nBDCbot\\nBLEXBot\\nBuiltBotTough\\nBullseye\\nBunnySlippers\\nca-crawler\\nCCBot\\nCegbfeieh\\nCheeseBot\\nCherryPicker\\nCopyRightCheck\\ncosmos\\nCrescent\\ndiscobot\\nDittoSpyder\\nDotBot\\nDownload Ninja\\nEasouSpider\\nEmailCollector\\nEmailSiphon\\nEmailWolf\\nEroCrawler\\nExtractorPro\\nFasterfox\\nFeedBooster\\nFoobot\\nGenieo\\ngrub-client\\nHarvest\\nhloader\\nhttplib\\nHTTrack\\nhumanlinks\\nieautodiscovery\\nInfoNaviRobot\\nIstellaBot\\nJava\\/1.\\nJennyBot\\nk2spider\\nKenjin Spider\\nKeyword Density\\/0.9\\nlarbin\\nLexiBot\\nlibWeb\\nlibwww\\nLinkextractorPro\\nlinko\\nLinkScan\\/8.1a Unix\\nLinkWalker\\nLNSpiderguy\\nlwp-trivial\\nmagpie\\nMata Hari\\nMaxPointCrawler\\nMegaIndex\\nMicrosoft URL Control\\nMIIxpc\\nMippin\\nMissigua Locator\\nMister PiX\\nMJ12bot\\nmoget\\nMSIECrawler\\nNetAnts\\nNICErsPRO\\nNiki-Bot\\nNPBot\\nNutch\\nOffline Explorer\\nOpenfind\\npanscient.com\\nPHP\\/5.{\\nProPowerBot\\/2.14\\nProWebWalker\\nPython-urllib\\nQueryN Metasearch\\nRepoMonkey\\nSISTRIX\\nsitecheck.Internetseer.com\\nSiteSnagger\\nSnapPreviewBot\\nSogou\\nSpankBot\\nspanner\\nspbot\\nSpinn3r\\nsuzuran\\nSzukacz\\/1.4\\nTeleport\\nTelesoft\\nThe Intraformant\\nTheNomad\\nTightTwatBot\\nTitan\\ntoCrawl\\/UrlDispatcher\\nTrue_Robot\\nturingos\\nTurnitinBot\\nUbiCrawler\\nUnisterBot\\nURLy Warning\\nVCI\\nWBSearchBot\\nWeb Downloader\\/6.9\\nWeb Image Collector\\nWebAuto\\nWebBandit\\nWebCopier\\nWebEnhancer\\nWebmasterWorldForumBot\\nWebReaper\\nWebSauger\\nWebsite Quester\\nWebster Pro\\nWebStripper\\nWebZip\\nWotbox\\nwsr-agent\\nWWW-Collector-E\\nXenu\\nZao\\nZeus\\nZyBORG\\ncoccoc\\nIncutio\\nlmspider\\nmemoryBot\\nserf\\nUnknown\\nuptime files","referer":"semalt.com\\nkambasoft.com\\nsavetubevideo.com\\nbuttons-for-website.com\\nsharebutton.net\\nsoundfrost.org\\nsrecorder.com\\nsoftomix.com\\nsoftomix.net\\nmyprintscreen.com\\njoinandplay.me\\nfbfreegifts.com\\nopenmediasoft.com\\nzazagames.org\\nextener.org\\nopenfrost.com\\nopenfrost.net\\ngooglsucks.com\\nbest-seo-offer.com\\nbuttons-for-your-website.com\\nwww.Get-Free-Traffic-Now.com\\nbest-seo-solution.com\\nbuy-cheap-online.info\\nsite3.free-share-buttons.com\\nwebmaster-traffic.com"}}}}}', 'yes'),
(164, 'aioseo_options_lite', '{"advanced":{"usageTracking":false}}', 'yes'),
(165, 'aioseo_options_dynamic', '{"sitemap":{"priority":{"postTypes":{"post":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"},"page":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"},"attachment":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"}},"taxonomies":{"category":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"},"post_tag":{"priority":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}","frequency":"{\\"label\\":\\"default\\",\\"value\\":\\"default\\"}"}}}},"social":{"facebook":{"general":{"postTypes":{"post":{"objectType":"article"},"page":{"objectType":"article"},"attachment":{"objectType":"article"}}}}},"searchAppearance":{"postTypes":{"post":{"show":true,"advanced":{"robotsMeta":{"default":true,"noindex":false,"nofollow":false,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"showDateInGooglePreview":true,"showPostThumbnailInSearch":true,"showMetaBox":true,"bulkEditing":"enabled"},"title":"#post_title #separator_sa #site_title","metaDescription":"#post_excerpt","schemaType":"Article","webPageType":"WebPage","articleType":"BlogPosting","customFields":null},"page":{"show":true,"advanced":{"robotsMeta":{"default":true,"noindex":false,"nofollow":false,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"showDateInGooglePreview":true,"showPostThumbnailInSearch":true,"showMetaBox":true,"bulkEditing":"enabled"},"title":"#post_title #separator_sa #site_title","metaDescription":"#post_content","schemaType":"WebPage","webPageType":"WebPage","articleType":"BlogPosting","customFields":null},"attachment":{"show":true,"advanced":{"robotsMeta":{"default":true,"noindex":false,"nofollow":false,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"showDateInGooglePreview":true,"showPostThumbnailInSearch":true,"showMetaBox":true,"bulkEditing":"enabled"},"title":"#post_title #separator_sa #site_title","metaDescription":"#attachment_caption","schemaType":"ItemPage","webPageType":"ItemPage","articleType":"BlogPosting","customFields":null,"redirectAttachmentUrls":"attachment"}},"taxonomies":{"category":{"show":true,"advanced":{"robotsMeta":{"default":true,"noindex":false,"nofollow":false,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"showDateInGooglePreview":true,"showPostThumbnailInSearch":true,"showMetaBox":true},"title":"#taxonomy_title #separator_sa #site_title","metaDescription":"#taxonomy_description"},"post_tag":{"show":true,"advanced":{"robotsMeta":{"default":true,"noindex":false,"nofollow":false,"noarchive":false,"noimageindex":false,"notranslate":false,"nosnippet":false,"noodp":false,"maxSnippet":-1,"maxVideoPreview":-1,"maxImagePreview":"large"},"showDateInGooglePreview":true,"showPostThumbnailInSearch":true,"showMetaBox":true},"title":"#taxonomy_title #separator_sa #site_title","metaDescription":"#taxonomy_description"}},"archives":[]}}', 'yes'),
(194, 'current_theme', 'White Label Storage - B2C Multisite', 'yes'),
(195, 'theme_mods_sage-10', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(196, 'theme_switched', '', 'yes'),
(198, 'recently_activated', 'a:2:{s:23:"gutenberg/gutenberg.php";i:1710341087;s:34:"advanced-custom-fields-pro/acf.php";i:1710285987;}', 'yes'),
(249, 'WPLANG', '', 'yes'),
(250, 'new_admin_email', 'mike@reccenter.com', 'yes'),
(269, 'cptui_post_types', 'a:1:{s:5:"units";a:34:{s:4:"name";s:5:"units";s:5:"label";s:5:"Units";s:14:"singular_label";s:4:"Unit";s:11:"description";s:0:"";s:6:"public";s:4:"true";s:18:"publicly_queryable";s:4:"true";s:7:"show_ui";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:16:"delete_with_user";s:5:"false";s:12:"show_in_rest";s:4:"true";s:9:"rest_base";s:0:"";s:21:"rest_controller_class";s:0:"";s:14:"rest_namespace";s:0:"";s:11:"has_archive";s:5:"false";s:18:"has_archive_string";s:0:"";s:19:"exclude_from_search";s:5:"false";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:4:"true";s:10:"can_export";s:4:"true";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:4:"true";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:70:"https://white-label-storage-b2c.local/app/uploads/2024/03/WLS-Icon.png";s:20:"register_meta_box_cb";N;s:8:"supports";a:4:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:9:"thumbnail";i:3;s:15:"page-attributes";}s:10:"taxonomies";a:0:{}s:6:"labels";a:31:{s:9:"menu_name";s:5:"Units";s:9:"all_items";s:9:"All units";s:7:"add_new";s:7:"Add new";s:12:"add_new_item";s:13:"Add new units";s:9:"edit_item";s:10:"Edit units";s:8:"new_item";s:9:"New units";s:9:"view_item";s:10:"View units";s:10:"view_items";s:10:"View units";s:12:"search_items";s:12:"Search units";s:9:"not_found";s:14:"No units found";s:18:"not_found_in_trash";s:23:"No units found in trash";s:6:"parent";s:13:"Parent units:";s:14:"featured_image";s:29:"Featured image for this units";s:18:"set_featured_image";s:33:"Set featured image for this units";s:21:"remove_featured_image";s:36:"Remove featured image for this units";s:18:"use_featured_image";s:36:"Use as featured image for this units";s:8:"archives";s:14:"units archives";s:16:"insert_into_item";s:17:"Insert into units";s:21:"uploaded_to_this_item";s:20:"Upload to this units";s:17:"filter_items_list";s:17:"Filter units list";s:21:"items_list_navigation";s:21:"units list navigation";s:10:"items_list";s:10:"units list";s:10:"attributes";s:16:"units attributes";s:14:"name_admin_bar";s:5:"units";s:14:"item_published";s:15:"units published";s:24:"item_published_privately";s:26:"units published privately.";s:22:"item_reverted_to_draft";s:24:"units reverted to draft.";s:12:"item_trashed";s:14:"units trashed.";s:14:"item_scheduled";s:15:"units scheduled";s:12:"item_updated";s:14:"units updated.";s:17:"parent_item_colon";s:13:"Parent units:";}s:15:"custom_supports";s:0:"";s:16:"enter_title_here";s:9:"Add units";}}', 'yes'),
(275, 'post_count', '0', 'yes'),
(296, 'category_children', 'a:0:{}', 'yes'),
(309, 'wpgetapi_setup', 'a:1:{s:4:"apis";a:1:{i:0;a:3:{s:4:"name";s:9:"StoreEDGE";s:2:"id";s:9:"storeedge";s:8:"base_url";s:52:"https://storage-api-tawny.vercel.app/storage-service";}}}', 'no'),
(311, 'mo_custom_api_wp_version', '2.9.0', 'yes'),
(317, 'mo_rest_api_protect_migrate', '1', 'yes'),
(319, 'mo_api_authentication_jwt_client_secret', 'zzA1tAsE8xYiRRQO55d2mJ6SXQQ1npZb', 'yes'),
(320, 'mo_api_authentication_jwt_signing_algorithm', 'HS256', 'yes'),
(321, 'mo_custom_api_form1', 'a:1:{s:7:"ApiName";s:0:"";}', 'yes'),
(323, 'mo_save_settings', '0', 'yes'),
(324, 'mo_rest_api_show_popup', '1', 'yes'),
(407, 'edd_sl_33ed56f74cc3dde849dd3b5d3388eddf', 'a:2:{s:7:"timeout";i:1710463488;s:5:"value";s:8022:"{"new_version":"1.3.14","stable_version":"1.3.14","name":"API to Posts","slug":"wpgetapi-api-to-posts","url":"https:\\/\\/wpgetapi.com\\/downloads\\/api-to-posts\\/?changelog=1","last_updated":"2024-01-04 15:23:36","homepage":"https:\\/\\/wpgetapi.com\\/downloads\\/api-to-posts\\/","package":"","download_link":"","sections":{"description":"<p>Import data from your API and use this data to create custom posts or WooCommerce products within WordPress. Map your API data to custom fields, tags, categories, images and more.<br \\/>Keep your posts in sync with your API by setting the automatic sync interval from anywhere between 5 minutes and a week.<\\/p>\\n","changelog":"<p>= 1.3.14 (2023-12-05) =<br \\/>\\n- New - add new filter \'wpgetapi_api_to_posts_get_item_for_mapping\' to allow setting any item to use as the mapping \'base\' item.<\\/p>\\n<p>= 1.3.13 (2023-12-05) =<br \\/>\\n- New - add ability for plugin to \'find\' an images that is buried in sub-arrays when using Featured Image.<\\/p>\\n<p>= 1.3.12 (2023-11-30) =<br \\/>\\n- Update - modify the way taxonomies are recognised in mapping dropdown. Using get_object_taxonomies() now.<\\/p>\\n<p>= 1.3.11 (2023-11-01) =<br \\/>\\n- New - add pagination for Growthhub<\\/p>\\n<p>= 1.3.10 (2023-10-27) =<br \\/>\\n- Fix - delete cron job when turning of automatic sync.<br \\/>\\n- Fix - add check for string within post name creator value.<\\/p>\\n<p>= 1.3.9 (2023-10-24) =<br \\/>\\n- Fix - allow arrays to pass through as JSON if in single field.<\\/p>\\n<p>= 1.3.8 (2023-10-14) =<br \\/>\\n- Fix - error in pagination for Spark API.<\\/p>\\n<p>= 1.3.7 (2023-10-13) =<br \\/>\\n- New - add pagination for Spark API.<\\/p>\\n<p>= 1.3.6 (2023-09-21) =<br \\/>\\n- Update - trime whitespace from values before processing.<br \\/>\\n- Update - allow multiple categories and tags to be added.<\\/p>\\n<p>= 1.3.5 (2023-09-20) =<br \\/>\\n- New - add date fields to data mapping.<br \\/>\\n- Update - modify some checks on the regular_price and sale_price for WooCommerce importing.<\\/p>\\n<p>= 1.3.4 (2023-09-19) =<br \\/>\\n- New - add pagination for trendz API.<\\/p>\\n<p>= 1.3.3 (2023-09-15) =<br \\/>\\n- New - filter \'wpgetapi_api_to_posts_mapped_value\' for modifying a single mapped value.<br \\/>\\n- New - filter \'wpgetapi_api_to_posts_pagination_delay\' for modifying the delay between pagination. Default 0.2 seconds.<br \\/>\\n- New - filter \'wpgetapi_api_to_posts_importer_items_before_save\' for modifying entire items array before starting the saving\\/pagination process.<\\/p>\\n<p>= 1.3.2 (2023-09-12) =<br \\/>\\n- New - new pagination type included for TMDB API.<\\/p>\\n<p>= 1.3.1 (2023-09-07) =<br \\/>\\n- Updates - hiding\\/showing correct fields when choosing the WordPress field type.<\\/p>\\n<p>= 1.3.0 (2023-09-06) =<br \\/>\\n- Breaking Update - add repeatable mapping fields.<br \\/>\\n- Update - make compatible with XML APIs when using PRO.<\\/p>\\n<p>= 1.2.4 (2023-09-05) =<br \\/>\\n- Update - test pagination and include minor updates to get this working.<\\/p>\\n<p>= 1.2.3 (2023-08-30) =<br \\/>\\n- Fix - add user-agent to image upload. Was getting 403 error with some URLs<br \\/>\\n- Fix - add check for $this-&gt;setup_opts[\'apis\'] in class-admin-options.php<\\/p>\\n<p>= 1.2.2 (2023-08-28) =<br \\/>\\n- New - add step down field if value is array in mapping tab.<br \\/>\\n- New - allow to get array value within post title field in mapping.<br \\/>\\n- Fix - issue with adding linked endpoint when it is not a linked endpoint.<\\/p>\\n<p>= 1.2.1 (2023-08-28) =<br \\/>\\n- Fix - error using pp() function from testing. Change to wpgetapi_pp().<\\/p>\\n<p>= 1.2.0 (2023-08-24) =<br \\/>\\n- New - post creator done via AJAX.<br \\/>\\n- New - dashboard added.<br \\/>\\n- Fix - recognise post type correctly on detail data type.<\\/p>\\n<p>= 1.1.0 (2023-08-17) =<br \\/>\\n- New - add \'Detail\' API Type which allows linking multiple endpoints.<br \\/>\\n- New - Sidebar info.<br \\/>\\n- Update - Major UI overhaul. Ensure tabs are working correctly.<br \\/>\\n- Update - Hide Save buttons on Importer and Creator tabs.<\\/p>\\n<p>= 1.0.0 (2023-08-12) =<br \\/>\\n- Initial Release<\\/p>\\n"},"banners":{"high":"","low":""},"icons":[],"msg":"No license key has been provided.","description":["<p>Import data from your API and use this data to create custom posts or WooCommerce products within WordPress. Map your API data to custom fields, tags, categories, images and more.<br \\/>Keep your posts in sync with your API by setting the automatic sync interval from anywhere between 5 minutes and a week.<\\/p>\\n"],"changelog":["<p>= 1.3.14 (2023-12-05) =<br \\/>\\n- New - add new filter \'wpgetapi_api_to_posts_get_item_for_mapping\' to allow setting any item to use as the mapping \'base\' item.<\\/p>\\n<p>= 1.3.13 (2023-12-05) =<br \\/>\\n- New - add ability for plugin to \'find\' an images that is buried in sub-arrays when using Featured Image.<\\/p>\\n<p>= 1.3.12 (2023-11-30) =<br \\/>\\n- Update - modify the way taxonomies are recognised in mapping dropdown. Using get_object_taxonomies() now.<\\/p>\\n<p>= 1.3.11 (2023-11-01) =<br \\/>\\n- New - add pagination for Growthhub<\\/p>\\n<p>= 1.3.10 (2023-10-27) =<br \\/>\\n- Fix - delete cron job when turning of automatic sync.<br \\/>\\n- Fix - add check for string within post name creator value.<\\/p>\\n<p>= 1.3.9 (2023-10-24) =<br \\/>\\n- Fix - allow arrays to pass through as JSON if in single field.<\\/p>\\n<p>= 1.3.8 (2023-10-14) =<br \\/>\\n- Fix - error in pagination for Spark API.<\\/p>\\n<p>= 1.3.7 (2023-10-13) =<br \\/>\\n- New - add pagination for Spark API.<\\/p>\\n<p>= 1.3.6 (2023-09-21) =<br \\/>\\n- Update - trime whitespace from values before processing.<br \\/>\\n- Update - allow multiple categories and tags to be added.<\\/p>\\n<p>= 1.3.5 (2023-09-20) =<br \\/>\\n- New - add date fields to data mapping.<br \\/>\\n- Update - modify some checks on the regular_price and sale_price for WooCommerce importing.<\\/p>\\n<p>= 1.3.4 (2023-09-19) =<br \\/>\\n- New - add pagination for trendz API.<\\/p>\\n<p>= 1.3.3 (2023-09-15) =<br \\/>\\n- New - filter \'wpgetapi_api_to_posts_mapped_value\' for modifying a single mapped value.<br \\/>\\n- New - filter \'wpgetapi_api_to_posts_pagination_delay\' for modifying the delay between pagination. Default 0.2 seconds.<br \\/>\\n- New - filter \'wpgetapi_api_to_posts_importer_items_before_save\' for modifying entire items array before starting the saving\\/pagination process.<\\/p>\\n<p>= 1.3.2 (2023-09-12) =<br \\/>\\n- New - new pagination type included for TMDB API.<\\/p>\\n<p>= 1.3.1 (2023-09-07) =<br \\/>\\n- Updates - hiding\\/showing correct fields when choosing the WordPress field type.<\\/p>\\n<p>= 1.3.0 (2023-09-06) =<br \\/>\\n- Breaking Update - add repeatable mapping fields.<br \\/>\\n- Update - make compatible with XML APIs when using PRO.<\\/p>\\n<p>= 1.2.4 (2023-09-05) =<br \\/>\\n- Update - test pagination and include minor updates to get this working.<\\/p>\\n<p>= 1.2.3 (2023-08-30) =<br \\/>\\n- Fix - add user-agent to image upload. Was getting 403 error with some URLs<br \\/>\\n- Fix - add check for $this-&gt;setup_opts[\'apis\'] in class-admin-options.php<\\/p>\\n<p>= 1.2.2 (2023-08-28) =<br \\/>\\n- New - add step down field if value is array in mapping tab.<br \\/>\\n- New - allow to get array value within post title field in mapping.<br \\/>\\n- Fix - issue with adding linked endpoint when it is not a linked endpoint.<\\/p>\\n<p>= 1.2.1 (2023-08-28) =<br \\/>\\n- Fix - error using pp() function from testing. Change to wpgetapi_pp().<\\/p>\\n<p>= 1.2.0 (2023-08-24) =<br \\/>\\n- New - post creator done via AJAX.<br \\/>\\n- New - dashboard added.<br \\/>\\n- Fix - recognise post type correctly on detail data type.<\\/p>\\n<p>= 1.1.0 (2023-08-17) =<br \\/>\\n- New - add \'Detail\' API Type which allows linking multiple endpoints.<br \\/>\\n- New - Sidebar info.<br \\/>\\n- Update - Major UI overhaul. Ensure tabs are working correctly.<br \\/>\\n- Update - Hide Save buttons on Importer and Creator tabs.<\\/p>\\n<p>= 1.0.0 (2023-08-12) =<br \\/>\\n- Initial Release<\\/p>\\n"],"plugin":"wpgetapi-api-to-posts\\/wpgetapi-api-to-posts.php","id":"wpgetapi-api-to-posts\\/wpgetapi-api-to-posts.php","tested":null}";}', 'no'),
(412, 'venobox_settings', 'a:14:{s:13:"ng_all_images";s:1:"1";s:15:"ng_title_select";s:1:"1";s:17:"ng_title_position";s:3:"top";s:21:"ng_numeratio_position";s:3:"top";s:13:"ng_infinigall";s:1:"1";s:10:"ng_overlay";s:16:"rgba(0,0,0,0.85)";s:15:"ng_nav_elements";s:4:"#fff";s:18:"ng_nav_elements_bg";s:16:"rgba(0,0,0,0.85)";s:15:"ng_border_width";s:0:"";s:15:"ng_border_color";s:19:"rgba(255,255,255,1)";s:13:"ng_all_videos";s:1:"1";s:11:"ng_autoplay";s:1:"1";s:12:"ng_preloader";s:13:"double-bounce";s:14:"ng_vb_searchfp";s:1:"1";}', 'yes'),
(449, 'options_company_title', 'Company', 'no'),
(450, '_options_company_title', 'field_65f32f35af40c', 'no'),
(451, 'options_footer_logo', '176', 'no'),
(452, '_options_footer_logo', 'field_65f32fc2af411', 'no'),
(453, 'options_footer_phone', '610-601-6009', 'no'),
(454, '_options_footer_phone', 'field_65f32f52af40d', 'no'),
(455, 'options_footer_address', '31 Catherine Street Shillington, PA 19607', 'no'),
(456, '_options_footer_address', 'field_65f32f6aaf40e', 'no'),
(457, 'options_footer_email', '', 'no'),
(458, '_options_footer_email', 'field_65f32f90af40f', 'no'),
(459, 'options_footer_legal_line', 'Powered by White Label Storage', 'no'),
(460, '_options_footer_legal_line', 'field_65f32fa9af410', 'no'),
(461, 'options_footer_all_rights_reserved', 'WSL - All Rights Reserved', 'no'),
(462, '_options_footer_all_rights_reserved', 'field_65f3335b9fc62', 'no'),
(465, 'ai1wm_updater', 'a:1:{s:43:"all-in-one-wp-migration-multisite-extension";a:13:{s:4:"name";s:19:"Multisite Extension";s:4:"slug";s:19:"multisite-extension";s:8:"homepage";s:51:"https://servmask.com/extensions/multisite-extension";s:13:"download_link";s:29:"https://servmask.com/purchase";s:7:"version";s:4:"4.34";s:6:"author";s:8:"ServMask";s:15:"author_homepage";s:20:"https://servmask.com";s:8:"sections";a:1:{s:11:"description";s:553:"<ul class="description"><li>Export single site from the network</li><li>Export multiple sites from the network</li><li>Export the whole network</li><li>Import single site into the network</li><li>Import multiple sites into the network</li><li>Import a network</li><li>Clone single site within a network</li><li>Multi-network  support</li><li>Use on any number of websites that you own</li><li>Reset Hub: Reset tools for efficient site management new</li><li>Unlimited Extension included</li><li>WP CLI commands included</li><li>Premium support</li></ul>";}s:7:"banners";a:2:{s:3:"low";s:65:"https://servmask.com/img/products/multisite-extension-772x250.png";s:4:"high";s:66:"https://servmask.com/img/products/multisite-extension-1544x500.png";}s:5:"icons";a:3:{s:2:"1x";s:65:"https://servmask.com/img/products/multisite-extension-128x128.png";s:2:"2x";s:65:"https://servmask.com/img/products/multisite-extension-256x256.png";s:7:"default";s:65:"https://servmask.com/img/products/multisite-extension-256x256.png";}s:6:"rating";i:99;s:11:"num_ratings";i:509;s:10:"downloaded";i:50188;}}', 'yes'),
(476, 'options_header_logo', '20', 'no'),
(477, '_options_header_logo', 'field_65edb35ae9d48', 'no'),
(478, 'options_favicon', '17', 'no'),
(479, '_options_favicon', 'field_65eda14004abd', 'no'),
(480, 'options_call_or_text_title', 'Call Or Text Us', 'no'),
(481, '_options_call_or_text_title', 'field_65eddd49043d9', 'no'),
(482, 'options_header_phone_number', '(610) 601-6009', 'no'),
(483, '_options_header_phone_number', 'field_65eddd6c043da', 'no'),
(484, 'options_pay_your_bill_title', 'Pay Your Bill', 'no'),
(485, '_options_pay_your_bill_title', 'field_65eddd9b043db', 'no'),
(486, 'options_bill_payment_link', '#', 'no'),
(487, '_options_bill_payment_link', 'field_65eddda4043dc', 'no'),
(488, 'options_header_code', '', 'no'),
(489, '_options_header_code', 'field_65eda11804abc', 'no'),
(501, 'wp_migrate_addon_schema', '1', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=5145 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 2, '_wp_trash_meta_status', 'publish'),
(4, 2, '_wp_trash_meta_time', '1710069560'),
(5, 2, '_wp_desired_post_slug', 'sample-page'),
(6, 8, '_edit_lock', '1710437171:1'),
(7, 8, '_edit_last', '1'),
(8, 8, '_wp_page_template', 'default'),
(9, 8, '_aioseo_title', NULL),
(10, 8, '_aioseo_description', NULL),
(11, 8, '_aioseo_keywords', ''),
(12, 8, '_aioseo_og_title', NULL),
(13, 8, '_aioseo_og_description', NULL),
(14, 8, '_aioseo_og_article_section', ''),
(15, 8, '_aioseo_og_article_tags', ''),
(16, 8, '_aioseo_twitter_title', NULL),
(17, 8, '_aioseo_twitter_description', NULL),
(18, 6, '_edit_lock', '1710070176:1'),
(22, 1, '_edit_lock', '1710070052:1'),
(23, 1, '_wp_trash_meta_status', 'publish'),
(24, 1, '_wp_trash_meta_time', '1710070196'),
(25, 1, '_wp_desired_post_slug', 'hello-world'),
(26, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(27, 13, '_edit_lock', '1710441462:1'),
(28, 13, '_edit_last', '1'),
(29, 8, 'header_code', ''),
(30, 8, '_header_code', 'field_65eda11804abc'),
(31, 8, 'favicon', '17'),
(32, 8, '_favicon', 'field_65eda14004abd'),
(37, 17, '_wp_attached_file', '2024/03/favicon.png'),
(38, 17, '_wp_attachment_image_alt', 'Favicon'),
(39, 17, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:32;s:6:"height";i:32;s:4:"file";s:19:"2024/03/favicon.png";s:8:"filesize";i:1834;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(44, 20, '_wp_attached_file', '2024/03/Emailsignature-logo.png'),
(45, 20, '_wp_attachment_image_alt', 'White Label Storage'),
(46, 20, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:280;s:6:"height";i:218;s:4:"file";s:31:"2024/03/Emailsignature-logo.png";s:8:"filesize";i:17297;s:5:"sizes";a:1:{s:12:"small-square";a:5:{s:4:"file";s:29:"Emailsignature-logo-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2769;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(47, 8, 'header_logo', '20'),
(48, 8, '_header_logo', 'field_65edb35ae9d48'),
(55, 22, '_edit_lock', '1710090951:1'),
(56, 22, '_edit_last', '1'),
(57, 43, '_wp_attached_file', '2024/03/WLS-Icon.png'),
(58, 43, '_wp_attachment_image_alt', 'Wls Icon'),
(59, 43, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:20;s:6:"height";i:20;s:4:"file";s:20:"2024/03/WLS-Icon.png";s:8:"filesize";i:1244;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(60, 8, 'call_or_text_title', 'Call Or Text Us'),
(61, 8, '_call_or_text_title', 'field_65eddd49043d9'),
(62, 8, 'header_phone_number', '(610) 601-6009'),
(63, 8, '_header_phone_number', 'field_65eddd6c043da'),
(64, 8, 'pay_your_bill_title', 'Pay Your Bill'),
(65, 8, '_pay_your_bill_title', 'field_65eddd9b043db'),
(66, 8, 'bill_payment_link', ''),
(67, 8, '_bill_payment_link', 'field_65eddda4043dc'),
(68, 8, 'company_name', 'Storage Zone'),
(69, 8, '_company_name', 'field_65eddddeee69d'),
(70, 8, 'tagline', 'Get the most value for your dollar at Budget Mini Storage'),
(71, 8, '_tagline', 'field_65edde02ee69e'),
(72, 8, 'company_description', 'Are you in search of the perfect self-storage solution in Rexford, NY? Look no further than Rexford Self Storage!'),
(73, 8, '_company_description', 'field_65edde19ee69f'),
(74, 8, 'address', '31 Catherine Street Shillington, PA 19607'),
(75, 8, '_address', 'field_65edde3bee6a0'),
(76, 8, 'access_hours_title', 'Access Hours'),
(77, 8, '_access_hours_title', 'field_65eddec2ee6a1'),
(78, 8, 'access_hours_monday_friday_hours', '9:00am - 6:00pm'),
(79, 8, '_access_hours_monday_friday_hours', 'field_65eddf44ee6a3'),
(80, 8, 'access_hours_monday_saturday_hours', '9:00am - 6:00pm'),
(81, 8, '_access_hours_monday_saturday_hours', 'field_65ede058ee6a7'),
(82, 8, 'access_hours_saturday_sunday_hours', '10:00am - 5:00pm'),
(83, 8, '_access_hours_saturday_sunday_hours', 'field_65ede003ee6a4'),
(84, 8, 'access_hours_saturday_hours', '10:00am - 5:00pm'),
(85, 8, '_access_hours_saturday_hours', 'field_65ede013ee6a5'),
(86, 8, 'access_hours_sunday_hours', '10:00am - 5:00pm'),
(87, 8, '_access_hours_sunday_hours', 'field_65ede022ee6a6'),
(90, 8, 'amenities_features', 'a:9:{i:0;s:8:"security";i:1;s:5:"gated";i:2;s:10:"247booking";i:3;s:6:"aircon";i:4;s:8:"lighting";i:5;s:10:"monthlease";i:6;s:11:"contactless";i:7;s:6:"keypad";i:8;s:8:"business";}'),
(91, 8, '_amenities_features', 'field_65ede09b8a8c4'),
(92, 8, 'location_photo', '95'),
(93, 8, '_location_photo', 'field_65ede14e37095'),
(94, 8, 'google_map_hero', ''),
(95, 8, '_google_map_hero', 'field_65ede16737096'),
(306, 8, 'access_hours_store_hours_0_hours_title', 'Mon - Sun'),
(307, 8, '_access_hours_store_hours_0_hours_title', 'field_65f0e638c5112'),
(308, 8, 'access_hours_store_hours_0_hours_time', '12:00am - 11:59pm'),
(309, 8, '_access_hours_store_hours_0_hours_time', 'field_65f0e64ec5113'),
(314, 8, 'access_hours_store_hours', '1'),
(315, 8, '_access_hours_store_hours', 'field_65f0e5e9c5111'),
(368, 8, 'access_hours_details', 'Open 24hrs everyday'),
(369, 8, '_access_hours_details', 'field_65f0e78463056'),
(474, 8, 'support_hours_title', 'Support Hours'),
(475, 8, '_support_hours_title', 'field_65f0e8bf9bbf7'),
(476, 8, 'support_hours_details', 'Open Daily'),
(477, 8, '_support_hours_details', 'field_65f0e8d69bbf8'),
(478, 8, 'support_hours_support_hours_0_hours_title', 'Mon - Fri'),
(479, 8, '_support_hours_support_hours_0_hours_title', 'field_65f0e87f9bbf5'),
(480, 8, 'support_hours_support_hours_0_hours_time', '9:00am - 6:00pm'),
(481, 8, '_support_hours_support_hours_0_hours_time', 'field_65f0e87f9bbf6'),
(482, 8, 'support_hours_support_hours_1_hours_title', 'Sat & Sun'),
(483, 8, '_support_hours_support_hours_1_hours_title', 'field_65f0e87f9bbf5'),
(484, 8, 'support_hours_support_hours_1_hours_time', '9:00am - 5:00pm'),
(485, 8, '_support_hours_support_hours_1_hours_time', 'field_65f0e87f9bbf6'),
(486, 8, 'support_hours_support_hours', '2'),
(487, 8, '_support_hours_support_hours', 'field_65f0e87f9bbf4'),
(488, 8, 'support_hours', '2'),
(489, 8, '_support_hours', 'field_65f0ec97db9f7') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(556, 8, 'access_hours', '1'),
(557, 8, '_access_hours', 'field_65f0e5e9c5111'),
(558, 8, 'access_hours_0_hours_title', 'Mon - Sun:'),
(559, 8, '_access_hours_0_hours_title', 'field_65f0e638c5112'),
(560, 8, 'access_hours_0_hours_time', '12:00am - 11:59pm'),
(561, 8, '_access_hours_0_hours_time', 'field_65f0e64ec5113'),
(632, 8, 'support_hours_0_hours_title', 'Mon - Fri:'),
(633, 8, '_support_hours_0_hours_title', 'field_65f0ec97db9f8'),
(634, 8, 'support_hours_0_hours_time', '9:00am - 6:00pm'),
(635, 8, '_support_hours_0_hours_time', 'field_65f0ec97db9f9'),
(636, 8, 'support_hours_1_hours_title', 'Sat & Sun:'),
(637, 8, '_support_hours_1_hours_title', 'field_65f0ec97db9f8'),
(638, 8, 'support_hours_1_hours_time', '9:00am - 5:00pm'),
(639, 8, '_support_hours_1_hours_time', 'field_65f0ec97db9f9'),
(1030, 95, '_wp_attached_file', '2024/03/Storage-Zone-1.jpg'),
(1031, 95, '_wp_attachment_image_alt', 'Storage Zone 1'),
(1032, 95, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2048;s:6:"height";i:1365;s:4:"file";s:26:"2024/03/Storage-Zone-1.jpg";s:8:"filesize";i:273487;s:5:"sizes";a:7:{s:9:"thumbnail";a:5:{s:4:"file";s:26:"Storage-Zone-1-500x500.jpg";s:5:"width";i:500;s:6:"height";i:500;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:41544;}s:6:"medium";a:5:{s:4:"file";s:26:"Storage-Zone-1-800x533.jpg";s:5:"width";i:800;s:6:"height";i:533;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:65314;}s:12:"medium_large";a:5:{s:4:"file";s:26:"Storage-Zone-1-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:60960;}s:5:"large";a:5:{s:4:"file";s:28:"Storage-Zone-1-1500x1000.jpg";s:5:"width";i:1500;s:6:"height";i:1000;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:184741;}s:9:"1536x1536";a:5:{s:4:"file";s:28:"Storage-Zone-1-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:192128;}s:12:"small-square";a:5:{s:4:"file";s:24:"Storage-Zone-1-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3542;}s:8:"photogal";a:5:{s:4:"file";s:26:"Storage-Zone-1-900x600.jpg";s:5:"width";i:900;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:79401;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1033, 96, '_wp_attached_file', '2024/03/Storage-Zone-7.jpg'),
(1034, 96, '_wp_attachment_image_alt', 'Storage Zone 7'),
(1035, 96, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2048;s:6:"height";i:1365;s:4:"file";s:26:"2024/03/Storage-Zone-7.jpg";s:8:"filesize";i:595686;s:5:"sizes";a:7:{s:9:"thumbnail";a:5:{s:4:"file";s:26:"Storage-Zone-7-500x500.jpg";s:5:"width";i:500;s:6:"height";i:500;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:74012;}s:6:"medium";a:5:{s:4:"file";s:26:"Storage-Zone-7-800x533.jpg";s:5:"width";i:800;s:6:"height";i:533;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:115764;}s:12:"medium_large";a:5:{s:4:"file";s:26:"Storage-Zone-7-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:107113;}s:5:"large";a:5:{s:4:"file";s:28:"Storage-Zone-7-1500x1000.jpg";s:5:"width";i:1500;s:6:"height";i:1000;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:359911;}s:9:"1536x1536";a:5:{s:4:"file";s:28:"Storage-Zone-7-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:374651;}s:12:"small-square";a:5:{s:4:"file";s:24:"Storage-Zone-7-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4085;}s:8:"photogal";a:5:{s:4:"file";s:26:"Storage-Zone-7-900x600.jpg";s:5:"width";i:900;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:143518;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1036, 97, '_wp_attached_file', '2024/03/Storage-Zone-6.jpg'),
(1037, 97, '_wp_attachment_image_alt', 'Storage Zone 6'),
(1038, 97, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2048;s:6:"height";i:1365;s:4:"file";s:26:"2024/03/Storage-Zone-6.jpg";s:8:"filesize";i:316160;s:5:"sizes";a:7:{s:9:"thumbnail";a:5:{s:4:"file";s:26:"Storage-Zone-6-500x500.jpg";s:5:"width";i:500;s:6:"height";i:500;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:46622;}s:6:"medium";a:5:{s:4:"file";s:26:"Storage-Zone-6-800x533.jpg";s:5:"width";i:800;s:6:"height";i:533;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:76376;}s:12:"medium_large";a:5:{s:4:"file";s:26:"Storage-Zone-6-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:70875;}s:5:"large";a:5:{s:4:"file";s:28:"Storage-Zone-6-1500x1000.jpg";s:5:"width";i:1500;s:6:"height";i:1000;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:212528;}s:9:"1536x1536";a:5:{s:4:"file";s:28:"Storage-Zone-6-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:220354;}s:12:"small-square";a:5:{s:4:"file";s:24:"Storage-Zone-6-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3372;}s:8:"photogal";a:5:{s:4:"file";s:26:"Storage-Zone-6-900x600.jpg";s:5:"width";i:900;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:92938;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1039, 98, '_wp_attached_file', '2024/03/Storage-Zone-5.jpg'),
(1040, 98, '_wp_attachment_image_alt', 'Storage Zone 5'),
(1041, 98, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2048;s:6:"height";i:1365;s:4:"file";s:26:"2024/03/Storage-Zone-5.jpg";s:8:"filesize";i:300579;s:5:"sizes";a:7:{s:9:"thumbnail";a:5:{s:4:"file";s:26:"Storage-Zone-5-500x500.jpg";s:5:"width";i:500;s:6:"height";i:500;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:46371;}s:6:"medium";a:5:{s:4:"file";s:26:"Storage-Zone-5-800x533.jpg";s:5:"width";i:800;s:6:"height";i:533;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:63924;}s:12:"medium_large";a:5:{s:4:"file";s:26:"Storage-Zone-5-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:59316;}s:5:"large";a:5:{s:4:"file";s:28:"Storage-Zone-5-1500x1000.jpg";s:5:"width";i:1500;s:6:"height";i:1000;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:191560;}s:9:"1536x1536";a:5:{s:4:"file";s:28:"Storage-Zone-5-1536x1024.jpg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:199430;}s:12:"small-square";a:5:{s:4:"file";s:24:"Storage-Zone-5-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3328;}s:8:"photogal";a:5:{s:4:"file";s:26:"Storage-Zone-5-900x600.jpg";s:5:"width";i:900;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:78688;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1042, 99, '_wp_attached_file', '2024/03/Storage-Zone-4.jpg'),
(1043, 99, '_wp_attachment_image_alt', 'Storage Zone 4'),
(1044, 99, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1365;s:6:"height";i:1047;s:4:"file";s:26:"2024/03/Storage-Zone-4.jpg";s:8:"filesize";i:185261;s:5:"sizes";a:5:{s:9:"thumbnail";a:5:{s:4:"file";s:26:"Storage-Zone-4-500x500.jpg";s:5:"width";i:500;s:6:"height";i:500;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:56608;}s:6:"medium";a:5:{s:4:"file";s:26:"Storage-Zone-4-800x614.jpg";s:5:"width";i:800;s:6:"height";i:614;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:88794;}s:12:"medium_large";a:5:{s:4:"file";s:26:"Storage-Zone-4-768x589.jpg";s:5:"width";i:768;s:6:"height";i:589;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:83613;}s:12:"small-square";a:5:{s:4:"file";s:24:"Storage-Zone-4-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3961;}s:8:"photogal";a:5:{s:4:"file";s:26:"Storage-Zone-4-900x600.jpg";s:5:"width";i:900;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:97445;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1045, 100, '_wp_attached_file', '2024/03/Storage-Zone-3.jpg'),
(1046, 100, '_wp_attachment_image_alt', 'Storage Zone 3'),
(1047, 100, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1365;s:6:"height";i:942;s:4:"file";s:26:"2024/03/Storage-Zone-3.jpg";s:8:"filesize";i:189419;s:5:"sizes";a:5:{s:9:"thumbnail";a:5:{s:4:"file";s:26:"Storage-Zone-3-500x500.jpg";s:5:"width";i:500;s:6:"height";i:500;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:56567;}s:6:"medium";a:5:{s:4:"file";s:26:"Storage-Zone-3-800x552.jpg";s:5:"width";i:800;s:6:"height";i:552;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:92348;}s:12:"medium_large";a:5:{s:4:"file";s:26:"Storage-Zone-3-768x530.jpg";s:5:"width";i:768;s:6:"height";i:530;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:86943;}s:12:"small-square";a:5:{s:4:"file";s:24:"Storage-Zone-3-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4366;}s:8:"photogal";a:5:{s:4:"file";s:26:"Storage-Zone-3-900x600.jpg";s:5:"width";i:900;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:108479;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1048, 101, '_wp_attached_file', '2024/03/Storage-Zone-2.jpg'),
(1049, 101, '_wp_attachment_image_alt', 'Storage Zone 2'),
(1050, 101, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1365;s:6:"height";i:1109;s:4:"file";s:26:"2024/03/Storage-Zone-2.jpg";s:8:"filesize";i:221793;s:5:"sizes";a:5:{s:9:"thumbnail";a:5:{s:4:"file";s:26:"Storage-Zone-2-500x500.jpg";s:5:"width";i:500;s:6:"height";i:500;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:59422;}s:6:"medium";a:5:{s:4:"file";s:26:"Storage-Zone-2-800x650.jpg";s:5:"width";i:800;s:6:"height";i:650;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:108336;}s:12:"medium_large";a:5:{s:4:"file";s:26:"Storage-Zone-2-768x624.jpg";s:5:"width";i:768;s:6:"height";i:624;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:101057;}s:12:"small-square";a:5:{s:4:"file";s:24:"Storage-Zone-2-90x90.jpg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4315;}s:8:"photogal";a:5:{s:4:"file";s:26:"Storage-Zone-2-900x600.jpg";s:5:"width";i:900;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:112989;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1051, 8, 'unit_photos_0_unit_photo', '95'),
(1052, 8, '_unit_photos_0_unit_photo', 'field_65f1bc544976c'),
(1053, 8, 'unit_photos_1_unit_photo', '100'),
(1054, 8, '_unit_photos_1_unit_photo', 'field_65f1bc544976c'),
(1055, 8, 'unit_photos_2_unit_photo', '99'),
(1056, 8, '_unit_photos_2_unit_photo', 'field_65f1bc544976c'),
(1057, 8, 'unit_photos_3_unit_photo', '98'),
(1058, 8, '_unit_photos_3_unit_photo', 'field_65f1bc544976c'),
(1059, 8, 'unit_photos_4_unit_photo', '97'),
(1060, 8, '_unit_photos_4_unit_photo', 'field_65f1bc544976c'),
(1061, 8, 'unit_photos_5_unit_photo', '96'),
(1062, 8, '_unit_photos_5_unit_photo', 'field_65f1bc544976c'),
(1063, 8, 'unit_photos', '6'),
(1064, 8, '_unit_photos', 'field_65f1bc3b4976b'),
(1249, 8, 'storage_options_title', 'Storage Options'),
(1250, 8, '_storage_options_title', 'field_65f1eaa8d3660'),
(1251, 8, 'options_0_option_title', '24/7 Rentals & Support'),
(1252, 8, '_options_0_option_title', 'field_65f1eadad3663'),
(1253, 8, 'options_0_option_icon', '119'),
(1254, 8, '_options_0_option_icon', 'field_65f1eae3d3664'),
(1255, 8, 'options_0_option_description', 'Whether you have a car, motorcycle, or ATV that needs safekeeping, our vehicle storage options offer a secure and convenient solution.'),
(1256, 8, '_options_0_option_description', 'field_65f1eb61d3665'),
(1257, 8, 'options', '7'),
(1258, 8, '_options', 'field_65f1eaced3662'),
(1361, 112, '_wp_attached_file', '2024/03/Parking.svg'),
(1362, 112, '_wp_attachment_image_alt', 'Parking'),
(1363, 112, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:2106;}'),
(1364, 113, '_wp_attached_file', '2024/03/Boxes-And-Moving-Supplies.svg'),
(1365, 113, '_wp_attachment_image_alt', 'Boxes And Moving Supplies'),
(1366, 113, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:1046;}'),
(1367, 114, '_wp_attached_file', '2024/03/Online-Bill-Payment.svg'),
(1368, 114, '_wp_attachment_image_alt', 'Online Bill Payment'),
(1369, 114, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:1132;}'),
(1370, 115, '_wp_attached_file', '2024/03/Air-Cooled-Storage.svg'),
(1371, 115, '_wp_attachment_image_alt', 'Air Cooled Storage'),
(1372, 115, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:947;}'),
(1373, 116, '_wp_attached_file', '2024/03/Business-Storage.svg'),
(1374, 116, '_wp_attachment_image_alt', 'Business Storage'),
(1375, 116, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:1346;}'),
(1376, 117, '_wp_attached_file', '2024/03/Drive-Up-Access.svg'),
(1377, 117, '_wp_attachment_image_alt', 'Drive Up Access'),
(1378, 117, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:836;}'),
(1379, 118, '_wp_attached_file', '2024/03/RV-Trailer-Boat-Storage.svg'),
(1380, 118, '_wp_attachment_image_alt', 'Rv Trailer Boat Storage'),
(1381, 118, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:1417;}'),
(1382, 119, '_wp_attached_file', '2024/03/247-Rentals-Support.svg'),
(1383, 119, '_wp_attachment_image_alt', '247 Rentals Support'),
(1384, 119, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:958;}'),
(1385, 8, 'options_1_option_title', 'RV, Trailer & Boat Storage'),
(1386, 8, '_options_1_option_title', 'field_65f1eadad3663'),
(1387, 8, 'options_1_option_icon', '118'),
(1388, 8, '_options_1_option_icon', 'field_65f1eae3d3664'),
(1389, 8, 'options_1_option_description', 'Whether you have a car, motorcycle, or ATV that needs safekeeping, our vehicle storage options offer a secure and convenient solution.'),
(1390, 8, '_options_1_option_description', 'field_65f1eb61d3665'),
(1391, 8, 'options_2_option_title', 'Drive-Up Access'),
(1392, 8, '_options_2_option_title', 'field_65f1eadad3663'),
(1393, 8, 'options_2_option_icon', '117'),
(1394, 8, '_options_2_option_icon', 'field_65f1eae3d3664'),
(1395, 8, 'options_2_option_description', 'Whether you have a car, motorcycle, or ATV that needs safekeeping, our vehicle storage options offer a secure and convenient solution.'),
(1396, 8, '_options_2_option_description', 'field_65f1eb61d3665'),
(1397, 8, 'options_3_option_title', 'Business Storage'),
(1398, 8, '_options_3_option_title', 'field_65f1eadad3663'),
(1399, 8, 'options_3_option_icon', '116'),
(1400, 8, '_options_3_option_icon', 'field_65f1eae3d3664'),
(1401, 8, 'options_3_option_description', 'Whether you have a car, motorcycle, or ATV that needs safekeeping, our vehicle storage options offer a secure and convenient solution.') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1402, 8, '_options_3_option_description', 'field_65f1eb61d3665'),
(1403, 8, 'options_4_option_title', 'Air-Cooled Storage'),
(1404, 8, '_options_4_option_title', 'field_65f1eadad3663'),
(1405, 8, 'options_4_option_icon', '115'),
(1406, 8, '_options_4_option_icon', 'field_65f1eae3d3664'),
(1407, 8, 'options_4_option_description', 'Whether you have a car, motorcycle, or ATV that needs safekeeping, our vehicle storage options offer a secure and convenient solution.'),
(1408, 8, '_options_4_option_description', 'field_65f1eb61d3665'),
(1409, 8, 'options_5_option_title', 'Online Bill Payment'),
(1410, 8, '_options_5_option_title', 'field_65f1eadad3663'),
(1411, 8, 'options_5_option_icon', '114'),
(1412, 8, '_options_5_option_icon', 'field_65f1eae3d3664'),
(1413, 8, 'options_5_option_description', 'Whether you have a car, motorcycle, or ATV that needs safekeeping, our vehicle storage options offer a secure and convenient solution.'),
(1414, 8, '_options_5_option_description', 'field_65f1eb61d3665'),
(1415, 8, 'options_6_option_title', 'Boxes & Moving Supplies'),
(1416, 8, '_options_6_option_title', 'field_65f1eadad3663'),
(1417, 8, 'options_6_option_icon', '113'),
(1418, 8, '_options_6_option_icon', 'field_65f1eae3d3664'),
(1419, 8, 'options_6_option_description', 'Whether you have a car, motorcycle, or ATV that needs safekeeping, our vehicle storage options offer a secure and convenient solution.'),
(1420, 8, '_options_6_option_description', 'field_65f1eb61d3665'),
(1559, 8, 'storage_options_tagline', 'Get the most value for your dollar at Storage Zone'),
(1560, 8, '_storage_options_tagline', 'field_65f1eabbd3661'),
(1701, 8, 'google_map_embed_code', '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2924.427218633232!2d-73.89322112267239!3d42.86382617115046!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89de6c62c65f64eb%3A0x790d745652e1cb31!2s8%20Daggett%20Dr%2C%20Rexford%2C%20NY%2012148!5e0!3m2!1sen!2sus!4v1709556792757!5m2!1sen!2sus" width="100%" height="100%" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>'),
(1702, 8, '_google_map_embed_code', 'field_65f211801175c'),
(1845, 8, 'about_alternating_blocks_0_block_image', '96'),
(1846, 8, '_about_alternating_blocks_0_block_image', 'field_65f22f4a85b8b'),
(1847, 8, 'about_alternating_blocks_0_block_title', 'Welcome to Storage Zone'),
(1848, 8, '_about_alternating_blocks_0_block_title', 'field_65f22fd485b8c'),
(1849, 8, 'about_alternating_blocks_0_block_subtitle', 'Premier Self Storage in Shillington, PA'),
(1850, 8, '_about_alternating_blocks_0_block_subtitle', 'field_65f22fe385b8d'),
(1851, 8, 'about_alternating_blocks_0_block_description', 'Are you in need of reliable and convenient self-storage in Shillington, PA? Look no further than Storage Zone - your premier self-storage destination. Our facility offers a wide range of storage options to meet your specific needs, including climate-controlled storage, business storage, extra garage space, extra closet space, and hobby closets to launch your adventures. We understand the importance of security, accessibility, and convenience, which is why we have implemented state-of-the-art features to ensure your peace of mind.'),
(1852, 8, '_about_alternating_blocks_0_block_description', 'field_65f22fec85b8e'),
(1853, 8, 'about_alternating_blocks_0_block_options', ''),
(1854, 8, '_about_alternating_blocks_0_block_options', 'field_65f2301a85b8f'),
(1855, 8, 'about_alternating_blocks_1_block_image', '99'),
(1856, 8, '_about_alternating_blocks_1_block_image', 'field_65f22f4a85b8b'),
(1857, 8, 'about_alternating_blocks_1_block_title', 'Why Choose Storage Zone for Self-Storage in Shillington, PA?'),
(1858, 8, '_about_alternating_blocks_1_block_title', 'field_65f22fd485b8c'),
(1859, 8, 'about_alternating_blocks_1_block_subtitle', 'Our best amenities'),
(1860, 8, '_about_alternating_blocks_1_block_subtitle', 'field_65f22fe385b8d'),
(1861, 8, 'about_alternating_blocks_1_block_description', 'When it comes to self-storage, we believe in offering our customers nothing but the best. Here are some key reasons why Storage Zone is the top choice for self-storage in Shillington, PA:'),
(1862, 8, '_about_alternating_blocks_1_block_description', 'field_65f22fec85b8e'),
(1863, 8, 'about_alternating_blocks_1_block_options', 'a:9:{i:0;s:8:"security";i:1;s:5:"gated";i:2;s:10:"247booking";i:3;s:6:"aircon";i:4;s:8:"lighting";i:5;s:10:"monthlease";i:6;s:11:"contactless";i:7;s:6:"keypad";i:8;s:8:"business";}'),
(1864, 8, '_about_alternating_blocks_1_block_options', 'field_65f2301a85b8f'),
(1875, 8, 'about_alternating_blocks', '2'),
(1876, 8, '_about_alternating_blocks', 'field_65f22f3185b8a'),
(2051, 8, 'about_alternating_blocks_0_amenities', ''),
(2052, 8, '_about_alternating_blocks_0_amenities', 'field_65f234b41184a'),
(2053, 8, 'about_alternating_blocks_1_amenities', ''),
(2054, 8, '_about_alternating_blocks_1_amenities', 'field_65f234b41184a'),
(2223, 8, 'amenities', '16'),
(2224, 8, '_amenities', 'field_65f234b41184a'),
(2735, 8, 'amenities_0_amenity_title', 'Convenient Location: '),
(2736, 8, '_amenities_0_amenity_title', 'field_65f234ce1184b'),
(2737, 8, 'amenities_0_amenity_description', 'Our facility is conveniently located in Shillington, making it easily accessible for residents and businesses in Shillington and its neighboring communities.'),
(2738, 8, '_amenities_0_amenity_description', 'field_65f234d71184c'),
(2739, 8, 'amenities_1_amenity_title', 'Security Cameras: '),
(2740, 8, '_amenities_1_amenity_title', 'field_65f234ce1184b'),
(2741, 8, 'amenities_1_amenity_description', 'We prioritize the safety of your belongings. Our facility is equipped with advanced security cameras that monitor the premises, ensuring that your items are always protected.'),
(2742, 8, '_amenities_1_amenity_description', 'field_65f234d71184c'),
(2743, 8, 'amenities_2_amenity_title', 'Temperature-Controlled Facility: '),
(2744, 8, '_amenities_2_amenity_title', 'field_65f234ce1184b'),
(2745, 8, 'amenities_2_amenity_description', 'Worried about temperature fluctuations affecting your stored items? Our climate-controlled storage units are designed to maintain a consistent temperature, protecting your belongings from extreme heat or cold.'),
(2746, 8, '_amenities_2_amenity_description', 'field_65f234d71184c'),
(2747, 8, 'amenities_3_amenity_title', 'Month-To-Month Leases: '),
(2748, 8, '_amenities_3_amenity_title', 'field_65f234ce1184b'),
(2749, 8, 'amenities_3_amenity_description', 'We offer flexible month-to-month leases, so you\'re not tied down to a long-term commitment. This gives you the freedom to adjust your storage space as your needs change.'),
(2750, 8, '_amenities_3_amenity_description', 'field_65f234d71184c'),
(2751, 8, 'amenities_4_amenity_title', 'Contactless Move-Ins: '),
(2752, 8, '_amenities_4_amenity_title', 'field_65f234ce1184b'),
(2753, 8, 'amenities_4_amenity_description', 'In today\'s digital age, convenience is key. Our contactless move-in process allows you to rent a storage unit and access it without any physical contact.'),
(2754, 8, '_amenities_4_amenity_description', 'field_65f234d71184c'),
(2755, 8, 'amenities_5_amenity_title', 'Keypad Entry System: '),
(2756, 8, '_amenities_5_amenity_title', 'field_65f234ce1184b'),
(2757, 8, 'amenities_5_amenity_description', 'Accessing your storage unit has never been easier or more secure. Our keypad entry system ensures that only authorized individuals can enter the facility.'),
(2758, 8, '_amenities_5_amenity_description', 'field_65f234d71184c'),
(2759, 8, 'amenities_6_amenity_title', 'Storage Options to Suit Your Needs:'),
(2760, 8, '_amenities_6_amenity_title', 'field_65f234ce1184b'),
(2761, 8, 'amenities_6_amenity_description', 'At Storage Zone, we understand that different customers have different storage needs. That\'s why we offer a variety of storage unit sizes and types, including:'),
(2762, 8, '_amenities_6_amenity_description', 'field_65f234d71184c'),
(2763, 8, 'amenities_7_amenity_title', 'Climate-Controlled Storage: '),
(2764, 8, '_amenities_7_amenity_title', 'field_65f234ce1184b'),
(2765, 8, 'amenities_7_amenity_description', 'Perfect for items that require temperature and humidity control, such as furniture, electronics, and sensitive documents.'),
(2766, 8, '_amenities_7_amenity_description', 'field_65f234d71184c'),
(2767, 8, 'amenities_8_amenity_title', 'Business Storage: '),
(2768, 8, '_amenities_8_amenity_title', 'field_65f234ce1184b'),
(2769, 8, 'amenities_8_amenity_description', 'If you\'re a business owner looking to store inventory, equipment, or documents, our business storage solutions are ideal.'),
(2770, 8, '_amenities_8_amenity_description', 'field_65f234d71184c'),
(2771, 8, 'amenities_9_amenity_title', 'Gain an Extra Garage: '),
(2772, 8, '_amenities_9_amenity_title', 'field_65f234ce1184b'),
(2773, 8, 'amenities_9_amenity_description', 'Need extra space for the items cluttering your garage? Our large self-storage units have you covered. Consider a 12x10 or 10x20 unit.'),
(2774, 8, '_amenities_9_amenity_description', 'field_65f234d71184c'),
(2775, 8, 'amenities_10_amenity_title', 'Need an Extra Walk-In Closet? '),
(2776, 8, '_amenities_10_amenity_title', 'field_65f234ce1184b'),
(2777, 8, 'amenities_10_amenity_description', 'We have smaller storage options like 5x5 and 5x7 units for those with minimal storage needs, such as seasonal clothing or personal items.'),
(2778, 8, '_amenities_10_amenity_description', 'field_65f234d71184c'),
(2779, 8, 'amenities_11_amenity_title', 'Consider us Your Official Hobby Closet: '),
(2780, 8, '_amenities_11_amenity_title', 'field_65f234ce1184b'),
(2781, 8, 'amenities_11_amenity_description', 'Designed for hobbyists who need a dedicated space for their craft supplies, tools, or equipment.'),
(2782, 8, '_amenities_11_amenity_description', 'field_65f234d71184c'),
(2783, 8, 'amenities_12_amenity_title', 'Self-Storage Near Shillington and Surrounding Towns: ') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2784, 8, '_amenities_12_amenity_title', 'field_65f234ce1184b'),
(2785, 8, 'amenities_12_amenity_description', 'Our facility is strategically situated to cater to the storage needs of various nearby towns, including Lincoln Park, Mohnton, Reading, Kenhorst, Pennwyn, and Grill, PA. If you\'re located in Lincoln Park or its vicinity, Storage Zone is your convenient storage solution. Mohnton residents will appreciate the easy access to our Shillington facility, simplifying their storage requirements. For those in Reading and neighboring areas, our facility is just a short drive away. If you\'re in Reading, PA, Storage Zone offers a convenient option for all your storage needs. Kenhorst residents will find our facility to be the perfect choice for secure and accessible self-storage. Furthermore, Storage Zone serves Pennwyn, PA, with premium self-storage solutions, and Grill, PA residents can rely on us for secure self-storage options.'),
(2786, 8, '_amenities_12_amenity_description', 'field_65f234d71184c'),
(2787, 8, 'amenities_13_amenity_title', 'If you\'re trying to locate our facility, keep an eye out for these nearby landmarks:'),
(2788, 8, '_amenities_13_amenity_title', 'field_65f234ce1184b'),
(2789, 8, 'amenities_13_amenity_description', 'Our facility enjoys proximity to the Mifflin Community Library, making it a convenient stop on your way to or from your storage unit. Center 22 is another nearby landmark that provides easy reference for our customers.\r\n\r\nWe recognize the importance of accessibility in self-storage, and our strategic location ensures that you can easily access your stored items whenever necessary. Whether you\'re dropping off or picking up belongings, our facility offers convenient parking nearby to streamline the process for your convenience.'),
(2790, 8, '_amenities_13_amenity_description', 'field_65f234d71184c'),
(2791, 8, 'amenities_14_amenity_title', 'Top-Notch Security for Peace of Mind: '),
(2792, 8, '_amenities_14_amenity_title', 'field_65f234ce1184b'),
(2793, 8, 'amenities_14_amenity_description', 'Security is at the forefront of our operations. We want you to have complete peace of mind when storing your valuable possessions with us. Our facility is equipped with state-of-the-art security cameras that monitor the premises. Your items are our top priority, and we take every precaution to keep them safe and secure.'),
(2794, 8, '_amenities_14_amenity_description', 'field_65f234d71184c'),
(2795, 8, 'amenities_15_amenity_title', 'Flexible Unit Sizes: '),
(2796, 8, '_amenities_15_amenity_title', 'field_65f234ce1184b'),
(2797, 8, 'amenities_15_amenity_description', 'We recognize that storage needs vary from person to person and business to business. That\'s why we offer a range of unit sizes to accommodate all your storage requirements. Whether you\'re storing a few boxes or the contents of an entire house, we have the perfect unit size for you.\r\n\r\nOur climate-controlled units are ideal for items that require extra care, ensuring they stay in excellent condition. Choose Storage Zone for Your Self-Storage Needs in Shillington, PA.\r\n\r\nWhen it comes to self-storage, Storage Zone is your premier choice in Shillington, PA. Our commitment to security, convenience, and flexibility sets us apart from the rest. Whether you\'re a resident of Shillington or a neighboring town, we have the perfect storage solution for you. Contact us today to learn more about our available units, pricing, and current promotions. Let Storage Zone be your trusted partner for all your self-storage needs in Shillington and beyond. Discover the peace of mind that comes with storing your belongings at Storage Zone.'),
(2798, 8, '_amenities_15_amenity_description', 'field_65f234d71184c'),
(3267, 8, 'google_map_link', 'https://maps.app.goo.gl/MoJuLZWrTGKyciiD6'),
(3268, 8, '_google_map_link', 'field_65f2a06680890'),
(3741, 8, 'testimonials_title', 'See What Our Customers Are Saying'),
(3742, 8, '_testimonials_title', 'field_65f2ab792146e'),
(3743, 8, 'testimonials_tagline', ''),
(3744, 8, '_testimonials_tagline', 'field_65f2ab892146f'),
(3745, 8, 'testimonials', '3'),
(3746, 8, '_testimonials', 'field_65f2ab8f21470'),
(3989, 155, '_wp_attached_file', '2024/03/Patrick-Gioffre.jpeg'),
(3990, 155, '_wp_attachment_image_alt', 'Patrick Gioffre'),
(3991, 155, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:500;s:6:"height";i:499;s:4:"file";s:28:"2024/03/Patrick-Gioffre.jpeg";s:8:"filesize";i:64772;s:5:"sizes";a:2:{s:9:"thumbnail";a:5:{s:4:"file";s:28:"Patrick-Gioffre-500x331.jpeg";s:5:"width";i:500;s:6:"height";i:331;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:38954;}s:12:"small-square";a:5:{s:4:"file";s:26:"Patrick-Gioffre-90x90.jpeg";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6436;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(3992, 8, 'testimonials_0_testimonial_author', 'Adam Frymoyer'),
(3993, 8, '_testimonials_0_testimonial_author', 'field_65f2ad782e355'),
(3994, 8, 'testimonials_0_date_of_testimonial', '20240307'),
(3995, 8, '_testimonials_0_date_of_testimonial', 'field_65f2ad842e356'),
(3996, 8, 'testimonials_0_testimonial_author_photo', '155'),
(3997, 8, '_testimonials_0_testimonial_author_photo', 'field_65f2ada52e357'),
(3998, 8, 'testimonials_0_testimonial', 'Process was seamless. I inquired about the units last night and received a phone call this morning from staff, answering most of my questions. There was a few questions she was unsure of, so she helped me to schedule a same day site-visit with the property manager so that I could assess the concerns I had. I met the property manager a few hours later and I\'m glad I did. All of my concerns were answered, and this is the place I needed. It\'s clean, easily accessible, in a safe neighborhood, and close to home. Highly recommend checking them out. I\'ve done research for the last two weeks on over 12 different possible storage locations. For the venue, cost, safety, and closeness to home, this was the winner, hands down! Thank you Jake!!'),
(3999, 8, '_testimonials_0_testimonial', 'field_65f2ae062e358'),
(4000, 8, 'testimonials_0_testimonial_stars', 'a:1:{i:0;s:4:"five";}'),
(4001, 8, '_testimonials_0_testimonial_stars', 'field_65f2ae242e359'),
(4254, 8, 'testimonials_1_testimonial_author', 'Dave Materia'),
(4255, 8, '_testimonials_1_testimonial_author', 'field_65f2ad782e355'),
(4256, 8, 'testimonials_1_date_of_testimonial', '20240114'),
(4257, 8, '_testimonials_1_date_of_testimonial', 'field_65f2ad842e356'),
(4258, 8, 'testimonials_1_testimonial_author_photo', '155'),
(4259, 8, '_testimonials_1_testimonial_author_photo', 'field_65f2ada52e357'),
(4260, 8, 'testimonials_1_testimonial', 'Great location and affordable!'),
(4261, 8, '_testimonials_1_testimonial', 'field_65f2ae062e358'),
(4262, 8, 'testimonials_1_testimonial_stars', 'a:1:{i:0;s:4:"five";}'),
(4263, 8, '_testimonials_1_testimonial_stars', 'field_65f2ae242e359'),
(4526, 8, 'testimonials_2_testimonial_author', 'Jennifer Aston'),
(4527, 8, '_testimonials_2_testimonial_author', 'field_65f2ad782e355'),
(4528, 8, 'testimonials_2_date_of_testimonial', '20240111'),
(4529, 8, '_testimonials_2_date_of_testimonial', 'field_65f2ad842e356'),
(4530, 8, 'testimonials_2_testimonial_author_photo', '155'),
(4531, 8, '_testimonials_2_testimonial_author_photo', 'field_65f2ada52e357'),
(4532, 8, 'testimonials_2_testimonial', 'My son and i rented a space here. I was able to book online and get my space immediately.'),
(4533, 8, '_testimonials_2_testimonial', 'field_65f2ae062e358'),
(4534, 8, 'testimonials_2_testimonial_stars', 'a:1:{i:0;s:4:"four";}'),
(4535, 8, '_testimonials_2_testimonial_stars', 'field_65f2ae242e359'),
(4808, 8, 'faq_title', 'Frequently Asked Questions'),
(4809, 8, '_faq_title', 'field_65f2ba0494268'),
(4810, 8, 'faq_tagline', 'We’re here to help!'),
(4811, 8, '_faq_tagline', 'field_65f2ba3094269'),
(4812, 8, 'faqs_0_faq_question', 'How do I reserve a storage unit?'),
(4813, 8, '_faqs_0_faq_question', 'field_65f2b9ac94266'),
(4814, 8, 'faqs_0_faq_answer', 'Navigate to our unit listings above, select the size you want, and book online! If you have any questions about the units, please feel free to call us, we\'re always happy to help.'),
(4815, 8, '_faqs_0_faq_answer', 'field_65f2b9d594267'),
(4816, 8, 'faqs_1_faq_question', 'Can I reserve a storage unit in advance?'),
(4817, 8, '_faqs_1_faq_question', 'field_65f2b9ac94266'),
(4818, 8, 'faqs_1_faq_answer', 'Yes! You can reserve a locker up to 5 days ahead of your move-in-date. You do not have to pay for the unit until the day you move in. Please call our team if you are interested in reserving a unit.'),
(4819, 8, '_faqs_1_faq_answer', 'field_65f2b9d594267'),
(4820, 8, 'faqs_2_faq_question', 'How much are storage units near me in Shillington, PA?'),
(4821, 8, '_faqs_2_faq_question', 'field_65f2b9ac94266'),
(4822, 8, 'faqs_2_faq_answer', 'Our storage units are competitively priced for the Shillington, PA area. Check out our unit listings above for the most current price offerings.'),
(4823, 8, '_faqs_2_faq_answer', 'field_65f2b9d594267'),
(4824, 8, 'faqs_3_faq_question', 'What size storage unit do I need?'),
(4825, 8, '_faqs_3_faq_question', 'field_65f2b9ac94266'),
(4826, 8, 'faqs_3_faq_answer', 'The size of the storage unit you need totally depends on how you are planning to use it! A unit that is 5\' x 5\' works perfectly if you only need store extra items like skis, winter clothes, golf clubs, extra books, family photo albums and memorabilia, bikes, car seats, kids toys, holiday decorations, scooters, etc. However, if you are planning to move a small apartment into a storage unit and don\'t have large pieces of furniture, we would recommend at least a 10\' x 5\'. If you have furniture, a 10\' x 10\' makes the most sense. If you are looking to store multiple sets of bedroom furniture and large appliances, you should book a 10\' x 20\'.'),
(4827, 8, '_faqs_3_faq_answer', 'field_65f2b9d594267'),
(4828, 8, 'faqs_4_faq_question', 'What is self storage?'),
(4829, 8, '_faqs_4_faq_question', 'field_65f2b9ac94266'),
(4830, 8, 'faqs_4_faq_answer', 'Self storage is the kind of storage that you can access regularly by yourself. Generally people use it when they have extra items they want to store outside their home to make additional space and/or when they are moving. At Storage Zone, we take access and convenience seriously - we know that you are choosing self storage because you want to handle your items yourself and want to be able to access your stuff at a moment\'s notice, anytime you need. For that reason, our storage facility is accessible via a secure personal keycode so that you are free to pop in to your storage unit and grab your things without a reservation in advance.'),
(4831, 8, '_faqs_4_faq_answer', 'field_65f2b9d594267'),
(4832, 8, 'faqs_5_faq_question', 'Is the Shillington facility climate controlled?'),
(4833, 8, '_faqs_5_faq_question', 'field_65f2b9ac94266'),
(4834, 8, 'faqs_5_faq_answer', 'Yes, all our units are climate controlled.'),
(4835, 8, '_faqs_5_faq_answer', 'field_65f2b9d594267'),
(4836, 8, 'faqs', '6'),
(4837, 8, '_faqs', 'field_65f2b9a294265'),
(5140, 166, '_edit_lock', '1710449346:1'),
(5141, 166, '_edit_last', '1'),
(5142, 176, '_wp_attached_file', '2024/03/Footer-White-Label-Storage-Logo.png'),
(5143, 176, '_wp_attachment_image_alt', 'White Label Storage'),
(5144, 176, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:500;s:6:"height";i:389;s:4:"file";s:43:"2024/03/Footer-White-Label-Storage-Logo.png";s:8:"filesize";i:19518;s:5:"sizes";a:1:{s:12:"small-square";a:5:{s:4:"file";s:41:"Footer-White-Label-Storage-Logo-90x90.png";s:5:"width";i:90;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:3543;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2024-03-09 21:20:42', '2024-03-09 21:20:42', '<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->', 'Hello world!', '', 'trash', 'open', 'closed', '', 'hello-world__trashed', '', '', '2024-03-10 07:29:56', '2024-03-10 11:29:56', '', 0, 'http://white-label-storage-b2c.local/?p=1', 0, 'post', '', 1),
(2, 1, '2024-03-09 21:20:42', '2024-03-09 21:20:42', '<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href="http://white-label-storage-b2c.local/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->', 'Sample Page', '', 'trash', 'closed', 'closed', '', 'sample-page__trashed', '', '', '2024-03-10 07:19:20', '2024-03-10 11:19:20', '', 0, 'http://white-label-storage-b2c.local/?page_id=2', 0, 'page', '', 0),
(3, 1, '2024-03-09 21:20:42', '2024-03-09 21:20:42', '<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Our website address is: http://white-label-storage-b2c.local.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Comments</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Embedded content from other websites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you request a password reset, your IP address will be included in the reset email.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where your data is sent</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Suggested text: </strong>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph -->', 'Privacy Policy', '', 'draft', 'closed', 'closed', '', 'privacy-policy', '', '', '2024-03-09 21:20:42', '2024-03-09 21:20:42', '', 0, 'http://white-label-storage-b2c.local/?page_id=3', 0, 'page', '', 0),
(4, 0, '2024-03-09 23:13:54', '2024-03-09 23:13:54', '<!-- wp:page-list /-->', 'Navigation', '', 'publish', 'closed', 'closed', '', 'navigation', '', '', '2024-03-09 23:13:54', '2024-03-09 23:13:54', '', 0, 'http://white-label-storage-b2c.local/blog/2024/03/09/navigation/', 0, 'wp_navigation', '', 0),
(5, 1, '2024-03-09 23:14:14', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2024-03-09 23:14:14', '0000-00-00 00:00:00', '', 0, 'http://white-label-storage-b2c.local/?p=5', 0, 'post', '', 0),
(6, 1, '2024-03-10 11:18:29', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2024-03-10 11:18:29', '0000-00-00 00:00:00', '', 0, 'http://white-label-storage-b2c.local/?p=6', 0, 'post', '', 0),
(8, 1, '2024-03-10 07:19:40', '2024-03-10 11:19:40', '', 'White Label Solutions', '', 'publish', 'closed', 'closed', '', 'white-label-solutions', '', '', '2024-03-14 04:54:15', '2024-03-14 08:54:15', '', 0, 'http://white-label-storage-b2c.local/?page_id=8', 0, 'page', '', 0),
(12, 1, '2024-03-10 07:32:29', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', '', '', '', '', '', '', '2024-03-10 07:32:29', '0000-00-00 00:00:00', '', 0, 'http://white-label-storage-b2c.local/?p=12', 0, 'post', '', 0),
(13, 1, '2024-03-10 08:02:32', '2024-03-10 12:02:32', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:1:"8";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Homepage', 'homepage', 'publish', 'closed', 'closed', '', 'group_65eda1180359e', '', '', '2024-03-14 13:08:41', '2024-03-14 17:08:41', '', 0, 'http://white-label-storage-b2c.local/?post_type=acf-field-group&#038;p=13', 0, 'acf-field-group', '', 0),
(14, 1, '2024-03-10 08:02:32', '2024-03-10 12:02:32', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:11:"placeholder";s:0:"";s:9:"new_lines";s:0:"";}', 'Header Code', 'header_code', 'publish', 'closed', 'closed', '', 'field_65eda11804abc', '', '', '2024-03-14 14:42:28', '2024-03-14 18:42:28', '', 166, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=14', 7, 'acf-field', '', 0),
(15, 1, '2024-03-10 08:02:32', '2024-03-10 12:02:32', 'a:16:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:12:"preview_size";s:6:"medium";}', 'Favicon', 'favicon', 'publish', 'closed', 'closed', '', 'field_65eda14004abd', '', '', '2024-03-14 14:42:28', '2024-03-14 18:42:28', '', 166, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=15', 2, 'acf-field', '', 0),
(17, 1, '2024-03-10 08:15:24', '2024-03-10 12:15:24', 'Favicon', 'Favicon', '', 'inherit', 'closed', 'closed', '', 'favicon', '', '', '2024-03-10 08:15:24', '2024-03-10 12:15:24', '', 8, 'http://white-label-storage-b2c.local/wp-content/uploads/2024/03/favicon.png', 0, 'attachment', 'image/png', 0),
(19, 1, '2024-03-10 09:20:26', '2024-03-10 13:20:26', 'a:16:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:12:"preview_size";s:6:"medium";}', 'Header Logo', 'header_logo', 'publish', 'closed', 'closed', '', 'field_65edb35ae9d48', '', '', '2024-03-14 14:42:28', '2024-03-14 18:42:28', '', 166, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=19', 1, 'acf-field', '', 0),
(20, 1, '2024-03-10 09:22:12', '2024-03-10 13:22:12', 'White Label Storage', 'White Label Storage', '', 'inherit', 'closed', 'closed', '', 'emailsignature-logo', '', '', '2024-03-10 09:22:24', '2024-03-10 13:22:24', '', 8, 'http://white-label-storage-b2c.local/wp-content/uploads/2024/03/Emailsignature-logo.png', 0, 'attachment', 'image/png', 0),
(22, 1, '2024-03-10 10:50:58', '2024-03-10 14:50:58', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:5:"units";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Units', 'units', 'publish', 'closed', 'closed', '', 'group_65edc6c18daf7', '', '', '2024-03-10 13:18:06', '2024-03-10 17:18:06', '', 0, 'http://white-label-storage-b2c.local/?post_type=acf-field-group&#038;p=22', 0, 'acf-field-group', '', 0),
(23, 1, '2024-03-10 10:50:58', '2024-03-10 14:50:58', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Status', 'status', 'publish', 'closed', 'closed', '', 'field_65edc6c11a86f', '', '', '2024-03-10 10:50:58', '2024-03-10 14:50:58', '', 22, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=23', 0, 'acf-field', '', 0),
(24, 1, '2024-03-10 10:50:58', '2024-03-10 14:50:58', 'a:16:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:98:"Use a landscape 3:2 formatted JPEG at 1500 px wide. Thumbnail size will be auto generated at 500px";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:12:"preview_size";s:9:"thumbnail";}', 'Unit Image', 'unit_image', 'publish', 'closed', 'closed', '', 'field_65edc7a11a870', '', '', '2024-03-10 10:51:36', '2024-03-10 14:51:36', '', 22, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=24', 1, 'acf-field', '', 0),
(25, 1, '2024-03-10 10:50:58', '2024-03-10 14:50:58', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Price', 'price', 'publish', 'closed', 'closed', '', 'field_65edc7f41a871', '', '', '2024-03-10 10:50:58', '2024-03-10 14:50:58', '', 22, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=25', 2, 'acf-field', '', 0),
(26, 1, '2024-03-10 10:50:58', '2024-03-10 14:50:58', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Original Price', 'original_price', 'publish', 'closed', 'closed', '', 'field_65edc8001a872', '', '', '2024-03-10 10:50:58', '2024-03-10 14:50:58', '', 22, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=26', 3, 'acf-field', '', 0),
(27, 1, '2024-03-10 10:50:58', '2024-03-10 14:50:58', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Unit Type', 'unit_type', 'publish', 'closed', 'closed', '', 'field_65edc8081a873', '', '', '2024-03-10 10:50:58', '2024-03-10 14:50:58', '', 22, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=27', 4, 'acf-field', '', 0),
(28, 1, '2024-03-10 10:50:58', '2024-03-10 14:50:58', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Location', 'location', 'publish', 'closed', 'closed', '', 'field_65edc81f1a874', '', '', '2024-03-10 10:50:58', '2024-03-10 14:50:58', '', 22, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=28', 5, 'acf-field', '', 0),
(29, 1, '2024-03-10 10:50:58', '2024-03-10 14:50:58', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:72:"Add the full size here, add individual measurements below. FORMAT: WxLXH";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Size', 'size', 'publish', 'closed', 'closed', '', 'field_65edc8291a875', '', '', '2024-03-10 10:56:26', '2024-03-10 14:56:26', '', 22, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=29', 6, 'acf-field', '', 0),
(30, 1, '2024-03-10 10:50:58', '2024-03-10 14:50:58', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Width', 'width', 'publish', 'closed', 'closed', '', 'field_65edc8351a876', '', '', '2024-03-10 10:50:58', '2024-03-10 14:50:58', '', 22, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=30', 7, 'acf-field', '', 0),
(31, 1, '2024-03-10 10:50:58', '2024-03-10 14:50:58', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Length', 'length', 'publish', 'closed', 'closed', '', 'field_65edc8531a877', '', '', '2024-03-10 10:50:58', '2024-03-10 14:50:58', '', 22, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=31', 8, 'acf-field', '', 0),
(32, 1, '2024-03-10 10:50:58', '2024-03-10 14:50:58', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Height', 'height', 'publish', 'closed', 'closed', '', 'field_65edc8591a878', '', '', '2024-03-10 10:50:58', '2024-03-10 14:50:58', '', 22, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=32', 9, 'acf-field', '', 0),
(33, 1, '2024-03-10 10:50:58', '2024-03-10 14:50:58', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:41:"i.e. 40 sqft (leave out the 2 superscrpt)";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Square Feet', 'square_feet', 'publish', 'closed', 'closed', '', 'field_65edc85d1a879', '', '', '2024-03-10 10:56:26', '2024-03-10 14:56:26', '', 22, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=33', 10, 'acf-field', '', 0),
(34, 1, '2024-03-10 10:50:58', '2024-03-10 14:50:58', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:24:"i.e. 3 ft (w) x 6 ft (h)";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Door Size', 'door_size', 'publish', 'closed', 'closed', '', 'field_65edc86b1a87a', '', '', '2024-03-10 10:56:26', '2024-03-10 14:56:26', '', 22, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=34', 11, 'acf-field', '', 0),
(35, 1, '2024-03-10 10:50:58', '2024-03-10 14:50:58', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:11:"i.e. Rollup";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Door Type', 'door_type', 'publish', 'closed', 'closed', '', 'field_65edc8791a87b', '', '', '2024-03-10 10:56:26', '2024-03-10 14:56:26', '', 22, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=35', 12, 'acf-field', '', 0),
(36, 1, '2024-03-10 10:50:58', '2024-03-10 14:50:58', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:11:"i.e. Indoor";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Access Type', 'access_type', 'publish', 'closed', 'closed', '', 'field_65edc87b1a87c', '', '', '2024-03-10 10:56:26', '2024-03-10 14:56:26', '', 22, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=36', 13, 'acf-field', '', 0),
(37, 1, '2024-03-10 10:50:58', '2024-03-10 14:50:58', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:65:"i.e. 50% or "Half Off" (will display large - small details below)";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Promo Discount Or Header', 'promo_discount_or_header', 'publish', 'closed', 'closed', '', 'field_65edc8961a87d', '', '', '2024-03-10 10:50:58', '2024-03-10 14:50:58', '', 22, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=37', 14, 'acf-field', '', 0),
(38, 1, '2024-03-10 10:50:58', '2024-03-10 14:50:58', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:22:"i.e. "Next month free"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Promotional text', 'promotional_text', 'publish', 'closed', 'closed', '', 'field_65edc8bb1a87e', '', '', '2024-03-10 10:50:58', '2024-03-10 14:50:58', '', 22, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=38', 15, 'acf-field', '', 0),
(39, 1, '2024-03-10 10:56:26', '2024-03-10 14:56:26', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Amenities 1', 'amenities_1', 'publish', 'closed', 'closed', '', 'field_65edc96ca4f0c', '', '', '2024-03-10 10:56:26', '2024-03-10 14:56:26', '', 22, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=39', 16, 'acf-field', '', 0),
(40, 1, '2024-03-10 10:56:26', '2024-03-10 14:56:26', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Amenities 2', 'amenities_2', 'publish', 'closed', 'closed', '', 'field_65edca10a4f0d', '', '', '2024-03-10 10:56:26', '2024-03-10 14:56:26', '', 22, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=40', 17, 'acf-field', '', 0),
(41, 1, '2024-03-10 10:56:26', '2024-03-10 14:56:26', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Amenities 3', 'amenities_3', 'publish', 'closed', 'closed', '', 'field_65edca14a4f0e', '', '', '2024-03-10 10:56:26', '2024-03-10 14:56:26', '', 22, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=41', 18, 'acf-field', '', 0),
(42, 1, '2024-03-10 10:56:26', '2024-03-10 14:56:26', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Amenities 4', 'amenities_4', 'publish', 'closed', 'closed', '', 'field_65edca16a4f0f', '', '', '2024-03-10 10:56:26', '2024-03-10 14:56:26', '', 22, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=42', 19, 'acf-field', '', 0),
(43, 1, '2024-03-10 10:57:49', '2024-03-10 14:57:49', 'Wls Icon', 'Wls Icon', '', 'inherit', 'closed', 'closed', '', 'wls-icon', '', '', '2024-03-10 10:57:49', '2024-03-10 14:57:49', '', 0, 'http://white-label-storage-b2c.local/wp-content/uploads/2024/03/WLS-Icon.png', 0, 'attachment', 'image/png', 0),
(44, 1, '2024-03-10 12:20:13', '2024-03-10 16:20:13', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:15:"Call Or Text Us";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Call Or Text Title', 'call_or_text_title', 'publish', 'closed', 'closed', '', 'field_65eddd49043d9', '', '', '2024-03-14 14:42:28', '2024-03-14 18:42:28', '', 166, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=44', 3, 'acf-field', '', 0),
(45, 1, '2024-03-10 12:20:13', '2024-03-10 16:20:13', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Header Phone Number', 'header_phone_number', 'publish', 'closed', 'closed', '', 'field_65eddd6c043da', '', '', '2024-03-14 14:42:28', '2024-03-14 18:42:28', '', 166, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=45', 4, 'acf-field', '', 0),
(46, 1, '2024-03-10 12:20:13', '2024-03-10 16:20:13', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:13:"Pay Your Bill";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Pay Your Bill Title', 'pay_your_bill_title', 'publish', 'closed', 'closed', '', 'field_65eddd9b043db', '', '', '2024-03-14 14:42:28', '2024-03-14 18:42:28', '', 166, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=46', 5, 'acf-field', '', 0),
(47, 1, '2024-03-10 12:20:13', '2024-03-10 16:20:13', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Bill Payment Link', 'bill_payment_link', 'publish', 'closed', 'closed', '', 'field_65eddda4043dc', '', '', '2024-03-14 14:42:28', '2024-03-14 18:42:28', '', 166, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=47', 6, 'acf-field', '', 0),
(48, 1, '2024-03-10 12:32:04', '2024-03-10 16:32:04', 'a:8:{s:10:"aria-label";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Header', '', 'publish', 'closed', 'closed', '', 'field_65edddc2ee69b', '', '', '2024-03-14 14:39:34', '2024-03-14 18:39:34', '', 166, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=48', 0, 'acf-field', '', 0),
(49, 1, '2024-03-10 12:32:04', '2024-03-10 16:32:04', 'a:8:{s:10:"aria-label";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";b:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Hero', 'hero', 'publish', 'closed', 'closed', '', 'field_65edddd3ee69c', '', '', '2024-03-10 12:32:04', '2024-03-10 16:32:04', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=49', 8, 'acf-field', '', 0),
(50, 1, '2024-03-10 12:32:04', '2024-03-10 16:32:04', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:25:"i.e. Rexford Self-Storage";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Company Name', 'company_name', 'publish', 'closed', 'closed', '', 'field_65eddddeee69d', '', '', '2024-03-11 16:09:46', '2024-03-11 20:09:46', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=50', 10, 'acf-field', '', 0),
(51, 1, '2024-03-10 12:32:04', '2024-03-10 16:32:04', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:46:"Short tagline under the title, displays in red";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Tagline', 'tagline', 'publish', 'closed', 'closed', '', 'field_65edde02ee69e', '', '', '2024-03-11 16:09:46', '2024-03-11 20:09:46', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=51', 11, 'acf-field', '', 0),
(52, 1, '2024-03-10 12:32:04', '2024-03-10 16:32:04', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:11:"placeholder";s:0:"";s:9:"new_lines";s:0:"";}', 'Description', 'company_description', 'publish', 'closed', 'closed', '', 'field_65edde19ee69f', '', '', '2024-03-11 16:09:46', '2024-03-11 20:09:46', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=52', 12, 'acf-field', '', 0),
(53, 1, '2024-03-10 12:32:04', '2024-03-10 16:32:04', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:59:"Enter as one like, i.e. 143 Main Street, Brooklyn, NY 11222";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Address', 'address', 'publish', 'closed', 'closed', '', 'field_65edde3bee6a0', '', '', '2024-03-11 16:09:46', '2024-03-11 20:09:46', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=53', 13, 'acf-field', '', 0),
(54, 1, '2024-03-10 12:32:04', '2024-03-10 16:32:04', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:12:"Access Hours";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Access Hours Title', 'access_hours_title', 'publish', 'closed', 'closed', '', 'field_65eddec2ee6a1', '', '', '2024-03-14 03:00:13', '2024-03-14 07:00:13', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=54', 15, 'acf-field', '', 0),
(61, 1, '2024-03-10 12:34:53', '2024-03-10 16:34:53', 'a:14:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"checkbox";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:9:{s:8:"security";s:16:"Security Cameras";s:5:"gated";s:12:"Gated Access";s:10:"247booking";s:19:"24/7 Online Booking";s:6:"aircon";s:15:"Air Conditioned";s:8:"lighting";s:8:"Lighting";s:10:"monthlease";s:21:"Month-To-Month Leases";s:11:"contactless";s:20:"Contactless Move-ins";s:6:"keypad";s:12:"Keypad Entry";s:8:"business";s:16:"Business Storage";}s:13:"default_value";a:0:{}s:13:"return_format";s:5:"value";s:12:"allow_custom";i:0;s:6:"layout";s:8:"vertical";s:6:"toggle";i:0;s:11:"save_custom";i:0;s:25:"custom_choice_button_text";s:14:"Add new choice";}', 'Amenities Features', 'amenities_features', 'publish', 'closed', 'closed', '', 'field_65ede09b8a8c4', '', '', '2024-03-14 03:00:13', '2024-03-14 07:00:13', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=61', 21, 'acf-field', '', 0),
(62, 1, '2024-03-10 12:36:59', '2024-03-10 16:36:59', 'a:16:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:12:"preview_size";s:6:"medium";}', 'Location Photo', 'location_photo', 'publish', 'closed', 'closed', '', 'field_65ede14e37095', '', '', '2024-03-11 16:09:45', '2024-03-11 20:09:45', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=62', 9, 'acf-field', '', 0),
(63, 1, '2024-03-10 12:36:59', '2024-03-10 16:36:59', 'a:10:{s:10:"aria-label";s:0:"";s:4:"type";s:10:"google_map";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:10:"center_lat";s:0:"";s:10:"center_lng";s:0:"";s:4:"zoom";s:0:"";s:6:"height";s:0:"";}', 'Google Map Hero', 'google_map_hero', 'publish', 'closed', 'closed', '', 'field_65ede16737096', '', '', '2024-03-14 03:00:13', '2024-03-14 07:00:13', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=63', 22, 'acf-field', '', 0),
(69, 1, '2024-03-12 19:34:03', '2024-03-12 23:34:03', 'a:13:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:6:"layout";s:3:"row";s:10:"pagination";i:0;s:3:"min";s:0:"";s:3:"max";s:0:"";s:9:"collapsed";s:19:"field_65f0e638c5112";s:12:"button_label";s:15:"Add Another Set";s:13:"rows_per_page";i:20;}', 'Access Hours', 'access_hours', 'publish', 'closed', 'closed', '', 'field_65f0e5e9c5111', '', '', '2024-03-14 03:00:13', '2024-03-14 07:00:13', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=69', 17, 'acf-field', '', 0),
(70, 1, '2024-03-12 19:34:03', '2024-03-12 23:34:03', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:40:"i.e. Mon - Sat:<br />\r\nInclude the colon";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Hours Title', 'hours_title', 'publish', 'closed', 'closed', '', 'field_65f0e638c5112', '', '', '2024-03-12 20:13:01', '2024-03-13 00:13:01', '', 69, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=70', 0, 'acf-field', '', 0),
(71, 1, '2024-03-12 19:34:03', '2024-03-12 23:34:03', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:20:"i.e. 9:00am - 6:00pm";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Hours Time', 'hours_time', 'publish', 'closed', 'closed', '', 'field_65f0e64ec5113', '', '', '2024-03-12 19:34:03', '2024-03-12 23:34:03', '', 69, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=71', 1, 'acf-field', '', 0),
(72, 1, '2024-03-12 19:39:36', '2024-03-12 23:39:36', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:58:"Use for details, i.e. "Open 24/7 everyday". Keep it short.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Access Hours Details (optional)', 'access_hours_details', 'publish', 'closed', 'closed', '', 'field_65f0e78463056', '', '', '2024-03-14 03:00:13', '2024-03-14 07:00:13', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=72', 16, 'acf-field', '', 0),
(76, 1, '2024-03-12 19:45:12', '2024-03-12 23:45:12', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:13:"Support Hours";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Support Hours Title', 'support_hours_title', 'publish', 'closed', 'closed', '', 'field_65f0e8bf9bbf7', '', '', '2024-03-14 03:00:13', '2024-03-14 07:00:13', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=76', 18, 'acf-field', '', 0),
(77, 1, '2024-03-12 19:45:12', '2024-03-12 23:45:12', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:58:"Use for details, i.e. "Open 24/7 everyday". Keep it short.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Support Hours Details (optional)', 'support_hours_details', 'publish', 'closed', 'closed', '', 'field_65f0e8d69bbf8', '', '', '2024-03-14 03:00:13', '2024-03-14 07:00:13', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=77', 19, 'acf-field', '', 0),
(83, 1, '2024-03-12 20:02:14', '2024-03-13 00:02:14', 'a:13:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:6:"layout";s:3:"row";s:10:"pagination";i:0;s:3:"min";s:0:"";s:3:"max";s:0:"";s:9:"collapsed";s:19:"field_65f0ec97db9f8";s:12:"button_label";s:15:"Add Another Set";s:13:"rows_per_page";i:20;}', 'Support Hours', 'support_hours', 'publish', 'closed', 'closed', '', 'field_65f0ec97db9f7', '', '', '2024-03-14 03:00:13', '2024-03-14 07:00:13', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=83', 20, 'acf-field', '', 0),
(84, 1, '2024-03-12 20:02:14', '2024-03-13 00:02:14', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:40:"i.e. Mon - Sat:<br />\r\nInclude the colon";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Hours Title', 'hours_title', 'publish', 'closed', 'closed', '', 'field_65f0ec97db9f8', '', '', '2024-03-12 20:13:01', '2024-03-13 00:13:01', '', 83, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=84', 0, 'acf-field', '', 0),
(85, 1, '2024-03-12 20:02:14', '2024-03-13 00:02:14', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:20:"i.e. 9:00am - 6:00pm";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Hours Time', 'hours_time', 'publish', 'closed', 'closed', '', 'field_65f0ec97db9f9', '', '', '2024-03-12 20:02:14', '2024-03-13 00:02:14', '', 83, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=85', 1, 'acf-field', '', 0),
(92, 1, '2024-03-13 10:47:00', '2024-03-13 14:47:00', 'a:8:{s:10:"aria-label";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";b:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Photo Gallery', 'photo_gallery', 'publish', 'closed', 'closed', '', 'field_65f1bc274976a', '', '', '2024-03-14 03:00:13', '2024-03-14 07:00:13', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=92', 23, 'acf-field', '', 0),
(93, 1, '2024-03-13 10:47:00', '2024-03-13 14:47:00', 'a:13:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:6:"layout";s:5:"table";s:10:"pagination";i:0;s:3:"min";s:0:"";s:3:"max";s:0:"";s:9:"collapsed";s:19:"field_65f1bc544976c";s:12:"button_label";s:17:"Add Another Photo";s:13:"rows_per_page";i:20;}', 'Unit Photos', 'unit_photos', 'publish', 'closed', 'closed', '', 'field_65f1bc3b4976b', '', '', '2024-03-14 03:00:13', '2024-03-14 07:00:13', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=93', 24, 'acf-field', '', 0),
(94, 1, '2024-03-13 10:47:00', '2024-03-13 14:47:00', 'a:16:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:12:"preview_size";s:9:"thumbnail";}', 'Unit Photo', 'unit_photo', 'publish', 'closed', 'closed', '', 'field_65f1bc544976c', '', '', '2024-03-13 10:48:28', '2024-03-13 14:48:28', '', 93, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=94', 0, 'acf-field', '', 0),
(95, 1, '2024-03-13 10:47:54', '2024-03-13 14:47:54', 'Storage Zone 1', 'Storage Zone 1', '', 'inherit', 'closed', 'closed', '', 'storage-zone-1', '', '', '2024-03-13 10:47:54', '2024-03-13 14:47:54', '', 8, 'http://white-label-storage-b2c.local/wp-content/uploads/2024/03/Storage-Zone-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(96, 1, '2024-03-13 10:47:55', '2024-03-13 14:47:55', 'Storage Zone 7', 'Storage Zone 7', '', 'inherit', 'closed', 'closed', '', 'storage-zone-7', '', '', '2024-03-13 10:47:55', '2024-03-13 14:47:55', '', 8, 'http://white-label-storage-b2c.local/wp-content/uploads/2024/03/Storage-Zone-7.jpg', 0, 'attachment', 'image/jpeg', 0),
(97, 1, '2024-03-13 10:47:56', '2024-03-13 14:47:56', 'Storage Zone 6', 'Storage Zone 6', '', 'inherit', 'closed', 'closed', '', 'storage-zone-6', '', '', '2024-03-13 10:47:56', '2024-03-13 14:47:56', '', 8, 'http://white-label-storage-b2c.local/wp-content/uploads/2024/03/Storage-Zone-6.jpg', 0, 'attachment', 'image/jpeg', 0),
(98, 1, '2024-03-13 10:47:56', '2024-03-13 14:47:56', 'Storage Zone 5', 'Storage Zone 5', '', 'inherit', 'closed', 'closed', '', 'storage-zone-5', '', '', '2024-03-13 10:47:56', '2024-03-13 14:47:56', '', 8, 'http://white-label-storage-b2c.local/wp-content/uploads/2024/03/Storage-Zone-5.jpg', 0, 'attachment', 'image/jpeg', 0),
(99, 1, '2024-03-13 10:47:57', '2024-03-13 14:47:57', 'Storage Zone 4', 'Storage Zone 4', '', 'inherit', 'closed', 'closed', '', 'storage-zone-4', '', '', '2024-03-13 10:47:57', '2024-03-13 14:47:57', '', 8, 'http://white-label-storage-b2c.local/wp-content/uploads/2024/03/Storage-Zone-4.jpg', 0, 'attachment', 'image/jpeg', 0),
(100, 1, '2024-03-13 10:47:57', '2024-03-13 14:47:57', 'Storage Zone 3', 'Storage Zone 3', '', 'inherit', 'closed', 'closed', '', 'storage-zone-3', '', '', '2024-03-13 10:47:57', '2024-03-13 14:47:57', '', 8, 'http://white-label-storage-b2c.local/wp-content/uploads/2024/03/Storage-Zone-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(101, 1, '2024-03-13 10:47:57', '2024-03-13 14:47:57', 'Storage Zone 2', 'Storage Zone 2', '', 'inherit', 'closed', 'closed', '', 'storage-zone-2', '', '', '2024-03-13 10:47:57', '2024-03-13 14:47:57', '', 8, 'http://white-label-storage-b2c.local/wp-content/uploads/2024/03/Storage-Zone-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(104, 1, '2024-03-13 14:08:07', '2024-03-13 18:08:07', 'a:8:{s:10:"aria-label";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";b:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Storage Options', 'storage_options', 'publish', 'closed', 'closed', '', 'field_65f1ea99d365f', '', '', '2024-03-14 03:00:13', '2024-03-14 07:00:13', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=104', 25, 'acf-field', '', 0),
(105, 1, '2024-03-13 14:08:07', '2024-03-13 18:08:07', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:15:"Storage Options";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Storage Options Title', 'storage_options_title', 'publish', 'closed', 'closed', '', 'field_65f1eaa8d3660', '', '', '2024-03-14 03:00:13', '2024-03-14 07:00:13', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=105', 26, 'acf-field', '', 0),
(106, 1, '2024-03-13 14:08:07', '2024-03-13 18:08:07', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Tagline', 'storage_options_tagline', 'publish', 'closed', 'closed', '', 'field_65f1eabbd3661', '', '', '2024-03-14 03:00:13', '2024-03-14 07:00:13', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=106', 27, 'acf-field', '', 0),
(107, 1, '2024-03-13 14:08:07', '2024-03-13 18:08:07', 'a:13:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:6:"layout";s:3:"row";s:10:"pagination";i:0;s:3:"min";s:0:"";s:3:"max";s:0:"";s:9:"collapsed";s:19:"field_65f1eadad3663";s:12:"button_label";s:16:"Add Another Item";s:13:"rows_per_page";i:20;}', 'Options', 'options', 'publish', 'closed', 'closed', '', 'field_65f1eaced3662', '', '', '2024-03-14 03:00:13', '2024-03-14 07:00:13', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=107', 28, 'acf-field', '', 0),
(108, 1, '2024-03-13 14:08:07', '2024-03-13 18:08:07', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Option Title', 'option_title', 'publish', 'closed', 'closed', '', 'field_65f1eadad3663', '', '', '2024-03-13 14:08:07', '2024-03-13 18:08:07', '', 107, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=108', 0, 'acf-field', '', 0),
(109, 1, '2024-03-13 14:08:07', '2024-03-13 18:08:07', 'a:16:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:59:"Best to use a square formatted transparent PNG at 300 x 300";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:12:"preview_size";s:12:"small-square";}', 'Option Icon', 'option_icon', 'publish', 'closed', 'closed', '', 'field_65f1eae3d3664', '', '', '2024-03-13 14:08:07', '2024-03-13 18:08:07', '', 107, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=109', 1, 'acf-field', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(110, 1, '2024-03-13 14:08:07', '2024-03-13 18:08:07', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:11:"placeholder";s:0:"";s:9:"new_lines";s:0:"";}', 'Description', 'option_description', 'publish', 'closed', 'closed', '', 'field_65f1eb61d3665', '', '', '2024-03-13 14:08:36', '2024-03-13 18:08:36', '', 107, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=110', 2, 'acf-field', '', 0),
(112, 1, '2024-03-13 14:12:44', '2024-03-13 18:12:44', 'Parking', 'Parking', '', 'inherit', 'closed', 'closed', '', 'parking', '', '', '2024-03-13 14:12:44', '2024-03-13 18:12:44', '', 8, 'http://white-label-storage-b2c.local/wp-content/uploads/2024/03/Parking.svg', 0, 'attachment', 'image/svg+xml', 0),
(113, 1, '2024-03-13 14:12:44', '2024-03-13 18:12:44', 'Boxes And Moving Supplies', 'Boxes And Moving Supplies', '', 'inherit', 'closed', 'closed', '', 'boxes-and-moving-supplies', '', '', '2024-03-13 14:12:44', '2024-03-13 18:12:44', '', 8, 'http://white-label-storage-b2c.local/wp-content/uploads/2024/03/Boxes-And-Moving-Supplies.svg', 0, 'attachment', 'image/svg+xml', 0),
(114, 1, '2024-03-13 14:12:44', '2024-03-13 18:12:44', 'Online Bill Payment', 'Online Bill Payment', '', 'inherit', 'closed', 'closed', '', 'online-bill-payment', '', '', '2024-03-13 14:12:44', '2024-03-13 18:12:44', '', 8, 'http://white-label-storage-b2c.local/wp-content/uploads/2024/03/Online-Bill-Payment.svg', 0, 'attachment', 'image/svg+xml', 0),
(115, 1, '2024-03-13 14:12:45', '2024-03-13 18:12:45', 'Air Cooled Storage', 'Air Cooled Storage', '', 'inherit', 'closed', 'closed', '', 'air-cooled-storage', '', '', '2024-03-13 14:12:45', '2024-03-13 18:12:45', '', 8, 'http://white-label-storage-b2c.local/wp-content/uploads/2024/03/Air-Cooled-Storage.svg', 0, 'attachment', 'image/svg+xml', 0),
(116, 1, '2024-03-13 14:12:45', '2024-03-13 18:12:45', 'Business Storage', 'Business Storage', '', 'inherit', 'closed', 'closed', '', 'business-storage', '', '', '2024-03-13 14:12:45', '2024-03-13 18:12:45', '', 8, 'http://white-label-storage-b2c.local/wp-content/uploads/2024/03/Business-Storage.svg', 0, 'attachment', 'image/svg+xml', 0),
(117, 1, '2024-03-13 14:12:45', '2024-03-13 18:12:45', 'Drive Up Access', 'Drive Up Access', '', 'inherit', 'closed', 'closed', '', 'drive-up-access', '', '', '2024-03-13 14:12:45', '2024-03-13 18:12:45', '', 8, 'http://white-label-storage-b2c.local/wp-content/uploads/2024/03/Drive-Up-Access.svg', 0, 'attachment', 'image/svg+xml', 0),
(118, 1, '2024-03-13 14:12:45', '2024-03-13 18:12:45', 'Rv Trailer Boat Storage', 'Rv Trailer Boat Storage', '', 'inherit', 'closed', 'closed', '', 'rv-trailer-boat-storage', '', '', '2024-03-13 14:12:45', '2024-03-13 18:12:45', '', 8, 'http://white-label-storage-b2c.local/wp-content/uploads/2024/03/RV-Trailer-Boat-Storage.svg', 0, 'attachment', 'image/svg+xml', 0),
(119, 1, '2024-03-13 14:12:45', '2024-03-13 18:12:45', '247 Rentals Support', '247 Rentals Support', '', 'inherit', 'closed', 'closed', '', '247-rentals-support', '', '', '2024-03-13 14:12:45', '2024-03-13 18:12:45', '', 8, 'http://white-label-storage-b2c.local/wp-content/uploads/2024/03/247-Rentals-Support.svg', 0, 'attachment', 'image/svg+xml', 0),
(122, 1, '2024-03-13 16:51:15', '2024-03-13 20:51:15', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:11:"placeholder";s:0:"";s:9:"new_lines";s:0:"";}', 'Google Map Embed Code', 'google_map_embed_code', 'publish', 'closed', 'closed', '', 'field_65f211801175c', '', '', '2024-03-14 03:00:13', '2024-03-14 07:00:13', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=122', 29, 'acf-field', '', 0),
(124, 1, '2024-03-13 19:01:12', '2024-03-13 23:01:12', 'a:8:{s:10:"aria-label";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";b:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'About', 'about', 'publish', 'closed', 'closed', '', 'field_65f22f2685b89', '', '', '2024-03-14 03:00:13', '2024-03-14 07:00:13', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=124', 30, 'acf-field', '', 0),
(125, 1, '2024-03-13 19:01:12', '2024-03-13 23:01:12', 'a:13:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:6:"layout";s:3:"row";s:10:"pagination";i:0;s:3:"min";s:0:"";s:3:"max";s:0:"";s:9:"collapsed";s:19:"field_65f22f4a85b8b";s:12:"button_label";s:17:"Add Another Block";s:13:"rows_per_page";i:20;}', 'About Alternating Blocks', 'about_alternating_blocks', 'publish', 'closed', 'closed', '', 'field_65f22f3185b8a', '', '', '2024-03-14 03:00:13', '2024-03-14 07:00:13', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=125', 31, 'acf-field', '', 0),
(126, 1, '2024-03-13 19:01:12', '2024-03-13 23:01:12', 'a:16:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:24:"Use JPEG images, NOT PNG";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:11:".jpg, .jpeg";s:12:"preview_size";s:9:"thumbnail";}', 'Block Image', 'block_image', 'publish', 'closed', 'closed', '', 'field_65f22f4a85b8b', '', '', '2024-03-13 19:01:12', '2024-03-13 23:01:12', '', 125, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=126', 0, 'acf-field', '', 0),
(127, 1, '2024-03-13 19:01:12', '2024-03-13 23:01:12', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Block Title', 'block_title', 'publish', 'closed', 'closed', '', 'field_65f22fd485b8c', '', '', '2024-03-13 19:01:12', '2024-03-13 23:01:12', '', 125, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=127', 1, 'acf-field', '', 0),
(128, 1, '2024-03-13 19:01:12', '2024-03-13 23:01:12', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Block Subtitle', 'block_subtitle', 'publish', 'closed', 'closed', '', 'field_65f22fe385b8d', '', '', '2024-03-13 19:05:14', '2024-03-13 23:05:14', '', 125, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=128', 2, 'acf-field', '', 0),
(129, 1, '2024-03-13 19:01:12', '2024-03-13 23:01:12', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:17:"text-size-regular";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:4:"tabs";s:3:"all";s:7:"toolbar";s:4:"full";s:12:"media_upload";i:1;s:5:"delay";i:0;}', 'Block Description', 'block_description', 'publish', 'closed', 'closed', '', 'field_65f22fec85b8e', '', '', '2024-03-13 20:33:54', '2024-03-14 00:33:54', '', 125, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=129', 3, 'acf-field', '', 0),
(130, 1, '2024-03-13 19:01:12', '2024-03-13 23:01:12', 'a:14:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"checkbox";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:9:{s:8:"security";s:16:"Security Cameras";s:5:"gated";s:12:"Gated Access";s:10:"247booking";s:19:"24/7 Online Booking";s:6:"aircon";s:15:"Air Conditioned";s:8:"lighting";s:8:"Lighting";s:10:"monthlease";s:21:"Month-To-Month Leases";s:11:"contactless";s:20:"Contactless Move-ins";s:6:"keypad";s:12:"Keypad Entry";s:8:"business";s:16:"Business Storage";}s:13:"default_value";a:0:{}s:13:"return_format";s:5:"value";s:12:"allow_custom";i:0;s:6:"layout";s:8:"vertical";s:6:"toggle";i:0;s:11:"save_custom";i:0;s:25:"custom_choice_button_text";s:14:"Add new choice";}', 'Block Options', 'block_options', 'publish', 'closed', 'closed', '', 'field_65f2301a85b8f', '', '', '2024-03-13 22:13:55', '2024-03-14 02:13:55', '', 125, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=130', 4, 'acf-field', '', 0),
(132, 1, '2024-03-13 19:21:15', '2024-03-13 23:21:15', 'a:13:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:6:"layout";s:3:"row";s:10:"pagination";i:0;s:3:"min";s:0:"";s:3:"max";s:0:"";s:9:"collapsed";s:19:"field_65f234ce1184b";s:12:"button_label";s:19:"Add Another Amenity";s:13:"rows_per_page";i:20;}', 'Amenities', 'amenities', 'publish', 'closed', 'closed', '', 'field_65f234b41184a', '', '', '2024-03-14 03:00:13', '2024-03-14 07:00:13', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=132', 33, 'acf-field', '', 0),
(133, 1, '2024-03-13 19:21:15', '2024-03-13 23:21:15', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Amenity Title', 'amenity_title', 'publish', 'closed', 'closed', '', 'field_65f234ce1184b', '', '', '2024-03-13 19:21:15', '2024-03-13 23:21:15', '', 132, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=133', 0, 'acf-field', '', 0),
(134, 1, '2024-03-13 19:21:15', '2024-03-13 23:21:15', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";i:3;s:11:"placeholder";s:0:"";s:9:"new_lines";s:0:"";}', 'Amenity Description', 'amenity_description', 'publish', 'closed', 'closed', '', 'field_65f234d71184c', '', '', '2024-03-13 19:21:15', '2024-03-13 23:21:15', '', 132, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=134', 1, 'acf-field', '', 0),
(136, 1, '2024-03-13 20:21:00', '2024-03-14 00:21:00', 'a:8:{s:10:"aria-label";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";b:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Amenities', 'amenities', 'publish', 'closed', 'closed', '', 'field_65f235bf568f7', '', '', '2024-03-14 03:00:13', '2024-03-14 07:00:13', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=136', 32, 'acf-field', '', 0),
(142, 1, '2024-03-14 03:00:13', '2024-03-14 07:00:13', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:59:"Enter as one like, i.e. 143 Main Street, Brooklyn, NY 11222";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Google Map Link', 'google_map_link', 'publish', 'closed', 'closed', '', 'field_65f2a06680890', '', '', '2024-03-14 03:07:02', '2024-03-14 07:07:02', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=142', 14, 'acf-field', '', 0),
(145, 1, '2024-03-14 03:47:58', '2024-03-14 07:47:58', 'a:8:{s:10:"aria-label";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";b:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Testimonials', 'testimonials', 'publish', 'closed', 'closed', '', 'field_65f2ab612146d', '', '', '2024-03-14 03:47:58', '2024-03-14 07:47:58', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=145', 34, 'acf-field', '', 0),
(146, 1, '2024-03-14 03:47:58', '2024-03-14 07:47:58', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:33:"See What Our Customers Are Saying";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Testimonials Title', 'testimonials_title', 'publish', 'closed', 'closed', '', 'field_65f2ab792146e', '', '', '2024-03-14 04:50:18', '2024-03-14 08:50:18', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=146', 35, 'acf-field', '', 0),
(147, 1, '2024-03-14 03:47:58', '2024-03-14 07:47:58', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Testimonials Tagline', 'testimonials_tagline', 'publish', 'closed', 'closed', '', 'field_65f2ab892146f', '', '', '2024-03-14 03:47:58', '2024-03-14 07:47:58', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=147', 36, 'acf-field', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(148, 1, '2024-03-14 03:47:58', '2024-03-14 07:47:58', 'a:13:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:6:"layout";s:3:"row";s:10:"pagination";i:0;s:3:"min";s:0:"";s:3:"max";s:0:"";s:9:"collapsed";s:19:"field_65f2ad782e355";s:12:"button_label";s:23:"Add Another Testimonial";s:13:"rows_per_page";i:20;}', 'Testimonials', 'testimonials', 'publish', 'closed', 'closed', '', 'field_65f2ab8f21470', '', '', '2024-03-14 04:26:06', '2024-03-14 08:26:06', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=148', 37, 'acf-field', '', 0),
(150, 1, '2024-03-14 03:59:20', '2024-03-14 07:59:20', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Testimonial Author', 'testimonial_author', 'publish', 'closed', 'closed', '', 'field_65f2ad782e355', '', '', '2024-03-14 03:59:20', '2024-03-14 07:59:20', '', 148, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=150', 0, 'acf-field', '', 0),
(151, 1, '2024-03-14 03:59:20', '2024-03-14 07:59:20', 'a:9:{s:10:"aria-label";s:0:"";s:4:"type";s:11:"date_picker";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:14:"display_format";s:5:"m/d/Y";s:13:"return_format";s:6:"M j, Y";s:9:"first_day";i:1;}', 'Date Of Testimonial', 'date_of_testimonial', 'publish', 'closed', 'closed', '', 'field_65f2ad842e356', '', '', '2024-03-14 04:26:06', '2024-03-14 08:26:06', '', 148, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=151', 1, 'acf-field', '', 0),
(152, 1, '2024-03-14 03:59:20', '2024-03-14 07:59:20', 'a:16:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:75:"Use a square thumbnail size image, preferably 500 x 500, JPEG only, no PNGs";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";i:1500;s:10:"max_height";i:1500;s:8:"max_size";s:0:"";s:10:"mime_types";s:17:".jpg, .jpeg, jpeg";s:12:"preview_size";s:12:"small-square";}', 'Testimonial Author Photo', 'testimonial_author_photo', 'publish', 'closed', 'closed', '', 'field_65f2ada52e357', '', '', '2024-03-14 03:59:20', '2024-03-14 07:59:20', '', 148, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=152', 2, 'acf-field', '', 0),
(153, 1, '2024-03-14 03:59:20', '2024-03-14 07:59:20', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:11:"placeholder";s:0:"";s:9:"new_lines";s:0:"";}', 'Testimonial', 'testimonial', 'publish', 'closed', 'closed', '', 'field_65f2ae062e358', '', '', '2024-03-14 03:59:20', '2024-03-14 07:59:20', '', 148, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=153', 3, 'acf-field', '', 0),
(154, 1, '2024-03-14 03:59:20', '2024-03-14 07:59:20', 'a:14:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"checkbox";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:2:{s:4:"five";s:10:"Five Stars";s:4:"four";s:10:"Four Stars";}s:13:"default_value";a:0:{}s:13:"return_format";s:5:"value";s:12:"allow_custom";i:0;s:6:"layout";s:8:"vertical";s:6:"toggle";i:0;s:11:"save_custom";i:0;s:25:"custom_choice_button_text";s:14:"Add new choice";}', 'Testimonial Stars', 'testimonial_stars', 'publish', 'closed', 'closed', '', 'field_65f2ae242e359', '', '', '2024-03-14 04:41:01', '2024-03-14 08:41:01', '', 148, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=154', 4, 'acf-field', '', 0),
(155, 1, '2024-03-14 04:01:06', '2024-03-14 08:01:06', 'Patrick Gioffre', 'Patrick Gioffre', '', 'inherit', 'closed', 'closed', '', 'patrick-gioffre', '', '', '2024-03-14 04:01:06', '2024-03-14 08:01:06', '', 8, 'http://white-label-storage-b2c.local/wp-content/uploads/2024/03/Patrick-Gioffre.jpeg', 0, 'attachment', 'image/jpeg', 0),
(159, 1, '2024-03-14 04:50:18', '2024-03-14 08:50:18', 'a:8:{s:10:"aria-label";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";b:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'FAQs', 'faqs', 'publish', 'closed', 'closed', '', 'field_65f2b99694264', '', '', '2024-03-14 04:50:18', '2024-03-14 08:50:18', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=159', 38, 'acf-field', '', 0),
(160, 1, '2024-03-14 04:50:18', '2024-03-14 08:50:18', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:26:"Frequently Asked Questions";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'FAQ Title', 'faq_title', 'publish', 'closed', 'closed', '', 'field_65f2ba0494268', '', '', '2024-03-14 04:50:18', '2024-03-14 08:50:18', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=160', 39, 'acf-field', '', 0),
(161, 1, '2024-03-14 04:50:18', '2024-03-14 08:50:18', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:21:"We’re here to help!";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'FAQ Tagline', 'faq_tagline', 'publish', 'closed', 'closed', '', 'field_65f2ba3094269', '', '', '2024-03-14 04:50:51', '2024-03-14 08:50:51', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=161', 40, 'acf-field', '', 0),
(162, 1, '2024-03-14 04:50:18', '2024-03-14 08:50:18', 'a:13:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:6:"layout";s:3:"row";s:10:"pagination";i:0;s:3:"min";s:0:"";s:3:"max";s:0:"";s:9:"collapsed";s:19:"field_65f2b9ac94266";s:12:"button_label";s:20:"Add Another Question";s:13:"rows_per_page";i:20;}', 'FAQs', 'faqs', 'publish', 'closed', 'closed', '', 'field_65f2b9a294265', '', '', '2024-03-14 13:08:41', '2024-03-14 17:08:41', '', 13, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=162', 41, 'acf-field', '', 0),
(163, 1, '2024-03-14 04:50:18', '2024-03-14 08:50:18', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'FAQ Question', 'faq_question', 'publish', 'closed', 'closed', '', 'field_65f2b9ac94266', '', '', '2024-03-14 04:50:18', '2024-03-14 08:50:18', '', 162, 'http://white-label-storage-b2c.local/?post_type=acf-field&p=163', 0, 'acf-field', '', 0),
(164, 1, '2024-03-14 04:50:18', '2024-03-14 08:50:18', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";i:3;s:11:"placeholder";s:0:"";s:9:"new_lines";s:0:"";}', 'FAQ Answer', 'faq_answer', 'publish', 'closed', 'closed', '', 'field_65f2b9d594267', '', '', '2024-03-14 04:51:51', '2024-03-14 08:51:51', '', 162, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=164', 1, 'acf-field', '', 0),
(166, 1, '2024-03-14 13:11:50', '2024-03-14 17:11:50', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:22:"theme-general-settings";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Sitewide Options', 'sitewide-options', 'publish', 'closed', 'closed', '', 'group_65f32f1f43fef', '', '', '2024-03-14 14:43:22', '2024-03-14 18:43:22', '', 0, 'http://white-label-storage-b2c.local/?post_type=acf-field-group&#038;p=166', 0, 'acf-field-group', '', 0),
(167, 1, '2024-03-14 13:11:50', '2024-03-14 17:11:50', 'a:8:{s:10:"aria-label";s:0:"";s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";b:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:3:"top";s:8:"endpoint";i:0;}', 'Footer', 'footer', 'publish', 'closed', 'closed', '', 'field_65f32f1faf40b', '', '', '2024-03-14 14:43:22', '2024-03-14 18:43:22', '', 166, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=167', 8, 'acf-field', '', 0),
(168, 1, '2024-03-14 13:11:50', '2024-03-14 17:11:50', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:7:"Company";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Company Title', 'company_title', 'publish', 'closed', 'closed', '', 'field_65f32f35af40c', '', '', '2024-03-14 14:43:22', '2024-03-14 18:43:22', '', 166, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=168', 9, 'acf-field', '', 0),
(169, 1, '2024-03-14 13:11:50', '2024-03-14 17:11:50', 'a:16:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"image";s:12:"instructions";s:28:"Use a transparent PNG or GIF";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";s:12:"preview_size";s:12:"small-square";}', 'Footer Logo', 'footer_logo', 'publish', 'closed', 'closed', '', 'field_65f32fc2af411', '', '', '2024-03-14 14:43:22', '2024-03-14 18:43:22', '', 166, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=169', 10, 'acf-field', '', 0),
(170, 1, '2024-03-14 13:11:50', '2024-03-14 17:11:50', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Phone', 'footer_phone', 'publish', 'closed', 'closed', '', 'field_65f32f52af40d', '', '', '2024-03-14 14:43:22', '2024-03-14 18:43:22', '', 166, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=170', 11, 'acf-field', '', 0),
(171, 1, '2024-03-14 13:11:50', '2024-03-14 17:11:50', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Address', 'footer_address', 'publish', 'closed', 'closed', '', 'field_65f32f6aaf40e', '', '', '2024-03-14 14:43:22', '2024-03-14 18:43:22', '', 166, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=171', 12, 'acf-field', '', 0),
(172, 1, '2024-03-14 13:11:50', '2024-03-14 17:11:50', 'a:10:{s:10:"aria-label";s:0:"";s:4:"type";s:5:"email";s:12:"instructions";s:167:"Leave blank to hide email and link to the contact page for people to use the contact form. This will be more secure from spam, than showing everyone the contact email.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Email', 'footer_email', 'publish', 'closed', 'closed', '', 'field_65f32f90af40f', '', '', '2024-03-14 14:43:22', '2024-03-14 18:43:22', '', 166, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=172', 13, 'acf-field', '', 0),
(173, 1, '2024-03-14 13:11:50', '2024-03-14 17:11:50', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:30:"Powered by White Label Storage";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Footer Legal Line / Powered By', 'footer_legal_line', 'publish', 'closed', 'closed', '', 'field_65f32fa9af410', '', '', '2024-03-14 14:43:22', '2024-03-14 18:43:22', '', 166, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=173', 14, 'acf-field', '', 0),
(175, 1, '2024-03-14 13:27:29', '2024-03-14 17:27:29', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:68:"Text that appears right after the copyright, before the legal links.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Footer All Rights Reserved', 'footer_all_rights_reserved', 'publish', 'closed', 'closed', '', 'field_65f3335b9fc62', '', '', '2024-03-14 14:43:22', '2024-03-14 18:43:22', '', 166, 'http://white-label-storage-b2c.local/?post_type=acf-field&#038;p=175', 15, 'acf-field', '', 0),
(176, 1, '2024-03-14 13:30:15', '2024-03-14 17:30:15', 'Footer White Label Storage Logo', 'Footer White Label Storage Logo', '', 'inherit', 'closed', 'closed', '', 'footer-white-label-storage-logo', '', '', '2024-03-14 13:30:23', '2024-03-14 17:30:23', '', 0, 'http://white-label-storage-b2c.local/wp-content/uploads/2024/03/Footer-White-Label-Storage-Logo.png', 0, 'attachment', 'image/png', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_registration_log`
#

DROP TABLE IF EXISTS `wp_registration_log`;


#
# Table structure of table `wp_registration_log`
#

CREATE TABLE `wp_registration_log` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `IP` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `blog_id` bigint(20) NOT NULL DEFAULT '0',
  `date_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`ID`),
  KEY `IP` (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_registration_log`
#

#
# End of data contents of table `wp_registration_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_signups`
#

DROP TABLE IF EXISTS `wp_signups`;


#
# Table structure of table `wp_signups`
#

CREATE TABLE `wp_signups` (
  `signup_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `domain` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `path` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_login` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `activation_key` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`signup_id`),
  KEY `activation_key` (`activation_key`),
  KEY `user_email` (`user_email`),
  KEY `user_login_email` (`user_login`,`user_email`),
  KEY `domain_path` (`domain`(140),`path`(51))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_signups`
#

#
# End of data contents of table `wp_signups`
# --------------------------------------------------------



#
# Delete any existing table `wp_site`
#

DROP TABLE IF EXISTS `wp_site`;


#
# Table structure of table `wp_site`
#

CREATE TABLE `wp_site` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `domain` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `path` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `domain` (`domain`(140),`path`(51))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_site`
#
INSERT INTO `wp_site` ( `id`, `domain`, `path`) VALUES
(1, 'white-label-storage-b2c.local', '/') ;

#
# End of data contents of table `wp_site`
# --------------------------------------------------------



#
# Delete any existing table `wp_sitemeta`
#

DROP TABLE IF EXISTS `wp_sitemeta`;


#
# Table structure of table `wp_sitemeta`
#

CREATE TABLE `wp_sitemeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `site_id` bigint(20) NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `site_id` (`site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=254 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_sitemeta`
#
INSERT INTO `wp_sitemeta` ( `meta_id`, `site_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'site_name', 'White Label Storage B2c Sites'),
(2, 1, 'admin_email', 'mike@reccenter.com'),
(3, 1, 'admin_user_id', '1'),
(4, 1, 'registration', 'none'),
(5, 1, 'upload_filetypes', 'jpg jpeg png gif webp mov avi mpg 3gp 3g2 midi mid pdf doc ppt odt pptx docx pps ppsx xls xlsx key mp3 ogg flac m4a wav mp4 m4v webm ogv flv'),
(6, 1, 'blog_upload_space', '50'),
(7, 1, 'fileupload_maxk', '2500'),
(8, 1, 'site_admins', 'a:1:{i:0;s:16:"WLSB2C_CHUi239_x";}'),
(9, 1, 'allowedthemes', 'a:1:{s:7:"sage-10";b:1;}'),
(10, 1, 'illegal_names', 'a:9:{i:0;s:3:"www";i:1;s:3:"web";i:2;s:4:"root";i:3;s:5:"admin";i:4;s:4:"main";i:5;s:6:"invite";i:6;s:13:"administrator";i:7;s:5:"files";i:8;s:4:"blog";}'),
(11, 1, 'wpmu_upgrade_site', '56657'),
(12, 1, 'welcome_email', 'Howdy USERNAME,\r\n\r\nYour new SITE_NAME site has been successfully set up at:\r\nBLOG_URL\r\n\r\nYou can log in to the administrator account with the following information:\r\n\r\nUsername: USERNAME\r\nPassword: PASSWORD\r\nLog in here: BLOG_URLwp-login.php\r\n\r\nWe hope you enjoy your new site. Thanks!\r\n\r\n--The Team @ SITE_NAME'),
(13, 1, 'first_post', 'Welcome to %s. This is your first post. Edit or delete it, then start writing!'),
(14, 1, 'siteurl', 'http://white-label-storage-b2c.local/'),
(15, 1, 'add_new_users', '1'),
(16, 1, 'upload_space_check_disabled', '1'),
(17, 1, 'subdomain_install', ''),
(18, 1, 'ms_files_rewriting', '0'),
(19, 1, 'user_count', '1'),
(20, 1, 'initial_db_version', '56657'),
(21, 1, 'active_sitewide_plugins', 'a:8:{s:21:"wpgetapi/wpgetapi.php";i:1710039972;s:33:"classic-editor/classic-editor.php";i:1710043564;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:1710043564;s:34:"advanced-custom-fields-pro/acf.php";i:1710285994;s:47:"wpgetapi-api-to-posts/wpgetapi-api-to-posts.php";i:1710347275;s:33:"jquery-updater/jquery-updater.php";i:1710349361;s:28:"venobox-lightbox/venobox.php";i:1710349394;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";i:1710452694;}'),
(22, 1, 'WPLANG', ''),
(23, 1, 'main_site', '1'),
(33, 1, 'wp_force_deactivated_plugins', 'a:0:{}'),
(36, 1, 'blog_count', '1'),
(37, 1, 'can_compress_scripts', '1'),
(42, 1, 'recently_activated', 'a:10:{s:43:"dreamhost-automated-migration/dreamhost.php";i:1710451897;s:51:"all-in-one-wp-migration/all-in-one-wp-migration.php";i:1710451363;s:91:"all-in-one-wp-migration-multisite-extension/all-in-one-wp-migration-multisite-extension.php";i:1710451363;s:47:"regenerate-thumbnails/regenerate-thumbnails.php";i:1710446837;s:60:"wp-rest-api-authentication/miniorange-api-authentication.php";i:1710347303;s:46:"custom-api-for-wp/custom-api-for-wordpress.php";i:1710347252;s:35:"splide-carousel/splide-carousel.php";i:1710344562;s:23:"gutenberg/gutenberg.php";i:1710344553;s:43:"all-in-one-seo-pack/all_in_one_seo_pack.php";i:1710070388;s:33:"defender-security/wp-defender.php";i:1710070383;}'),
(58, 1, 'wd_show_ip_detection_xff_notice', '1'),
(59, 1, 'defender_free_install_date', '1710043565'),
(60, 1, 'wd_db_version', '4.5.1'),
(63, 1, 'wpmudev_recommended_plugins_registered', 'a:1:{s:33:"defender-security/wp-defender.php";a:1:{s:13:"registered_at";i:1710043565;}}'),
(64, 1, 'wpmudev_notices', 'a:3:{s:7:"plugins";a:1:{s:8:"defender";i:1710043584;}s:5:"queue";a:1:{s:8:"defender";a:3:{s:5:"email";i:1710043584;s:4:"rate";i:1710043584;s:8:"giveaway";i:1710043584;}}s:4:"done";a:0:{}}'),
(67, 1, 'hardener_settings', '{"issues":["disable-file-editor"],"fixed":["disable-xml-rpc","wp-version","hide-error","php-version","replace-admin-username","security-key","login-duration","disable-trackback","prevent-enum-users","protect-information","prevent-php-executed"],"ignore":[],"data":[],"last_seen":"","last_sent":"","automate":false}'),
(68, 1, 'wd_lockdown_settings', '{"ip_blocklist_cleanup_interval":"never","storage_days":30,"http_ip_header":"HTTP_X_FORWARDED_FOR","trusted_proxies_ip":"::1","trusted_proxy_preset":"","trusted_proxy_preset_list":["cloudflare"]}'),
(69, 1, 'wd_dismiss_ip_detection_xff_notice', '1'),
(70, 1, 'wp_defender_shown_activator', '1'),
(71, 1, 'wd_login_lockout_settings', '{"enabled":true,"attempt":5,"timeframe":300,"duration":300,"duration_unit":"seconds","lockout_type":"timeframe","lockout_message":"You have been locked out due to too many invalid login attempts.","username_blacklist":""}'),
(72, 1, 'wd_notfound_lockout_settings', '{"enabled":true,"attempt":20,"timeframe":300,"duration":300,"duration_unit":"seconds","lockout_type":"timeframe","blacklist":"","whitelist":".css\\n.js\\n.map","lockout_message":"You have been locked out due to too many attempts to access a file that doesn\'t exist.","detect_logged":false}'),
(73, 1, 'wd_user_agent_settings', '{"enabled":true,"blacklist":"MJ12Bot\\nAhrefsBot\\nSEMrushBot\\nDotBot","whitelist":"a6-indexer\\nadsbot-google\\naolbuild\\napis-google\\nbaidu\\nbingbot\\nbingpreview\\nbutterfly\\ncloudflare\\nchrome\\nduckduckbot\\nembedly\\nfacebookexternalhit\\nfacebot\\ngoogle page speed\\ngooglebot\\nia_archiver\\nlinkedinbot\\nmediapartners-google\\nmsnbot\\nnetcraftsurvey\\noutbrain\\npinterest\\nquora\\nslackbot\\nslurp\\ntweetmemebot\\ntwitterbot\\nuptimerobot\\nurlresolver\\nvkshare\\nw3c_validator\\nwordpress\\nwp rocket\\nyandex","message":"You have been blocked from accessing this website.","empty_headers":false}'),
(74, 1, 'defender_security_tweeks_login-duration', '7'),
(75, 1, 'wd_scan_settings', '{"integrity_check":true,"check_core":true,"check_plugins":false,"scan_malware":false,"check_known_vuln":true,"filesize":10,"scheduled_scanning":false,"frequency":"weekly","day":"sunday","day_n":"1","time":"4:00","quarantine_expire_schedule":"thirty_days"}'),
(76, 1, 'wd_main_settings', '{"translate":"English","usage_tracking":true,"uninstall_data":"keep","uninstall_settings":"preserve","high_contrast_mode":false,"uninstall_quarantine":"keep"}'),
(79, 1, 'wp_defender_config_default1710043596', 'a:6:{s:7:"configs";a:10:{s:4:"scan";a:25:{s:15:"integrity_check";b:1;s:10:"check_core";b:1;s:13:"check_plugins";b:0;s:16:"check_known_vuln";b:1;s:12:"scan_malware";b:0;s:8:"filesize";i:3;s:6:"report";s:7:"enabled";s:11:"always_send";b:0;s:18:"report_subscribers";a:0:{}s:3:"day";s:6:"sunday";s:5:"day_n";s:1:"1";s:4:"time";s:4:"4:00";s:9:"frequency";s:6:"weekly";s:7:"dry_run";b:0;s:12:"notification";s:7:"enabled";s:24:"always_send_notification";b:0;s:10:"error_send";b:0;s:24:"notification_subscribers";a:0:{}s:25:"email_subject_issue_found";s:70:"Malware Scan of {SITE_URL} is complete. {ISSUES_COUNT} issue(s) found.";s:29:"email_subject_issue_not_found";s:57:"Scan of {SITE_URL} complete. {ISSUES_COUNT} issues found.";s:19:"email_subject_error";s:48:"Couldn’t scan {SITE_URL} for vulnerabilities. ";s:25:"email_content_issue_found";s:139:"Hi {USER_NAME},\n\nMalware Scan identified {ISSUES_COUNT} issue(s) on {SITE_URL}. The identified issue(s) is/are listed below.\n\n{ISSUES_LIST}";s:29:"email_content_issue_not_found";s:67:"Hi {USER_NAME},\n\nNo vulnerabilities have been found for {SITE_URL}.";s:19:"email_content_error";s:113:"Hi {USER_NAME},\n\nWe couldn’t scan {SITE_URL} for vulnerabilities. Please visit your site and run a manual scan.";s:18:"scheduled_scanning";b:1;}s:9:"iplockout";a:48:{s:16:"login_protection";b:1;s:30:"login_protection_login_attempt";s:1:"5";s:34:"login_protection_lockout_timeframe";s:3:"300";s:28:"login_protection_lockout_ban";s:9:"timeframe";s:33:"login_protection_lockout_duration";s:1:"4";s:38:"login_protection_lockout_duration_unit";s:5:"hours";s:32:"login_protection_lockout_message";s:64:"You have been locked out due to too many invalid login attempts.";s:18:"username_blacklist";s:86:"adm\nadmin\nadmin1\nhostname\nmanager\nqwerty\nroot\nsupport\nsysadmin\ntest\nuser\nadministrator";s:10:"detect_404";b:1;s:20:"detect_404_threshold";s:2:"20";s:20:"detect_404_timeframe";s:3:"300";s:22:"detect_404_lockout_ban";s:9:"timeframe";s:27:"detect_404_lockout_duration";s:1:"4";s:32:"detect_404_lockout_duration_unit";s:5:"hours";s:26:"detect_404_lockout_message";s:86:"You have been locked out due to too many attempts to access a file that doesn\'t exist.";s:20:"detect_404_blacklist";s:0:"";s:20:"detect_404_whitelist";s:28:".css\n.js\n.jpg\n.png\n.gif\n.map";s:17:"detect_404_logged";b:1;s:12:"ip_blacklist";s:0:"";s:12:"ip_whitelist";s:0:"";s:17:"country_blacklist";s:0:"";s:17:"country_whitelist";s:0:"";s:18:"ip_lockout_message";s:66:"The administrator has blocked your IP from accessing this website.";s:26:"login_lockout_notification";b:1;s:23:"ip_lockout_notification";b:1;s:12:"notification";s:7:"enabled";s:24:"notification_subscribers";a:0:{}s:16:"cooldown_enabled";b:0;s:23:"cooldown_number_lockout";s:1:"3";s:15:"cooldown_period";s:2:"24";s:6:"report";s:7:"enabled";s:18:"report_subscribers";a:0:{}s:16:"report_frequency";s:6:"weekly";s:3:"day";s:6:"sunday";s:5:"day_n";s:1:"1";s:11:"report_time";s:4:"4:00";s:7:"dry_run";b:0;s:12:"storage_days";s:3:"180";s:8:"geoIP_db";s:0:"";s:29:"ip_blocklist_cleanup_interval";s:5:"never";s:18:"ua_banning_enabled";b:0;s:18:"ua_banning_message";s:50:"You have been blocked from accessing this website.";s:20:"ua_banning_blacklist";s:35:"MJ12Bot\nAhrefsBot\nSEMrushBot\nDotBot";s:20:"ua_banning_whitelist";s:379:"a6-indexer\nadsbot-google\naolbuild\napis-google\nbaidu\nbingbot\nbingpreview\nbutterfly\ncloudflare\nchrome\nduckduckbot\nembedly\nfacebookexternalhit\nfacebot\ngoogle page speed\ngooglebot\nia_archiver\nlinkedinbot\nmediapartners-google\nmsnbot\nnetcraftsurvey\noutbrain\npinterest\nquora\nslackbot\nslurp\ntweetmemebot\ntwitterbot\nuptimerobot\nurlresolver\nvkshare\nw3c_validator\nwordpress\nwp rocket\nyandex";s:24:"ua_banning_empty_headers";b:0;s:19:"maxmind_license_key";s:0:"";s:14:"global_ip_list";b:0;s:33:"global_ip_list_blocklist_autosync";b:0;}s:10:"two_factor";a:14:{s:7:"enabled";b:0;s:10:"lost_phone";b:1;s:10:"force_auth";b:0;s:15:"force_auth_mess";s:69:"You are required to setup two-factor authentication to use this site.";s:10:"user_roles";a:5:{i:0;s:13:"administrator";i:1;s:6:"editor";i:2;s:6:"author";i:3;s:11:"contributor";i:4;s:10:"subscriber";}s:16:"force_auth_roles";a:0:{}s:14:"custom_graphic";b:0;s:19:"custom_graphic_type";s:6:"upload";s:18:"custom_graphic_url";s:0:"";s:19:"custom_graphic_link";s:0:"";s:13:"email_subject";s:13:"Your OTP code";s:12:"email_sender";s:5:"admin";s:10:"email_body";s:167:"Hi {{display_name}},\n\nYour temporary password is {{passcode}}. To finish logging in, copy and paste the temporary password into the Password field on the login screen.";s:9:"app_title";s:0:"";}s:10:"mask_login";a:5:{s:7:"enabled";b:0;s:8:"mask_url";s:0:"";s:16:"redirect_traffic";s:3:"off";s:20:"redirect_traffic_url";s:0:"";s:24:"redirect_traffic_page_id";i:0;}s:16:"security_headers";a:16:{s:9:"sh_xframe";b:1;s:14:"sh_xframe_mode";s:10:"sameorigin";s:14:"sh_xframe_urls";s:0:"";s:17:"sh_xss_protection";b:1;s:22:"sh_xss_protection_mode";s:8:"sanitize";s:23:"sh_content_type_options";b:1;s:28:"sh_content_type_options_mode";s:7:"nosniff";s:19:"sh_strict_transport";b:1;s:12:"hsts_preload";b:0;s:17:"include_subdomain";b:0;s:19:"hsts_cache_duration";s:7:"30 days";s:18:"sh_referrer_policy";b:1;s:23:"sh_referrer_policy_mode";s:24:"origin-when-cross-origin";s:17:"sh_feature_policy";b:1;s:22:"sh_feature_policy_mode";s:4:"self";s:22:"sh_feature_policy_urls";s:0:"";}s:8:"settings";a:5:{s:14:"uninstall_data";s:4:"keep";s:18:"uninstall_settings";s:8:"preserve";s:9:"translate";s:0:"";s:14:"usage_tracking";b:0;s:18:"high_contrast_mode";b:0;}s:15:"pwned_passwords";a:3:{s:7:"enabled";b:0;s:10:"user_roles";a:5:{i:0;s:13:"administrator";i:1;s:6:"editor";i:2;s:6:"author";i:3;s:11:"contributor";i:4;s:10:"subscriber";}s:14:"custom_message";s:110:"You are required to change your password because the password you are using exists on database breach records.";}s:5:"audit";a:1:{s:7:"enabled";b:0;}s:17:"blocklist_monitor";a:1:{s:7:"enabled";b:0;}s:15:"security_tweaks";a:8:{s:19:"notification_repeat";s:6:"weekly";s:11:"subscribers";a:0:{}s:12:"notification";s:7:"enabled";s:8:"automate";b:1;s:4:"data";a:0:{}s:5:"fixed";a:4:{i:0;s:15:"disable-xml-rpc";i:1;s:14:"login-duration";i:2;s:17:"disable-trackback";i:3;s:18:"prevent-enum-users";}s:6:"issues";a:8:{i:0;s:11:"php-version";i:1;s:10:"wp-version";i:2;s:20:"prevent-php-executed";i:3;s:19:"protect-information";i:4;s:22:"replace-admin-username";i:5;s:12:"security-key";i:6;s:19:"disable-file-editor";i:7;s:10:"hide-error";}s:6:"ignore";a:0:{}}}s:7:"strings";a:9:{s:4:"scan";a:3:{i:0;s:6:"Active";i:1;s:26:"Email notifications active";i:2;s:66:"Email report inactive <span class="sui-tag sui-tag-pro">Pro</span>";}s:9:"iplockout";a:6:{i:0;s:23:"Login Protection active";i:1;s:20:"404 Detection active";i:2;s:26:"Global IP Blocker inactive";i:3;s:27:"User Agent Banning inactive";i:4;s:26:"Email notifications active";i:5;s:66:"Email report inactive <span class="sui-tag sui-tag-pro">Pro</span>";}s:10:"two_factor";a:1:{i:0;s:8:"Inactive";}s:10:"mask_login";a:1:{i:0;s:8:"Inactive";}s:16:"security_headers";a:1:{i:0;s:6:"Active";}s:15:"pwned_passwords";a:1:{i:0;s:8:"Inactive";}s:5:"audit";a:1:{i:0;s:53:"Inactive <span class="sui-tag sui-tag-pro">Pro</span>";}s:17:"blocklist_monitor";a:1:{i:0;s:53:"Inactive <span class="sui-tag sui-tag-pro">Pro</span>";}s:15:"security_tweaks";a:2:{i:0;s:30:"4/12 recommendations activated";i:1;s:26:"Email notifications active";}}s:4:"name";s:12:"Basic Config";s:11:"description";s:45:"Recommended default protection for every site";s:8:"immortal";b:1;s:12:"is_removable";b:1;}'),
(80, 1, 'defender_config_indexer', 'a:1:{s:36:"wp_defender_config_default1710043596";s:36:"wp_defender_config_default1710043596";}'),
(83, 1, 'wpdefender_preset_configs_transient_time', '1710043596'),
(87, 1, 'defender_scan_ignore_index', 'a:0:{}'),
(88, 1, 'defender_counter_completed_scans', '1'),
(89, 1, 'registrationnotification', 'yes'),
(90, 1, 'welcome_user_email', 'Howdy USERNAME,\r\n\r\nYour new account is set up.\r\n\r\nYou can log in with the following information:\r\nUsername: USERNAME\r\nPassword: PASSWORD\r\nLOGINLINK\r\n\r\nThanks!\r\n\r\n--The Team @ SITE_NAME'),
(93, 1, 'menu_items', 'a:0:{}'),
(94, 1, 'first_page', ''),
(95, 1, 'first_comment', ''),
(96, 1, 'first_comment_url', ''),
(97, 1, 'first_comment_author', ''),
(98, 1, 'limited_email_domains', ''),
(99, 1, 'banned_email_domains', ''),
(100, 1, 'new_admin_email', 'mike@reccenter.com'),
(101, 1, 'first_comment_email', ''),
(102, 1, 'classic-editor-replace', 'classic'),
(103, 1, 'classic-editor-allow-sites', 'allow'),
(104, 1, 'site_meta_supported', '1'),
(171, 1, 'dhredirect', 'no'),
(172, 1, 'bvActivateTime', '1710450593'),
(182, 1, 'bvSecretKey', 'nkhV2CyGs0GjAhyNMOhizaZxr4adCTsG'),
(192, 1, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1710457095;}') ;

#
# End of data contents of table `wp_sitemeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'WLSB2C_CHUi239_x'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'theme_editor_notice'),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'source_domain', 'white-label-storage-b2c.local'),
(17, 1, 'primary_blog', '1'),
(18, 1, 'session_tokens', 'a:3:{s:64:"39e9b9e6cff7885a3b37defc4f4d9f11a2dc9c14adc4fdd44664140c36ee48f3";a:4:{s:10:"expiration";i:1710544658;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36";s:5:"login";i:1710371858;}s:64:"839ab3771df00c1fe5541eec0a314b6b83c1e7169ad4a869fe322b21071efa7b";a:4:{s:10:"expiration";i:1710552422;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36";s:5:"login";i:1710379622;}s:64:"94ac9fce749e04c7409cd86da3d32851c2542878a93235bc354cb2646f91fdeb";a:4:{s:10:"expiration";i:1710624555;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:117:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36";s:5:"login";i:1710451755;}}'),
(19, 1, 'wp_dashboard_quick_press_last_post_id', '5'),
(20, 1, 'meta-box-order_page', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:36:"postimagediv,submitdiv,pageparentdiv";s:6:"normal";s:50:"aioseo-settings,commentstatusdiv,slugdiv,authordiv";s:8:"advanced";s:0:"";}'),
(21, 1, 'screen_layout_page', '2'),
(22, 1, 'wp_user-settings', 'libraryContent=browse'),
(23, 1, 'wp_user-settings-time', '1710354128'),
(24, 1, 'wp_persisted_preferences', 'a:2:{s:17:"core/edit-widgets";a:2:{s:26:"isComplementaryAreaVisible";b:1;s:12:"welcomeGuide";b:0;}s:9:"_modified";s:24:"2024-03-10T11:33:32.636Z";}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `spam` tinyint(2) NOT NULL DEFAULT '0',
  `deleted` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`, `spam`, `deleted`) VALUES
(1, 'WLSB2C_CHUi239_x', '$P$B7eMbHAEkgsAjNCRo4kLpy9qzsQVYM1', 'wlsb2c_chui239_x', 'mike@reccenter.com', 'http://white-label-storage-b2c.local', '2024-03-09 21:20:42', '', 0, 'WLSB2C_CHUi239_x', 0, 0) ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

